CREATE TABLE snapshots (
  snapshot_id TEXT PRIMARY KEY,
  shop_id TEXT NOT NULL,
  captured_at TEXT NOT NULL,
  row_count INTEGER NOT NULL
);
CREATE TABLE snapshot_orders (
  snapshot_id TEXT NOT NULL,
  order_id TEXT NOT NULL,
  ordered_at TEXT NOT NULL,
  sku TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  note TEXT NOT NULL,
  PRIMARY KEY (snapshot_id, order_id),
  FOREIGN KEY(snapshot_id) REFERENCES snapshots(snapshot_id)
);
CREATE TABLE export_jobs (
  export_id TEXT PRIMARY KEY,
  shop_id TEXT NOT NULL,
  snapshot_id TEXT NOT NULL,
  requested_at TEXT NOT NULL,
  status TEXT NOT NULL,
  object_key TEXT,
  row_count INTEGER,
  byte_count INTEGER,
  part_count INTEGER,
  sha256 TEXT
);
