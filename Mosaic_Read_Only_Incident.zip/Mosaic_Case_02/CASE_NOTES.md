# Your investigation notes

The casebook has an editable notebook as well. Nothing here is required for grading.

## My current explanation

## Confirmed observations

Include an export ID and a file/line reference when useful.

## Hypotheses not yet established

## Checks that ruled something out

## What remains unexplained

## Final causal explanation

