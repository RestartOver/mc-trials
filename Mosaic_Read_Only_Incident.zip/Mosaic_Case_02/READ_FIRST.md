# Mosaic: The export that passed

**Case 02 · Read-only debugging · One underlying implementation defect**

## The whole business, in four sentences

Mosaic is a fictional website that shop staff use to manage orders. A user can download a CSV file containing a saved selection of those orders. Each order should appear once, in order-ID order, with exactly the values in the saved selection. The user should receive that same file when the export says **Complete**.

There is no logistics vocabulary, deletion policy or hidden business rule to discover.

## The incident

On 24 September 2026, support received complaints about **completed exports with repeated or missing order records and damaged CSV content**. The orders on the website still looked correct. The export dashboard showed no failed jobs.

The first escalated example is **EX-24017**, for **SHOP-08**, using saved selection **SNP-510**. Support reproduced the complaint with **EX-24020**. Earlier export **EX-24009** used the same selection and was accepted by the customer. Small export **EX-24018** attracted no complaint. A later diagnostic export, **EX-24024**, was also reported correct.

Those are starting examples, not the only captures. The packet includes every export in the captured interval, including ordinary successful activity.

## What you need to do

**Explain the implementation defect and the sequence of events that turns correct source data into the reported bad download.** Point to the code and captured evidence that support your explanation, and account for both affected and unaffected examples.

You do **not** have to patch the code, install software, write tests or produce a formal report. Notes or a spoken explanation with file references are enough. There is no surprise second task.

## Rules, fixed before you begin

**For this independent attempt:** use the supplied files, your editor, local search, Git, paper, an ordinary notebook and ordinary language/API reference documentation. Local read-only queries and scratch calculations are allowed. Do not use AI to interpret the code, docs or evidence, suggest hypotheses, or solve the case. The browser notebook does not use AI.

No clock determines pass or fail. Set aside roughly **90–150 focused minutes** as a planning budget, not a validated completion target, and pause whenever you want. Difficulty has not been calibrated against other engineers.

There is **one implementation defect behind the reported incident**, not a four-bug scavenger hunt. The source has history; it is not a promise that every historical version was perfect under every possible configuration. Ordinary successful operations and normal redeliveries are not additional puzzles.

## Where things are

Start with [the system map and sequence](reference/01_SYSTEM_MAP.md). It is ordinary onboarding, not a hint. [The export rules](reference/02_EXPORT_RULES.md) define correctness. [The evidence guide](reference/03_EVIDENCE_GUIDE.md) explains the captures and clocks.

The file browser searches all the text, including source, logs, SQL, captures and diffs. The ZIP also contains a real Git repository and a SQLite database. **No Node installation is needed.**

The intended answer and private verification tests are not in this packet.
