// Convert a stream of byte chunks into numbered upload frames.
export async function* frameBytes(chunks, frameSize) {
  const workspace = Buffer.alloc(frameSize);
  let used = 0;
  let number = 1;
  for await (const chunk of chunks) {
    let offset = 0;
    while (offset < chunk.length) {
      const length = Math.min(frameSize - used, chunk.length - offset);
      chunk.copy(workspace, used, offset, offset + length);
      used += length;
      offset += length;
      if (used === frameSize) {
        yield { number: number++, bytes: workspace.subarray(0, used) };
        used = 0;
      }
    }
  }
  if (used > 0) {
    yield { number, bytes: workspace.subarray(0, used) };
  }
}
