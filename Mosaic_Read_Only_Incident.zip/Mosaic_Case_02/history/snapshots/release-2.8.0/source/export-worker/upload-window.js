// Limit pending part uploads. Upload acknowledgements may arrive out of order.
export class UploadWindow {
  constructor({ maxPending, archiveClient, exportId, sessionId, log }) {
    this.maxPending = maxPending;
    this.archiveClient = archiveClient;
    this.exportId = exportId;
    this.sessionId = sessionId;
    this.log = log;
    this.pending = new Map();
    this.receipts = new Map();
    this.failure = null;
  }

  async enqueue(frame) {
    if (this.failure) throw this.failure;
    const number = frame.number;
    if (this.pending.has(number) || this.receipts.has(number)) {
      throw new Error('repeated part number');
    }
    this.log('worker', 'frame_enqueued', {
      exportId: this.exportId, sessionId: this.sessionId,
      number, length: frame.bytes.length, pending: this.pending.size + 1,
    });
    const upload = this.archiveClient.putPart({
      exportId: this.exportId,
      sessionId: this.sessionId,
      number,
      bytes: frame.bytes,
    }).then(receipt => {
      this.receipts.set(number, receipt);
      this.log('worker', 'part_acknowledged', {
        exportId: this.exportId, number,
        storedBytes: receipt.length, sha256: receipt.sha256,
      });
    }).catch(error => {
      this.failure = error;
    }).finally(() => {
      this.pending.delete(number);
    });
    this.pending.set(number, upload);
    if (this.pending.size >= this.maxPending) {
      await Promise.race(this.pending.values());
    }
    if (this.failure) throw this.failure;
  }

  async drain() {
    await Promise.all(this.pending.values());
    if (this.failure) throw this.failure;
    return [...this.receipts.values()].sort((a, b) => a.number - b.number);
  }
}
