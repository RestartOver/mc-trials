// Convert a stream of byte chunks into numbered upload frames.
export async function* frameBytes(chunks, frameSize) {
  let pending = Buffer.alloc(0);
  let number = 1;
  for await (const chunk of chunks) {
    pending = Buffer.concat([pending, chunk]);
    while (pending.length >= frameSize) {
      const bytes = Buffer.from(pending.subarray(0, frameSize));
      yield { number: number++, bytes };
      pending = Buffer.from(pending.subarray(frameSize));
    }
  }
  if (pending.length > 0) {
    yield { number, bytes: Buffer.from(pending) };
  }
}
