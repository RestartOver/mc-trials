import { sha256 } from '../shared/checksum.js';

export function downloadExport(request, services) {
  const { database, archiveStore, log } = services;
  const job = database.findJob(request.exportId);
  if (!job || job.shopId !== request.shopId) return { status: 404 };
  if (job.status !== 'COMPLETE') return { status: 409 };
  const object = archiveStore.get(job.objectKey);
  if (request.ifNoneMatch === object.sha256) {
    log('downloads', 'not_modified', { exportId: job.exportId, requestId: request.requestId });
    return { status: 304, headers: { etag: object.sha256 } };
  }
  const body = Buffer.from(object.bytes);
  log('downloads', 'download_sent', {
    exportId: job.exportId, requestId: request.requestId,
    objectKey: job.objectKey, bytes: body.length, sha256: sha256(body),
  });
  return {
    status: 200,
    headers: {
      'content-type': object.contentType,
      'content-length': String(body.length),
      'content-disposition': `attachment; filename="orders-${job.exportId}.csv"`,
      etag: object.sha256,
    },
    body,
  };
}
