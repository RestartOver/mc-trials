import { partRequestId } from '../shared/ids.js';
import { sha256 } from '../shared/checksum.js';

export class ArchiveClient {
  constructor({ connectionPool, transport, clock, timing, log }) {
    this.connectionPool = connectionPool;
    this.transport = transport;
    this.clock = clock;
    this.timing = timing;
    this.log = log;
  }
  async begin(request) {
    return this.transport.begin(request);
  }
  async putPart(part) {
    const { exportId, sessionId, number, bytes } = part;
    const requestId = partRequestId(exportId, number);
    const connectionId = await this.connectionPool.acquire(exportId, number);
    this.log('transport', 'part_request_opened', {
      exportId, sessionId, number, requestId, connectionId, length: bytes.length,
    });
    try {
      await this.clock.sleep(this.timing.beforeBody(exportId, number));
      const body = Buffer.from(bytes);
      const checksum = sha256(body);
      this.log('transport', 'part_body_sent', {
        exportId, sessionId, number, requestId, connectionId,
        length: body.length, sha256: checksum,
      });
      const receipt = await this.transport.putPart({
        exportId, sessionId, number, requestId,
        body, checksum,
      });
      await this.clock.sleep(this.timing.afterBody(exportId, number));
      return receipt;
    } finally {
      this.connectionPool.release(connectionId);
    }
  }
  async complete(request) {
    return this.transport.complete(request);
  }
}
