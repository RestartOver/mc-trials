export class ConnectionPool {
  constructor(size, log) {
    this.free = Array.from({ length: size }, (_, i) => `archive-${i + 1}`);
    this.waiters = [];
    this.log = log;
  }
  async acquire(exportId, number) {
    if (this.free.length > 0) return this.free.shift();
    this.log('transport', 'connection_wait', { exportId, number });
    return new Promise(resolve => this.waiters.push(resolve));
  }
  release(connectionId) {
    const waiter = this.waiters.shift();
    if (waiter) waiter(connectionId);
    else this.free.push(connectionId);
  }
}
