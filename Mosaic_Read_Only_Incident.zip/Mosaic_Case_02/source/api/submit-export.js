import { objectKeyFor } from '../shared/ids.js';

export async function submitExport(request, services) {
  const { database, queue, log, clock } = services;
  const selection = database.findSelection(request.snapshotId);
  if (!selection || selection.shop_id !== request.shopId) {
    throw new Error('snapshot does not belong to the requested shop');
  }
  const job = {
    exportId: request.exportId,
    shopId: request.shopId,
    snapshotId: request.snapshotId,
    format: 'orders-csv-v1',
    requestedAt: clock.iso(),
    objectKey: objectKeyFor(request),
  };
  database.createJob(job);
  log('api', 'export_accepted', {
    exportId: job.exportId, shopId: job.shopId,
    snapshotId: job.snapshotId, expectedRows: selection.row_count,
    requestId: request.requestId,
  });
  await queue.publish('export-requests', { exportId: job.exportId });
  return { status: 202, exportId: job.exportId };
}
