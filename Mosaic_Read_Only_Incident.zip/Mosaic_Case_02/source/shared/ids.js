export function objectKeyFor(job) {
  return `exports/${job.shopId}/${job.exportId}.csv`;
}
export function archiveSessionFor(exportId) {
  return `upload-${exportId.toLowerCase()}`;
}
export function partRequestId(exportId, number) {
  return `${exportId.toLowerCase()}.part.${String(number).padStart(3, '0')}`;
}
