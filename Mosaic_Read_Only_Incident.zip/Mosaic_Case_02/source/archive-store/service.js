import { sha256 } from '../shared/checksum.js';

export class ArchiveStore {
  constructor(log) {
    this.log = log;
    this.sessions = new Map();
    this.objects = new Map();
  }
  async begin({ exportId, sessionId, objectKey, contentType }) {
    if (this.sessions.has(sessionId)) throw new Error('session already exists');
    this.sessions.set(sessionId, {
      exportId, objectKey, contentType, parts: new Map(),
    });
    this.log('archive', 'upload_opened', { exportId, sessionId, objectKey });
    return { sessionId };
  }
  async putPart({ exportId, sessionId, number, requestId, body, checksum }) {
    const session = this.sessions.get(sessionId);
    if (!session || session.exportId !== exportId) throw new Error('bad session');
    if (!Number.isInteger(number) || number < 1) throw new Error('bad part number');
    const actual = sha256(body);
    if (actual !== checksum) throw new Error('checksum mismatch');
    const previous = session.parts.get(number);
    if (previous && previous.sha256 !== actual) throw new Error('part conflict');
    const stored = { number, bytes: Buffer.from(body), sha256: actual, requestId };
    session.parts.set(number, stored);
    this.log('archive', 'part_stored', {
      exportId, sessionId, number, requestId, length: body.length, sha256: actual,
    });
    return { number, length: body.length, sha256: actual };
  }
  async complete({ exportId, sessionId, receipts }) {
    const session = this.sessions.get(sessionId);
    if (!session || session.exportId !== exportId) throw new Error('bad session');
    if (session.parts.size !== receipts.length) throw new Error('part count mismatch');
    const parts = [...session.parts.values()].sort((a, b) => a.number - b.number);
    for (let index = 0; index < parts.length; index++) {
      const part = parts[index];
      const receipt = receipts[index];
      if (part.number !== index + 1 || receipt.number !== part.number) {
        throw new Error('non-contiguous part list');
      }
      if (receipt.sha256 !== part.sha256 || receipt.length !== part.bytes.length) {
        throw new Error('receipt mismatch');
      }
    }
    const bytes = Buffer.concat(parts.map(part => part.bytes));
    const object = {
      objectKey: session.objectKey, contentType: session.contentType,
      bytes, sha256: sha256(bytes), partCount: parts.length,
    };
    this.objects.set(session.objectKey, object);
    this.log('archive', 'object_committed', {
      exportId, sessionId, objectKey: object.objectKey,
      length: bytes.length, parts: parts.length, sha256: object.sha256,
    });
    return { objectKey: object.objectKey, length: bytes.length, sha256: object.sha256 };
  }
  get(objectKey) {
    const object = this.objects.get(objectKey);
    if (!object) throw new Error('object not found');
    return { ...object, bytes: Buffer.from(object.bytes) };
  }
}
