// Capture adapter: deterministic time for offline reproduction.
// sleep() is an asynchronous delay, not a CPU-blocking wait.
export class CaptureClock {
  constructor(start) {
    this.epoch = Date.parse(start);
    this.elapsed = 0;
    this.nextOrder = 0;
    this.timers = [];
  }
  iso() { return new Date(this.epoch + this.elapsed).toISOString(); }
  sleep(ms) {
    return new Promise(resolve => {
      this.timers.push({ at: this.elapsed + ms, order: this.nextOrder++, resolve });
    });
  }
  async run(action) {
    let done = false;
    let result;
    let failure;
    Promise.resolve().then(action).then(value => {
      result = value; done = true;
    }, error => { failure = error; done = true; });
    let turns = 0;
    while (!done) {
      // Drain promise continuations before advancing to the next timer.
      await new Promise(resolve => setImmediate(resolve));
      if (done) break;
      this.timers.sort((a, b) => a.at - b.at || a.order - b.order);
      const timer = this.timers.shift();
      if (!timer) throw new Error('capture stalled without pending timer');
      this.elapsed = timer.at;
      timer.resolve();
      if (++turns > 100000) throw new Error('capture exceeded scheduler limit');
    }
    if (failure) throw failure;
    return result;
  }
}
