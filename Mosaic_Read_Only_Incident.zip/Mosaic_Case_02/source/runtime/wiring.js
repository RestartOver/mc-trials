import { DatabaseSync } from 'node:sqlite';
import { Database } from './database.js';
import { ExportQueue } from './queue.js';
import { CaptureClock } from './clock.js';
import { ConnectionPool } from '../storage/connection-pool.js';
import { ArchiveClient } from '../storage/archive-client.js';
import { ArchiveStore } from '../archive-store/service.js';
import { runExport } from '../export-worker/run.js';

export function createCaptureSystem({ databasePath, start, config, timing, build, worker }) {
  const clock = new CaptureClock(start);
  const logs = [];
  const log = (service, event, fields = {}) => {
    logs.push({ ts: clock.iso(), service, event, ...fields });
  };
  const sqlite = new DatabaseSync(databasePath, { readOnly: true });
  const database = new Database(sqlite, log);
  const queue = new ExportQueue(clock, log);
  const archiveStore = new ArchiveStore(log);
  const connectionPool = new ConnectionPool(config.archiveConnections, log);
  const archiveClient = new ArchiveClient({
    connectionPool, transport: archiveStore, clock, timing, log,
  });
  return {
    clock, logs, log, sqlite, database, queue,
    archiveStore, archiveClient, config,
    workerBuild: build, workerName: worker,
    runWorker: runExport,
  };
}
