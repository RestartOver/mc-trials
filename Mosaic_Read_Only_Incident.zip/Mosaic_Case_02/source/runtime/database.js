// Read-only source snapshots, plus an isolated in-memory job ledger for replay.
// SQL text is executed by SQLite; no query results are fabricated.
export class Database {
  constructor(sqlite, log) {
    this.sqlite = sqlite;
    this.log = log;
    this.jobs = new Map();
  }
  findSelection(snapshotId) {
    return this.sqlite.prepare('SELECT * FROM snapshots WHERE snapshot_id = ?').get(snapshotId);
  }
  queryOrders(sql, values) {
    return this.sqlite.prepare(sql).all(values);
  }
  createJob(job) {
    if (this.jobs.has(job.exportId)) throw new Error('duplicate export id');
    this.jobs.set(job.exportId, { ...job, status: 'QUEUED' });
  }
  findJob(exportId) {
    const job = this.jobs.get(exportId);
    return job && { ...job };
  }
  claimJob(exportId) {
    const job = this.jobs.get(exportId);
    if (!job || job.status !== 'QUEUED') return false;
    job.status = 'RUNNING';
    return true;
  }
  completeJob(exportId, result) {
    Object.assign(this.jobs.get(exportId), result, { status: 'COMPLETE' });
  }
  failJob(exportId, message) {
    Object.assign(this.jobs.get(exportId), { status: 'FAILED', error: message });
  }
}
