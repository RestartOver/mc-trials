export class ExportQueue {
  constructor(clock, log) {
    this.clock = clock;
    this.log = log;
    this.messages = [];
  }
  async publish(topic, payload) {
    if (topic !== 'export-requests') throw new Error('unknown queue');
    await this.clock.sleep(2);
    this.messages.push({ ...payload, delivery: 1 });
    this.log('queue', 'message_published', { topic, exportId: payload.exportId });
  }
  take() {
    return this.messages.shift();
  }
}
