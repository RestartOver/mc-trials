export async function deliver(message, services) {
  const { database, runWorker, log } = services;
  const job = database.findJob(message.exportId);
  if (!job) throw new Error('unknown export');
  if (job.status === 'COMPLETE') {
    log('dispatcher', 'already_complete', {
      exportId: job.exportId, delivery: message.delivery,
    });
    return { disposition: 'ack' };
  }
  if (!database.claimJob(job.exportId)) {
    log('dispatcher', 'already_claimed', { exportId: job.exportId });
    return { disposition: 'defer' };
  }
  log('dispatcher', 'job_claimed', {
    exportId: job.exportId, worker: services.workerName,
    delivery: message.delivery,
  });
  try {
    const result = await runWorker(job, services);
    database.completeJob(job.exportId, result);
    log('dispatcher', 'job_complete', {
      exportId: job.exportId, objectKey: result.objectKey,
      rows: result.rowCount, bytes: result.byteCount,
      parts: result.partCount, sha256: result.sha256,
    });
    return { disposition: 'ack' };
  } catch (error) {
    database.failJob(job.exportId, error.message);
    log('dispatcher', 'job_failed', {
      exportId: job.exportId, message: error.message,
    });
    return { disposition: 'retry' };
  }
}
