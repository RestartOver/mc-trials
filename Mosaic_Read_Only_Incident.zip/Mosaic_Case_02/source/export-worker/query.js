export const SELECT_ORDERS = `
 SELECT order_id, ordered_at, sku, quantity, note
 FROM snapshot_orders
 WHERE snapshot_id = :snapshotId
   AND order_id > :afterId
 ORDER BY order_id ASC
 LIMIT :pageSize
`;

export async function* readOrders(job, services) {
  const { database, clock, log, config } = services;
  let afterId = '';
  let page = 0;
  while (true) {
    const rows = database.queryOrders(SELECT_ORDERS, {
      snapshotId: job.snapshotId,
      afterId,
      pageSize: config.databasePageRows,
    });
    await clock.sleep(config.databaseReadMs);
    log('database', 'page_read', {
      exportId: job.exportId, snapshotId: job.snapshotId,
      page, afterId, rowCount: rows.length,
      firstId: rows[0]?.order_id ?? null,
      lastId: rows.at(-1)?.order_id ?? null,
    });
    if (rows.length === 0) return;
    for (const row of rows) yield row;
    afterId = rows.at(-1).order_id;
    page += 1;
  }
}
