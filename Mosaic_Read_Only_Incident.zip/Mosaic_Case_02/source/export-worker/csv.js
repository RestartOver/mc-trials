const columns = ['order_id', 'ordered_at', 'sku', 'quantity', 'note'];

export function csvCell(value) {
  const text = value === null || value === undefined ? '' : String(value);
  if (/[",\r\n]/.test(text)) return `"${text.replaceAll('"', '""')}"`;
  return text;
}

export function csvHeader() {
  return columns.join(',') + '\n';
}

export function csvRow(row) {
  return columns.map(column => csvCell(row[column])).join(',') + '\n';
}

export async function* encodeCsv(rows, counts) {
  yield Buffer.from(csvHeader(), 'utf8');
  for await (const row of rows) {
    const encoded = Buffer.from(csvRow(row), 'utf8');
    counts.rowCount += 1;
    counts.byteCount += encoded.length;
    yield encoded;
  }
}
