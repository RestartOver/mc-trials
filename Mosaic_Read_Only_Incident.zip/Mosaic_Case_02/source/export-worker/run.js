import { readOrders } from './query.js';
import { encodeCsv, csvHeader } from './csv.js';
import { frameBytes } from './frames.js';
import { UploadWindow } from './upload-window.js';
import { archiveSessionFor } from '../shared/ids.js';

export async function runExport(job, services) {
  const { archiveClient, log, config } = services;
  const counts = { rowCount: 0, byteCount: Buffer.byteLength(csvHeader()) };
  const sessionId = archiveSessionFor(job.exportId);
  log('worker', 'export_started', {
    exportId: job.exportId, snapshotId: job.snapshotId,
    build: services.workerBuild, worker: services.workerName,
    frameBytes: config.uploadFrameBytes,
    maxPending: config.maxPendingUploads,
    pageRows: config.databasePageRows,
  });
  await archiveClient.begin({
    exportId: job.exportId, sessionId, objectKey: job.objectKey,
    contentType: 'text/csv; charset=utf-8',
  });
  const uploads = new UploadWindow({
    maxPending: config.maxPendingUploads, archiveClient,
    exportId: job.exportId, sessionId, log,
  });
  const rows = readOrders(job, services);
  const encoded = encodeCsv(rows, counts);
  for await (const frame of frameBytes(encoded, config.uploadFrameBytes)) {
    await uploads.enqueue(frame);
  }
  const receipts = await uploads.drain();
  log('worker', 'export_encoded', {
    exportId: job.exportId, rows: counts.rowCount,
    bytes: counts.byteCount, parts: receipts.length,
  });
  const completed = await archiveClient.complete({
    exportId: job.exportId, sessionId, receipts,
  });
  if (completed.length !== counts.byteCount) {
    throw new Error('stored object length differs from encoded byte count');
  }
  return {
    objectKey: job.objectKey, rowCount: counts.rowCount,
    byteCount: counts.byteCount, partCount: receipts.length,
    sha256: completed.sha256,
  };
}
