# Support handover: 24 September 2026

**09:43, SHOP-08:** “The export says Complete, but the file starts in the middle of a line. Some orders repeat and the early orders aren't there. The orders screen is fine.” The attachment is retained as `evidence/downloads/EX-24017.csv`.

**09:49, support:** Re-exported the same saved selection as EX-24020. Customer reports the same kind of damage. Earlier EX-24009 was accepted by this customer.

**10:02, SHOP-45:** Reports repeated sections and missing records in EX-24019. Support retained the file; no edits have been made to it.

**10:08, support:** EX-24018 is a small export from another shop and was reported readable. No error banner was present on any of these jobs.

**10:17, operations:** Captured EX-24024 from SHOP-08 under a diagnostic worker setting. Support reports the file correct. Its exact effective settings are in the same request and worker-start records as other jobs.

**Handover:** There were worker and download releases this morning. Please explain why the affected exported bytes are wrong and why apparently similar exports can be correct. The order snapshots are preserved; avoid speculating about unrecorded customer edits.
