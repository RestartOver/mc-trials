# Packet inventory

- 17 current JavaScript source files (522 lines), with runtime wiring and capture adapters.
- 782 unique timestamped log events, supplied combined and per component.
- 25 captured exports with source selections, request settings, output files and download headers.
- SQL schema, complete SQL dump, per-selection CSVs and a read-only SQLite copy.
- Five release tags, four changes after the baseline, plaintext diffs and previous versions, plus a real local Git repository in the ZIP.
- A system map, request sequence, complete relevant business rules and storage interface.

File counts and log volume are not evidence of difficulty. No solution or grading key is embedded here.
