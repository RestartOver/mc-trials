# Reading this JavaScript snapshot

The business handlers are ordinary JavaScript ES modules. Each `import` identifies the other source file it uses. Each named `services` member is constructed in `source/runtime/wiring.js`. There are no dynamically installed plugins.

`async` functions may pause at an `await` while other started work continues. `async function*` functions produce values one at a time; `for await` consumes those values. These are normal JavaScript semantics, not a custom protocol.

`Buffer` is Node's standard byte-array type. Its methods use their ordinary Node semantics. Generic API documentation lookup is allowed in the independent attempt. This is not a memory-for-API-names examination.

The four application entry points call included storage and database adapters. A database read runs the supplied SQL. The queue adapter makes delivery visible. The deterministic clock records asynchronous ordering without making you run a server.

Each capture's output can be assessed against the fixed source rows without recreating any external account. No Node installation is necessary for a read-only investigation.

You may query the included SQLite database or use small local scripts to compare files. Doing so is allowed but not required. Do not modify the deployed source to complete the assignment: the requested deliverable is the explanation, not a patch.
