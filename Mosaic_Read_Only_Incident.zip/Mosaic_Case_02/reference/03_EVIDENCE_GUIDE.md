# How to use the evidence

## What is real inside the fiction?

Mosaic, its people and this incident are invented. The logs and CSV files were produced by executing the supplied JavaScript application logic against the supplied source rows. They were not written independently as clues and then fitted to the code.

The replay uses the built-in SQLite engine in Node 22 and a deterministic clock. It substitutes an in-process queue and ArchiveStore for network deployment; their implementations are included. These capture adapters define the runtime for this case. There is no missing microservice, hidden SQL trigger or unwritten business rule.

No trace record has been deliberately falsified. No clock-skew puzzle is involved. All timestamps are UTC. Durations in configuration are **milliseconds**. For equal timestamps, the order in `evidence/logs/all.jsonl` is the recorded emission order.

## Where to look

| Evidence | Location |
|---|---|
| Every job and its effective configuration | `evidence/requests/export-requests.json` |
| Completed-job metadata | `evidence/jobs.json` and `evidence/database/export_jobs.csv` |
| Combined execution trace | `evidence/logs/all.jsonl` |
| Same trace separated by component | Other files in `evidence/logs/` |
| Exact stored files | `evidence/objects/EX-*.csv` |
| Exact downloaded bodies and headers | `evidence/downloads/` and `evidence/download-headers/` |
| Accepted storage-part metadata | `evidence/archive-parts.json` |
| SQL schema, rows and complete database dump | `schema/` and `evidence/database/` |
| Source changes and rollout times | `history/` and `evidence/deployments/rollout.json` |

The combined and component traces contain the **same events**, not additional executions. A line repeated between those files is not a second action.

`order_id` identifies a row. `snapshotId` identifies the fixed input selection. `exportId` follows one export end to end. `sessionId` identifies its ArchiveStore upload. `number` is that upload's part number. `requestId` identifies one HTTP-equivalent request.

## Database access

The ZIP contains `mosaic-readonly.sqlite`, which can be opened in a SQLite viewer. Everything needed from it is also present as CSV and a readable SQL dump in the browser. You do not need a database program to solve the case.

The snapshots predate these exports and are fixed throughout. The replay's source queries execute the SQL shown in `query.js` against those snapshots.

## Git access

The ZIP is a real local Git repository, with release tags. Use `git log`, `git show` and `git diff` in its root normally. No clone, credentials or network are required. Plain-text copies of every change and the important previous file versions are also in the browser.

`history/CURRENT_REVISION.txt` identifies the deployed source snapshot. Not every component deployed at the same time; the rollout record is authoritative. `export_started` records the worker build and effective settings of that job. A job's logged configuration overrides the latest default when support starts a diagnostic run.

## Captured timing

The archive client acquires a connection, waits for its recorded transport delay, sends a body, then awaits acknowledgement. Other work can run across those asynchronous waits. The offline clock executes this ordering deterministically; it is not a requirement to infer unknown CPU timing.

Nothing needs to be run to establish the supplied traces. The complete control flow, SQL, configuration and message wiring are readable in the packet.
