# What a correct export means

## Input and output

Each request names one `shopId`, one `snapshotId` and a new `exportId`. The snapshot already exists and does not change during the captured period. `snapshot_orders` is authoritative for its contents; there is no external partner deciding which orders belong in it.

The output is UTF-8 CSV, with exactly this header and column order:

```csv
order_id,ordered_at,sku,quantity,note
```

Output records are ordered by `order_id` ascending. Every selected row appears once. Field values are unchanged. A cell containing a comma, quote or newline is quoted, and a quote inside a quoted cell is doubled. Lines end with LF (`\n`). There is no byte-order mark, compression, enrichment, filtering, deduplication or deletion during export.

These are the complete business rules relevant to this incident.

## A small example

Two database rows with order IDs `O-001` and `O-002` should produce:

```csv
order_id,ordered_at,sku,quantity,note
O-001,2026-09-10T10:00:00Z,SKU-104,1,standard order
O-002,2026-09-10T10:01:00Z,SKU-107,2,"gift, please"
```

This example explains formatting; it is not one of the incident exports.

## Three different units

A **database page** is a set of rows returned by one SQL query. A **CSV byte chunk** is an encoded header or row. An **upload frame/part** is a numbered section of file bytes. Their boundaries do not have to coincide, and a CSV line can cross an upload-part boundary.

The SQL query and its cursor are in `source/export-worker/query.js`. Encoding is in `csv.js`. Numbering and framing are in `frames.js`. The worker's upload scheduling is in `upload-window.js`.

## Completion

The worker records the number of source rows encoded. It also records the byte count, stored-object hash and number of uploaded parts. These metadata fields should not be treated as an independent audit of every final CSV row.

A failed storage call or rejected receipt must not produce a Complete job. The download application must return the stored object's bytes unchanged.
