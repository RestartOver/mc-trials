# What runs where

## Names used in the code

A **shop** is one customer account. An **order** is one purchase record. A **snapshot** is a saved, unchanging list of orders selected for an export. An **export job** asks the system to turn one snapshot into one CSV file.

The database snapshot is the input. The downloadable file is the output. A new export of the same snapshot should produce the same CSV bytes.

## Data-flow map

<div class="system-map"><svg viewBox="0 0 960 390" role="img" aria-label="Data flow from a user's export request through API, queue, dispatcher, worker, archive storage and downloads, with database reads and job records shown.">
<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#377c87"/></marker></defs>
<g fill="none" stroke="#377c87" stroke-width="2" marker-end="url(#arrow)">
<path d="M180 50 H225"/><path d="M410 50 H465"/><path d="M650 50 H705"/><path d="M820 80 V150"/>
<path d="M320 80 V145"/><path d="M455 190 H705"/><path d="M820 225 V325 H655"/>
<path d="M465 325 H415"/><path d="M225 325 H185"/><path d="M325 230 V285"/>
</g>
<g font-family="system-ui,sans-serif" font-size="11" fill="#46666a" text-anchor="middle">
<text x="202" y="38">request</text><text x="438" y="38">publish</text><text x="678" y="38">deliver</text>
<text x="844" y="116">run</text><text x="382" y="118">check / record job</text><text x="580" y="177">selected order rows</text>
<text x="800" y="274">numbered parts</text><text x="439" y="313">get file</text><text x="203" y="313">CSV</text>
<text x="391" y="267">file metadata</text>
</g>
<g fill="#fff" stroke="#b9ced0" stroke-width="1.2">
<rect x="20" y="20" width="160" height="60" rx="6"/><rect x="230" y="20" width="180" height="60" rx="6"/>
<rect x="470" y="20" width="180" height="60" rx="6"/><rect x="710" y="20" width="220" height="60" rx="6"/>
<rect x="240" y="150" width="210" height="80" rx="6"/><rect x="710" y="155" width="220" height="70" rx="6"/>
<rect x="470" y="290" width="180" height="70" rx="6"/><rect x="230" y="290" width="180" height="70" rx="6"/>
<rect x="20" y="290" width="160" height="70" rx="6"/>
</g>
<g font-family="system-ui,sans-serif" font-size="14" fill="#172638" font-weight="650">
<text x="34" y="45">Shop user</text><text x="244" y="45">exports-api</text><text x="484" y="45">export-requests</text><text x="724" y="45">export-dispatcher</text>
<text x="254" y="176">SQL database</text><text x="724" y="181">csv-worker</text><text x="484" y="317">ArchiveStore</text><text x="244" y="317">downloads</text><text x="34" y="317">Shop user</text>
</g>
<g font-family="system-ui,sans-serif" font-size="11" fill="#596e72">
<text x="34" y="63">Requests an export</text><text x="244" y="63">Checks selection; creates job</text><text x="484" y="63">Queue of export IDs</text><text x="724" y="63">Claims and runs jobs</text>
<text x="254" y="198">snapshot_orders: fixed input</text><text x="254" y="216">export_jobs: status / file path</text><text x="724" y="203">Read → encode → upload</text>
<text x="484" y="339">Saves the assembled file</text><text x="244" y="339">Returns stored bytes</text><text x="34" y="339">Receives CSV file</text>
</g></svg></div>

This is the high-level data flow. The call sequence below shows when those interactions occur.

## Request sequence

```text
User          API           Queue / Dispatcher      CSV worker       SQL DB        ArchiveStore      Downloads
 |             |                    |                   |               |               |                |
 |-- export -->|                    |                   |               |               |                |
 |             |-- check snapshot ------------------------------------>|               |                |
 |             |-- create job ---------------------------------------->|               |                |
 |             |-- publish ID ----->|                   |               |               |                |
 |<-- 202 -----|                    |                   |               |               |                |
 |                                  |-- claim job --------------------->|               |                |
 |                                  |-- run export --->|               |               |                |
 |                                  |                  |-- open upload --------------->|                |
 |                                  |                  |-- read page -->|              |                |
 |                                  |                  |<-- rows -------|              |                |
 |                                  |                  |-- encode rows / frame bytes   |                |
 |                                  |                  |-- upload numbered parts ----->|                |
 |                                  |                  |   [page reads and uploads repeat]              |
 |                                  |                  |<-- part receipts -------------|                |
 |                                  |                  |-- complete file ------------->|                |
 |                                  |                  |<-- saved file metadata -------|                |
 |                                  |<-- result -------|               |               |                |
 |                                  |-- mark Complete ---------------->|               |                |
 |-- download ---------------------------------------------------------------------------------------->|
 |                                                                                     |<-- get file --|
 |<----------------------------------------- saved CSV bytes ------------------------------------------|
```

This shows responsibilities, not a promise that all uploads finish in submission order. Exact ordering is determined by the supplied code, per-job configuration and logs.

## Source entry points

| Component | Entry point | What it does |
|---|---|---|
| API | `source/api/submit-export.js` | Validates snapshot ownership, creates job, publishes ID |
| Dispatcher | `source/dispatcher/deliver.js` | Claims a queued job, calls the worker, records result |
| CSV worker | `source/export-worker/run.js` | Coordinates SQL reads, CSV encoding and uploading |
| Storage client | `source/storage/archive-client.js` | Sends requests from the worker to ArchiveStore |
| ArchiveStore | `source/archive-store/service.js` | Stores parts and assembles the final object |
| Downloads | `source/downloads/response.js` | Returns the stored bytes to an authorized shop |

There is one worker invocation per claimed job. The queue may redeliver a message. A completed job is acknowledged without starting a second export.

## What is `services`?

It is the collection of explicitly named objects passed to a handler: `database`, `queue`, `archiveClient`, `archiveStore`, `clock`, `log`, configuration and worker identity. It is not a hidden service or an extra database.

`source/runtime/wiring.js` creates them and connects them. `config/service-map.json` lists the queue and component relationships in machine-readable form. `source/runtime/database.js` shows which database calls execute SQL and which job-status calls update the replay ledger.
