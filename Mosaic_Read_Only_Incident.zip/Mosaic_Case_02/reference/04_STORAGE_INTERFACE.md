# ArchiveStore, in ordinary terms

ArchiveStore is the internal service that holds finished export files. The worker sends the file in numbered pieces, then asks ArchiveStore to join the pieces together.

This is a small fictional storage API, not Amazon S3. There is no S3 minimum-part-size rule to discover. The captured environment uses 4,096-byte worker frames to keep the evidence manageable.

## Operations

**Open an upload.** `ArchiveClient.begin` names an export, an upload session and an object key (the future file's storage path). A session belongs to one export.

**Send a part.** `ArchiveClient.putPart` receives a part number and its bytes. It returns a receipt containing the part number, byte length and SHA-256 hash of the accepted bytes. The client implementation and transport are included in the source.

**Finish the file.** `ArchiveClient.complete` submits the receipts. ArchiveStore requires the complete consecutive part-number sequence starting at 1, with matching lengths and hashes. It joins accepted parts in numeric order, never arrival order, and returns the finished object's metadata.

**Download the file.** `ArchiveStore.get` returns the object bytes. The download application returns those bytes without a CSV transformation.

## What a checksum proves

At the storage boundary, the supplied checksum must match the request body. Stored-part receipts and final download hashes record the actual bytes at those stages. A hash value alone does not describe which order rows the file was meant to contain.

No storage corruption, hash collision, missing receipt, hidden SDK transform or secret retry is required for this case. All relevant client behavior is in `source/storage/`, all server behavior is in `source/archive-store/`.
