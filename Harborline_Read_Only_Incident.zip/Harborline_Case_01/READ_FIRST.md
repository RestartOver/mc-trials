# Harborline: The vanishing collection slots

**Read-only incident investigation. No installation. No coding task.**

Open `OPEN_CASE.html` for a searchable, offline copy of this entire case. The same files are also available in the folders beside it, for an editor or your usual search tools.

## Your handover

You are covering Harborline's dispatch integrations on 17 November 2025. Its board shows the collection bay and time window assigned to each consignment. SlotLedger, an external booking platform, is authoritative for those reservations.

The board has started losing confirmed assignments. The reservations still appear in the partner's console, and some assignments subsequently return without anyone rebooking them.

Start with these reported observations:

- **CN-48271** and **CN-48292**, for Larkspur Foods, were confirmed before 09:00 and unassigned shortly after 09:10.
- **CN-48311**, for the same customer, still had a confirmed bay at 09:12. Later reports are inconsistent about which consignments are affected.
- **CN-48871**, for Alder Components, also lost its assignment. Ferris Healthcare's **CN-48571** was still confirmed.
- Around 09:57, several missing assignments were back. At 10:12, support reported another disappearance. No corrective release had been made.

## Your task

Explain what caused the incident and support the explanation with the supplied evidence and source. Account for the selective effects and the disappear/reappear behavior, rather than stopping at the first suspicious line.

A spoken explanation, scratch notes, or an annotated trail is enough. **You do not need to fix anything, run tests, install Node, or propose a new architecture.** There are no extra tasks after the diagnosis.

There is one deliberately introduced implementation defect behind this incident. Routine traffic, recoverable operational warnings, and legitimate business activity are included too. You are not being asked to find every theoretical weakness in the code.

No stopwatch. This is a case to investigate, not a speed ranking. The answer and hints are not in this package.
