# Runtime and storage notes

## Scope of this source export

The JavaScript files contain the relevant application functions as deployed. They depend on infrastructure ports supplied by their hosts. This case is intentionally read-only: you do not need those hosts or a JavaScript runtime to investigate it.

The following behavior is part of the case contract, not an additional place to look for a hidden defect.

## Database ports

`db.serialForLink(linkId, callback)` executes a transaction under the link's sequence-row lock. It serializes ingestion for that link. An exception rolls back all operations in the transaction. The SQL extract lists the affected tables.

`tx.sourceRows.forLink` returns the stored rows for that link, including inactive rows. `upsert` writes the complete record. `retire` changes `live` to false and records the retirement fields; it does not call SlotLedger.

`db.liveSourcesFor(consignmentId, tenantId)` returns the live source rows for that exact tenant and consignment. No global or cross-tenant fallback is used.

`db.assignmentFor` and `db.assignmentsFor` read the operational projection. These reads are not cached. The board's API responses have `cache-control: no-store`.

Inbox, sequence and outbox operations in `consumeReady` are transaction-local. The projection consumer is serialized per link and cannot overtake a previous projection event from that link. There were no projection failures in the capture window.

## Object storage

Bundle keys are immutable. `putIfAbsent` accepts a repeated identical write and rejects a write with different contents. `get` returns the bytes written under that exact key. Captured objects include the entire bundle.

## Partner HTTP client

`http.post` and `http.get` return parsed successful response bodies. Non-2xx responses throw errors carrying `status` and, where supplied, `retryAfterMs`. `wait` advances the retry delay without changing a cursor or response.

## Scheduling

Control plans each configured link approximately every 15 minutes. A run uses known scope tags when conditional reads are enabled and the previous body run started less than `fullRefreshMinutes` earlier. Otherwise it requests bodies. A link has at most one active connector run, and the next sequence is allocated from durable per-link state.

Control advances its tag map only after the associated bundle has been durably stored and accepted by the queue. The later queue acknowledgement and projection are separate observable events.

## Logging and capture

All timestamps are UTC and synchronized. Evidence has not been deliberately withheld from one service. Normal requests, successful jobs, scheduler polls, health checks and some recoverable warnings are included.

Logs can be searched by consignment, reservation, run, scan, request, object or projection identity. A single universal trace ID is not imposed across the independently operated services. Mappings are recorded where the services exchange work.

`source-0855.json` and `source-1010.json` are transactionally consistent exports after the corresponding runs. The partner listing at 10:14 includes its current confirmed reservations. HTTP captures are frozen responses from each individual scan, not responses reconstructed from the final listing.
