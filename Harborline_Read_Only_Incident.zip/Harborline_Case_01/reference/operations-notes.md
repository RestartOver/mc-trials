# Incident desk notes

## 17 November 2025

**09:18 / Dispatch support**
Larkspur reports that CN-48271 and CN-48292 lost their collection allocations. They were confirmed earlier this morning. Support's direct API checks around 09:12 agree with the board. CN-48311 is still confirmed.

**09:23 / Integrations**
Alder Components reports CN-48871 is also affected. Ferris Healthcare has not reported loss of allocations. No failed deployment health checks have been reported.

**09:29 / Support**
A refresh did not consistently fix it. CN-48292 is showing a bay again; CN-48311 is now unassigned. Staff have not recreated either booking.

**09:43 / Partner liaison**
SlotLedger support says the questioned Larkspur and Alder reservations remain confirmed on their side. Their read API is healthy. A separate Copperline cancellation was made by a customer; that cancellation is not being reported as erroneous.

**09:58 / Dispatch support**
The original Larkspur examples have allocations again. No Harborline corrective release or manual source-table update has been performed.

**10:13 / Dispatch support**
CN-48271 is missing again. Please establish the cause before we authorize a broad rollback or a manual reconstruction of the assignment table.

## Recent operational changes

| UTC | Component | Version | Recorded purpose |
|---|---|---|---|
| 08:47 | dispatch-api | 8.4.6 | Response-header normalization |
| 09:04 | partner connector | 3.18.0 | Partner quota-control rollout |
| 09:07 | board-web | 12.8.1 | Collection-label layout |
| 09:22 | dispatch workers | 5.12.2 | Scheduled worker replacement |

Booking-ingest remains at 6.9.1. The supplied code is the active application logic during the incident. The deployment history is context, not a declaration that a particular release is guilty.

## Current request

Give the incident lead a causal account backed by record IDs and source locations. Distinguish a directly observed fact from a deduction. It is enough to name a safe intervention to consider; implementation, exhaustive hardening, and a replacement architecture are not part of this exercise.
