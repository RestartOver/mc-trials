# SlotLedger availability API, revision 2.6

## Purpose

The availability scan API reads confirmed reservations. It does not create, cancel or change them. Customer and operator booking actions use separate endpoints and appear in the partner audit log.

A scan is account-scoped. Each requested **scope** is a `(hub, serviceDate)` pair. Reservation IDs are stable and unique within an account. The same consignment cannot have two confirmed reservations within that account.

## Open a scan

`POST /v2/availability/scans`

Request fields:

| Field | Meaning |
|---|---|
| `account` | Partner account to read |
| `scopes` | Unique hub/date pairs |
| `knownTags` | Optional map from `HUB/YYYY-MM-DD` to a previously observed state tag |
| `pageSize` | Maximum number of scope sections returned per page |
| `requestKey` | Idempotency key for opening the scan |

The response contains `scanId`, `requestId`, an initial `cursor`, and `expiresAt`.

Opening a scan freezes an account view. Every subsequent page for that scan describes the same `asOf` view. Reservation changes after that instant cannot alter its pages. Retrying an open request with the same `requestKey` returns the same scan while it remains available.

## Read a page

`GET /v2/availability/scans/{scanId}?cursor={cursor}`

A successful page has these fields:

| Field | Meaning |
|---|---|
| `scanId`, `account` | Scan identity |
| `asOf` | Frozen-view timestamp |
| `pageIndex` | Zero-based page number |
| `requestId` | HTTP request identity |
| `sections` | Scope results on this page |
| `bodyRowCount` | Count of reservation rows physically included on this page |
| `nextCursor` | Next page cursor, or `null` after the final page |

Page size counts sections, not reservation rows. One scope is wholly contained in one section; a reservation body is not split across pages. Each requested scope appears exactly once across a successfully completed scan.

## Scope section representations

Each section contains `scope`, `tag` and `representation`. Tags are opaque equality tokens for the complete current confirmed-reservation set of that scope. They are not timestamps or sortable version numbers.

### `body`

The section contains `reservations`, the complete confirmed-reservation set for this scope in the frozen view. An empty array means there are no confirmed reservations in that scope. A body can be returned whether or not the client supplied a tag.

### `reference`

The current complete set is identical to the set denoted by the client's supplied tag. The section repeats that tag and does not contain `reservations`. The client already knows that set from the earlier body associated with the tag. A reference does not mean that the scope has no reservations.

The server may use `reference` only when the client's supplied tag equals the current scope tag. Omitting `knownTags` requests bodies for every scope. Clients may also omit individual tags to require bodies for particular scopes.

A scan can contain both representations. Receiving its final page means every requested scope has been answered. It does not mean that every scope's reservation body has been transmitted.

## Reservation body fields

| Field | Meaning |
|---|---|
| `reservationId` | Stable partner booking identity |
| `consignmentId` | Client's dispatch reference |
| `account`, `hub`, `serviceDate` | Ownership and scope |
| `state` | `confirmed` for records in this endpoint |
| `bay` | Allocated collection bay |
| `windowStart`, `windowEnd` | Local operational time labels for the explicit service date |
| `createdAt`, `updatedAt` | Record audit timestamps |

Canceled reservations are absent from subsequent bodies. A cancellation changes the scope's tag. No inference about cancellation can be made from a reference representation alone.

## Errors and retries

A 429 or 503 response has no page-consumption side effect. Retrying the same cursor returns the same frozen page. A retryable response includes `retryAfterMs`. An expired scan returns 410, requiring a new scan. The client must not publish a completed result from an incomplete or expired scan.

All state-tag, section, and paging behavior in this revision predates the incident. There was no SlotLedger protocol change during the capture window.
