# Harborline availability bundle, format 2

## Producer and consumer

The connector writes immutable bundles and emits `availability.ready.v2`. Booking-ingest consumes those messages. This contract predates the connector release captured in this incident.

A bundle has `manifest`, `rows`, and a producer-side `receipt`. The receipt is stored for connector diagnostics. Booking-ingest applies the manifest and rows; it does not interpret partner protocol fields in the receipt.

## Manifest

| Field | Meaning |
|---|---|
| `format` | `availability-bundle/2` |
| `runId` | One logical ingestion message identity |
| `linkId`, `tenantId` | Storage and ownership boundary |
| `sourceScan` | Remote scan used to produce the bundle |
| `sequence` | Per-link contiguous ingestion sequence |
| `createdAt` | Bundle creation time |
| `mode` | `replace-scopes` |
| `replaceScopes` | Scopes for which the rows contain a complete authoritative set |
| `rowCount` | Number of normalized rows in this bundle |
| `rowsHash` | SHA-256 of the canonical normalized row array |

## Applying `replace-scopes`

Within each declared replacement scope, incoming rows are activated or refreshed. Existing local rows not present in that incoming set are retired. A declared scope with no rows explicitly represents an empty set.

Scopes not declared in the manifest remain unchanged. A producer can legitimately emit an empty replacement-scope list with no rows; ingestion still records the message sequence and performs no source-row changes.

All rows must belong to the manifest's link, tenant and replacement scopes. Each source identity must occur once. The producer is responsible for supplying a complete set for each declared scope.

Count and checksum validation protect transport integrity. They do not independently establish the correctness of a producer's scope declaration.

## Normalized rows

Rows retain partner reservation identity, the consignment reference, hub/date, bay, collection window and partner update time. `sourceKey` is derived from link and partner reservation ID. This contract does not use timestamps to order individual reservations.

## Delivery and atomicity

A queue message contains `messageKey`, `groupKey`, `sequence`, `objectKey`, and the full bundle hash. `messageKey` is the originating run ID. `groupKey` is the link ID.

The queue can redeliver a message, including after a delayed acknowledgement. Booking-ingest deduplicates on the logical message key inside the transaction that updates the source rows. Non-contiguous new sequences are rejected for retry, not applied out of order.

Source-row changes, ingestion receipt, sequence advancement, and projection outbox entry commit together. Projection consumers process a link's events in sequence and update the operational assignment view.
