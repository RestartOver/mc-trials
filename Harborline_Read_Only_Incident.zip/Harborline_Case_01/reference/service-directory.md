# Service directory

This is an incident export, not a runnable development checkout. All application logic on the relevant data path is supplied under `source/`. Framework infrastructure is represented by the port contracts in `runtime-and-storage.md`. None of those ports has a hidden defect in this case.

| Component | Responsibility | Source | Log |
|---|---|---|---|
| control | Plan partner availability runs and store connector state | `source/control/` | `evidence/logs/control.jsonl` |
| connector | Call SlotLedger and publish normalized availability bundles | `source/connector/` | `evidence/logs/connector.jsonl` |
| booking-ingest | Apply durable availability bundles to local source records | `source/ingest/` | `evidence/logs/ingest.jsonl` |
| dispatch | Build the operational assignment view; handle explicit releases | `source/dispatch/` | `evidence/logs/dispatch.jsonl` |
| dispatch-api | Read the assignment view for the board | `source/api/board.js` | `evidence/logs/api.jsonl` |
| board-web | Render the API response | `source/api/board-client.js` | API responses are captured separately |
| SlotLedger | External reservation platform | Contract: `slotledger-v2.md` | `evidence/logs/partner.jsonl` |

## Identifiers

A **tenant** is a Harborline customer. A **link** connects that tenant to one SlotLedger account. `account-routes.json` lists the associations and configured scopes.

`consignmentId` is the operational reference visible to support. `reservationId` identifies a booking inside SlotLedger. `sourceKey` is Harborline's internal reservation identity. A reservation belongs to one hub and one service date.

A `runId` identifies one connector run. A SlotLedger `scanId` and its HTTP `requestId` values identify the remote work. An object-storage `objectKey` identifies the resulting bundle. Queue and projection receipts carry the originating run. IDs are not interchangeable, but boundary logs record the mappings.

## Capture contents

- `evidence/logs/`: JSON Lines, one record per line, sorted by timestamp within each file.
- `evidence/captures/`: Captured SlotLedger HTTP exchanges and stored bundle objects, grouped by link. These are full captures for the listed runs, not selected snippets.
- `evidence/records/jobs.json`: Exact inputs to scheduled connector jobs.
- `evidence/records/queue-receipts.json`: Message delivery acknowledgements.
- `evidence/records/board-responses.json`: Selected direct API responses corresponding to support checks.
- `evidence/records/source-0855.json`: Local state after the 08:55 runs.
- `evidence/records/source-1010.json`: Local state after the 10:10 runs.
- `evidence/records/partner-1014.json`: Partner's reservation listing at 10:14.

The exported code is the deployed implementation for the incident, not a proposed fix. Account names, data and platforms are fictional. Every clock in this export uses UTC; service dates are explicit business dates and are not inferred from a server timezone.
