import { scopeKey } from '../shared/identity.js';

export async function applyBundle(tx, bundle, now) {
  const m = bundle.manifest;
  const current = await tx.sourceRows.forLink(m.linkId);
  const targetScopes = new Set(m.replaceScopes.map(scopeKey));
  const incoming = new Map(bundle.rows.map(row => [row.sourceKey, row]));
  const changed = new Set();
  let inserted = 0;
  let refreshed = 0;
  let retired = 0;

  for (const row of bundle.rows) {
    const before = current.find(existing => existing.sourceKey === row.sourceKey);
    await tx.sourceRows.upsert({
      ...row, live: true, observedRun: m.runId, observedAt: now,
      retiredRun: null, retiredAt: null,
    });
    if (before) refreshed++; else inserted++;
    changed.add(row.consignmentId);
    await tx.audit.append({
      at: now, action: before?.live ? 'source.refresh' : 'source.activate',
      runId: m.runId, sourceKey: row.sourceKey, consignmentId: row.consignmentId,
      scope: scopeKey(row),
    });
  }

  for (const row of current) {
    if (!row.live || !targetScopes.has(scopeKey(row)) || incoming.has(row.sourceKey)) continue;
    await tx.sourceRows.retire(row.sourceKey, { retiredRun: m.runId, retiredAt: now });
    changed.add(row.consignmentId);
    retired++;
    await tx.audit.append({
      at: now, action: 'source.retire', runId: m.runId,
      sourceKey: row.sourceKey, consignmentId: row.consignmentId,
      scope: scopeKey(row), reason: 'snapshot_absent',
    });
  }

  const projectEvent = {
    eventKey: `projection:${m.runId}`,
    tenantId: m.tenantId,
    runId: m.runId,
    sequence: m.sequence,
    consignmentIds: [...changed].sort(),
  };
  await tx.outbox.insert(projectEvent);
  return { inserted, refreshed, retired, affected: changed.size, projectEvent };
}
