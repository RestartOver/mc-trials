-- Schema extract from booking-ingest 6.9.1.
-- The storage adapter methods referenced in JavaScript map to these tables.
CREATE TABLE source_reservation (
    source_key text PRIMARY KEY,
    link_id text NOT NULL,
    tenant_id text NOT NULL,
    reservation_id text NOT NULL,
    consignment_id text NOT NULL,
    hub text NOT NULL,
    service_date date NOT NULL,
    bay text NOT NULL,
    window_start text NOT NULL,
    window_end text NOT NULL,
    provider_updated_at timestamptz NOT NULL,
    live boolean NOT NULL,
    observed_run text NOT NULL,
    observed_at timestamptz NOT NULL,
    retired_run text,
    retired_at timestamptz,
    UNIQUE (link_id, reservation_id)
);
CREATE INDEX source_reservation_scope ON source_reservation(link_id, hub, service_date);
CREATE INDEX source_reservation_consignment ON source_reservation(tenant_id, consignment_id) WHERE live;

CREATE TABLE ingest_sequence (link_id text PRIMARY KEY, last_sequence bigint NOT NULL);
CREATE TABLE ingest_inbox (message_key text PRIMARY KEY, committed_at timestamptz NOT NULL);
CREATE TABLE projection_outbox (event_key text PRIMARY KEY, payload jsonb NOT NULL, published_at timestamptz);
CREATE TABLE projection_inbox (event_key text PRIMARY KEY, committed_at timestamptz NOT NULL);

-- serialForLink acquires the link's sequence-row lock. Source-row updates,
-- sequence advancement, inbox receipt and projection outbox commit together.
-- The transport acknowledges only a committed transaction.
-- A failed transaction changes none of these tables.
