import { scopeKey } from '../shared/identity.js';
import { digest, verifyBundle } from '../shared/integrity.js';

export function validateIncoming(message, bundle) {
  verifyBundle(bundle);
  if (digest(bundle) !== message.bundleHash) throw new Error('bundle digest mismatch');
  const m = bundle.manifest;
  if (m.format !== 'availability-bundle/2' || m.mode !== 'replace-scopes') {
    throw new Error('unsupported bundle format');
  }
  if (m.runId !== message.messageKey || m.linkId !== message.groupKey ||
      m.sequence !== message.sequence) throw new Error('message and manifest disagree');
  const allowed = new Set(m.replaceScopes.map(scopeKey));
  if (allowed.size !== m.replaceScopes.length) throw new Error('duplicate replacement scope');
  for (const row of bundle.rows) {
    if (row.linkId !== m.linkId || row.tenantId !== m.tenantId) throw new Error('row tenant mismatch');
    if (!allowed.has(scopeKey(row))) throw new Error('row outside replacement scope');
  }
}
