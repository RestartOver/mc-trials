import { validateIncoming } from './validate.js';
import { applyBundle } from './apply.js';

export async function consumeReady(message, deps) {
  const bundle = await deps.storage.get(message.objectKey);
  validateIncoming(message, bundle);
  deps.log.info('bundle_loaded', {
    runId: message.messageKey, linkId: message.groupKey, sequence: message.sequence,
    objectKey: message.objectKey, rowCount: bundle.rows.length,
    scopeCount: bundle.manifest.replaceScopes.length,
  });

  const result = await deps.db.serialForLink(message.groupKey, async tx => {
    if (await tx.inbox.has(message.messageKey)) return { disposition: 'duplicate' };
    const previous = await tx.sequences.get(message.groupKey);
    if (message.sequence !== previous + 1) throw new Error('sequence gap');
    const applied = await applyBundle(tx, bundle, deps.clock.now());
    await tx.inbox.insert(message.messageKey);
    await tx.sequences.set(message.groupKey, message.sequence);
    return { disposition: 'applied', ...applied };
  });

  deps.log.info('bundle_committed', {
    runId: message.messageKey, linkId: message.groupKey,
    disposition: result.disposition,
    inserted: result.inserted ?? 0, refreshed: result.refreshed ?? 0,
    retired: result.retired ?? 0, affected: result.affected ?? 0,
  });
  return result;
}
