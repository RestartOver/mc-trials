export async function projectConsignment(consignmentId, event, deps) {
  const source = await deps.db.liveSourcesFor(consignmentId, event.tenantId);
  if (source.length > 1) throw new Error('ambiguous live reservation');
  const chosen = source[0] ?? null;
  const before = await deps.db.assignmentFor(consignmentId, event.tenantId);
  const after = {
    tenantId: event.tenantId,
    consignmentId,
    state: chosen ? 'CONFIRMED' : 'UNASSIGNED',
    reservationId: chosen?.reservationId ?? null,
    bay: chosen?.bay ?? null,
    hub: chosen?.hub ?? before?.hub ?? null,
    serviceDate: chosen?.serviceDate ?? before?.serviceDate ?? null,
    windowStart: chosen?.windowStart ?? null,
    windowEnd: chosen?.windowEnd ?? null,
    changedByRun: event.runId,
    projectedAt: deps.clock.now(),
  };
  await deps.db.saveAssignment(after);
  const transition = before?.state !== after.state || before?.bay !== after.bay;
  deps.log.info('assignment_projected', {
    eventKey: event.eventKey, runId: event.runId, consignmentId,
    previousState: before?.state ?? 'UNKNOWN', state: after.state,
    previousBay: before?.bay ?? null, bay: after.bay,
    sourceCount: source.length, transition,
  });
  if (transition) {
    await deps.audit.append({
      at: deps.clock.now(), action: 'assignment.change',
      runId: event.runId, consignmentId,
      from: before?.state ?? 'UNKNOWN', to: after.state,
      bay: after.bay,
    });
  }
  return after;
}

export async function consumeProjection(event, deps) {
  if (await deps.db.projectionInbox.has(event.eventKey)) {
    deps.log.info('projection_duplicate', { eventKey: event.eventKey, runId: event.runId });
    return;
  }
  // The outbox consumer serializes each link's events; failed deliveries are retried.
  for (const id of event.consignmentIds) await projectConsignment(id, event, deps);
  await deps.db.projectionInbox.insert(event.eventKey);
  deps.log.info('projection_complete', {
    runId: event.runId, eventKey: event.eventKey, count: event.consignmentIds.length,
  });
}
