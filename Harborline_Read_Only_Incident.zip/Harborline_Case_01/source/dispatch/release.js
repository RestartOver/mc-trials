// Explicit cancellation is separate from availability projection.
export async function releaseReservation(request, deps) {
  const record = await deps.db.assignmentFor(request.consignmentId, request.tenantId);
  if (!record?.reservationId) return { status: 409, body: { code: 'NO_RESERVATION' } };
  const permit = await deps.auth.canCancel(request.actor, request.tenantId);
  if (!permit) return { status: 403, body: { code: 'FORBIDDEN' } };
  await deps.partner.cancel(record.reservationId, { requestKey: request.requestId });
  deps.log.info('reservation_cancel_requested', {
    requestId: request.requestId, consignmentId: request.consignmentId,
    reservationId: record.reservationId, actor: request.actor.id,
  });
  return { status: 202, body: { accepted: true } };
}
