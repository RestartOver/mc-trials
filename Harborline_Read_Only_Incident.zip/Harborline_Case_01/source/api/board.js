function viewOf(row) {
  if (!row) return null;
  return {
    consignmentId: row.consignmentId,
    assignmentState: row.state,
    collection: row.state === 'CONFIRMED' ? {
      hub: row.hub, bay: row.bay, serviceDate: row.serviceDate,
      windowStart: row.windowStart, windowEnd: row.windowEnd,
    } : null,
    updatedAt: row.projectedAt,
  };
}

export async function getConsignment(req, deps) {
  await deps.auth.requireTenant(req.actor, req.tenantId);
  const row = await deps.db.assignmentFor(req.consignmentId, req.tenantId);
  const view = viewOf(row);
  const status = view ? 200 : 404;
  deps.log.info('board_read', {
    requestId: req.requestId, tenantId: req.tenantId,
    consignmentId: req.consignmentId, status,
    assignmentState: view?.assignmentState ?? null,
    bay: view?.collection?.bay ?? null,
    projectionRun: row?.changedByRun ?? null,
  });
  return { status, headers: { 'cache-control': 'no-store' }, body: view };
}

export async function listBoard(req, deps) {
  await deps.auth.requireTenant(req.actor, req.tenantId);
  const rows = await deps.db.assignmentsFor(req.tenantId, req.serviceDate);
  const filtered = req.state ? rows.filter(r => r.state === req.state) : rows;
  deps.log.info('board_list', {
    requestId: req.requestId, tenantId: req.tenantId,
    serviceDate: req.serviceDate, state: req.state ?? 'ALL', count: filtered.length,
  });
  return { status: 200, headers: { 'cache-control': 'no-store' }, body: filtered.map(viewOf) };
}
