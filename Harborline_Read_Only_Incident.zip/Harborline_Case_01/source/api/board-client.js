// Browser-side rendering used by the operational dispatch board.
export function renderCollection(item) {
  if (item.assignmentState !== 'CONFIRMED' || !item.collection) {
    return { badge: 'Awaiting allocation', label: 'No collection slot assigned' };
  }
  const c = item.collection;
  return {
    badge: 'Confirmed',
    label: `${c.hub} / ${c.bay} / ${c.serviceDate} ${c.windowStart}-${c.windowEnd}`,
  };
}

export async function refreshBoard(client, query, display) {
  const response = await client.get('/dispatch/board', query, { cache: 'no-store' });
  if (response.status !== 200) {
    display.showUnavailable();
    return;
  }
  display.replaceRows(response.body.map(item => ({ ...item, collectionView: renderCollection(item) })));
}
