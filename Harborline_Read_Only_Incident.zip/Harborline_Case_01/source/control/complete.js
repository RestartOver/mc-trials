export async function completeRun(plan, receipt, deps) {
  // State is advanced only after the connector has durably queued its bundle.
  const previous = await deps.state.load(plan.linkId);
  if (previous.nextSequence !== plan.sequence) throw new Error('unexpected run sequence');
  const next = {
    ...previous,
    nextSequence: previous.nextSequence + 1,
    tags: { ...previous.tags, ...receipt.tags },
    lastRunAt: deps.clock.now(),
    lastBodyRunAt: plan.profile === 'body' ? plan.requestedAt : previous.lastBodyRunAt,
  };
  await deps.state.save(plan.linkId, next);
  deps.log.info('run_completed', {
    runId: plan.runId, linkId: plan.linkId, objectKey: receipt.objectKey,
    nextSequence: next.nextSequence,
  });
}
