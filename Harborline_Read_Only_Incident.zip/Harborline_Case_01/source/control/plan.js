import { uniqueScopes, scopeKey } from '../shared/identity.js';

export function makePlan(link, state, now, runId) {
  const ageMs = state.lastBodyRunAt ? Date.parse(now) - Date.parse(state.lastBodyRunAt) : Infinity;
  const useKnownTags = Boolean(link.conditionalReads) &&
    Date.parse(now) >= Date.parse(link.conditionalEnabledAt) &&
    ageMs < link.fullRefreshMinutes * 60_000;
  const scopes = uniqueScopes(link.scopes);
  const knownTags = {};
  if (useKnownTags) {
    for (const scope of scopes) {
      const key = scopeKey(scope);
      if (state.tags[key]) knownTags[key] = state.tags[key];
    }
  }
  return {
    runId,
    linkId: link.linkId,
    account: link.partnerAccount,
    tenantId: link.tenantId,
    requestedAt: now,
    sequence: state.nextSequence,
    scopes,
    knownTags,
    profile: Object.keys(knownTags).length ? 'conditional' : 'body',
    pageSize: 2,
  };
}

export async function schedule(link, deps) {
  const state = await deps.state.load(link.linkId);
  const plan = makePlan(link, state, deps.clock.now(), deps.ids.next('run'));
  deps.log.info('run_planned', {
    runId: plan.runId, linkId: plan.linkId, sequence: plan.sequence,
    profile: plan.profile, scopeKeys: plan.scopes.map(scopeKey),
    knownTagCount: Object.keys(plan.knownTags).length,
  });
  await deps.jobs.put(plan);
  return plan;
}
