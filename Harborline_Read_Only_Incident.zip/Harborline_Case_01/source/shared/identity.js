// Stable storage identities shared by the connector and dispatch services.
export function scopeKey(scope) {
  if (!scope || !/^[A-Z]{3}$/.test(scope.hub) ||
      !/^\d{4}-\d{2}-\d{2}$/.test(scope.serviceDate)) {
    throw new Error('invalid scope');
  }
  return `${scope.hub}/${scope.serviceDate}`;
}

export function sourceKey(linkId, reservationId) {
  return `${linkId}:${reservationId}`;
}

export function sameScope(a, b) {
  return scopeKey(a) === scopeKey(b);
}

export function uniqueScopes(scopes) {
  const byKey = new Map(scopes.map(s => [scopeKey(s), s]));
  return [...byKey.values()].sort((a, b) => scopeKey(a).localeCompare(scopeKey(b)));
}
