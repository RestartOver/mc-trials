import { createHash } from 'node:crypto';

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value !== null && typeof value === 'object') {
    return Object.fromEntries(Object.keys(value).sort().map(k => [k, canonical(value[k])]));
  }
  return value;
}

export function digest(value) {
  return createHash('sha256').update(JSON.stringify(canonical(value))).digest('hex');
}

export function verifyBundle(bundle) {
  if (bundle.manifest.rowCount !== bundle.rows.length) {
    throw new Error('bundle row count mismatch');
  }
  if (bundle.manifest.rowsHash !== digest(bundle.rows)) {
    throw new Error('bundle checksum mismatch');
  }
}
