export async function retryRead(operation, { log, wait, attempts = 3 }) {
  for (let attempt = 1; ; attempt++) {
    try {
      return await operation(attempt);
    } catch (error) {
      const retryable = error.status === 429 || error.status === 503;
      if (!retryable || attempt >= attempts) throw error;
      const delayMs = Math.min(error.retryAfterMs ?? attempt * 200, 2000);
      log.warn('read_retry', { attempt, status: error.status, delayMs });
      await wait(delayMs);
    }
  }
}
