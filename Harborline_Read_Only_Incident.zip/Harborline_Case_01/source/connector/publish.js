import { digest, verifyBundle } from '../shared/integrity.js';

export async function publishBundle(bundle, deps) {
  verifyBundle(bundle);
  const m = bundle.manifest;
  const objectKey = `availability/${m.linkId}/${m.runId}.json`;
  await deps.storage.putIfAbsent(objectKey, bundle);
  const message = {
    type: 'availability.ready.v2',
    messageKey: m.runId,
    groupKey: m.linkId,
    sequence: m.sequence,
    objectKey,
    bundleHash: digest(bundle),
  };
  const acceptance = await deps.queue.send(message);
  deps.log.info('bundle_published', {
    runId: m.runId, linkId: m.linkId, scanId: m.sourceScan, objectKey,
    rowCount: m.rowCount, scopeCount: m.replaceScopes.length,
    rowsHash: m.rowsHash, queueReceipt: acceptance.receipt,
  });
  return { ...bundle.receipt, objectKey };
}
