import { retryRead } from '../shared/retry.js';

export async function openScan(plan, deps) {
  const response = await retryRead(() => deps.http.post('/v2/availability/scans', {
    account: plan.account,
    scopes: plan.scopes,
    knownTags: plan.knownTags,
    pageSize: plan.pageSize,
    requestKey: plan.runId,
  }), deps);
  deps.log.info('scan_opened', {
    runId: plan.runId, scanId: response.scanId, partnerRequestId: response.requestId,
    account: plan.account,
  });
  return response;
}

export async function readPage(scanId, cursor, deps) {
  return retryRead(() => deps.http.get(`/v2/availability/scans/${scanId}`, { cursor }), deps);
}
