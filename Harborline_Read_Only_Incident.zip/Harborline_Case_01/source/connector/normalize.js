import { scopeKey, sourceKey } from '../shared/identity.js';

export function normalizeReservation(row, section, plan) {
  if (row.account !== plan.account) throw new Error('reservation account mismatch');
  if (scopeKey(row) !== scopeKey(section.scope)) throw new Error('reservation scope mismatch');
  if (!row.reservationId || !row.consignmentId || !row.bay) throw new Error('invalid reservation');
  if (row.state !== 'confirmed') throw new Error('unexpected state in availability body');
  return {
    sourceKey: sourceKey(plan.linkId, row.reservationId),
    reservationId: row.reservationId,
    consignmentId: row.consignmentId,
    linkId: plan.linkId,
    tenantId: plan.tenantId,
    hub: row.hub,
    serviceDate: row.serviceDate,
    bay: row.bay,
    windowStart: row.windowStart,
    windowEnd: row.windowEnd,
    providerUpdatedAt: row.updatedAt,
  };
}

export function normalizedRows(scan, plan) {
  const rows = [];
  const identities = new Set();
  for (const section of scan.sections) {
    if (section.representation !== 'body') continue;
    for (const raw of section.reservations) {
      const row = normalizeReservation(raw, section, plan);
      if (identities.has(row.sourceKey)) throw new Error('duplicate reservation identity');
      identities.add(row.sourceKey);
      rows.push(row);
    }
  }
  return rows.sort((a, b) => a.sourceKey.localeCompare(b.sourceKey));
}
