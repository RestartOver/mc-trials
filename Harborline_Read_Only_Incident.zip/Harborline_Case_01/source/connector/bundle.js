import { scopeKey, uniqueScopes } from '../shared/identity.js';
import { digest } from '../shared/integrity.js';
import { normalizedRows } from './normalize.js';

export function buildBundle(plan, scan, createdAt) {
  const rows = normalizedRows(scan, plan);
  const scopes = uniqueScopes(scan.sections.map(section => section.scope));
  const tags = Object.fromEntries(scan.sections.map(section => [scopeKey(section.scope), section.tag]));

  return {
    manifest: {
      format: 'availability-bundle/2',
      runId: plan.runId,
      linkId: plan.linkId,
      tenantId: plan.tenantId,
      sourceScan: scan.scanId,
      sequence: plan.sequence,
      createdAt,
      mode: 'replace-scopes',
      replaceScopes: scopes,
      rowCount: rows.length,
      rowsHash: digest(rows),
    },
    rows,
    receipt: { tags, pagesRead: scan.pagesRead },
  };
}
