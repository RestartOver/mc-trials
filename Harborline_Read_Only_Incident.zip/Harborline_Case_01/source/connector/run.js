import { collectScan } from './collect.js';
import { buildBundle } from './bundle.js';
import { publishBundle } from './publish.js';

export async function runConnector(plan, deps) {
  deps.log.info('connector_start', {
    runId: plan.runId, linkId: plan.linkId, profile: plan.profile,
    release: deps.release,
  });
  const scan = await collectScan(plan, deps);
  const bundle = buildBundle(plan, scan, deps.clock.now());
  return publishBundle(bundle, deps);
}
