import { scopeKey } from '../shared/identity.js';
import { openScan, readPage } from './client.js';

export async function collectScan(plan, deps) {
  const opened = await openScan(plan, deps);
  const expected = new Set(plan.scopes.map(scopeKey));
  const found = new Set();
  const sections = [];
  let cursor = opened.cursor;
  let pagesRead = 0;
  const visitedCursors = new Set();

  while (cursor !== null) {
    if (visitedCursors.has(cursor)) throw new Error('repeated page cursor');
    visitedCursors.add(cursor);
    const page = await readPage(opened.scanId, cursor, deps);
    if (page.scanId !== opened.scanId || page.account !== plan.account) {
      throw new Error('scan response identity mismatch');
    }
    if (page.pageIndex !== pagesRead) throw new Error('unexpected page index');
    let pageRows = 0;
    for (const section of page.sections) {
      const key = scopeKey(section.scope);
      if (!expected.has(key) || found.has(key)) throw new Error('unexpected or repeated scope');
      if (!['body', 'reference'].includes(section.representation)) {
        throw new Error('unknown representation');
      }
      if (section.representation === 'body' && !Array.isArray(section.reservations)) {
        throw new Error('missing reservations body');
      }
      if (section.representation === 'reference' && section.reservations !== undefined) {
        throw new Error('unexpected reservations body');
      }
      if (section.representation === 'reference' && plan.knownTags[key] !== section.tag) {
        throw new Error('unrecognized reference tag');
      }
      pageRows += section.reservations?.length ?? 0;
      found.add(key);
      sections.push(section);
    }
    if (pageRows !== page.bodyRowCount) throw new Error('page row count mismatch');
    deps.log.info('page_collected', {
      runId: plan.runId, scanId: opened.scanId, pageIndex: pagesRead,
      cursor, nextCursor: page.nextCursor,
      sectionCount: page.sections.length, bodyRowCount: pageRows,
      partnerRequestId: page.requestId,
    });
    cursor = page.nextCursor;
    pagesRead += 1;
  }
  if (found.size !== expected.size) throw new Error('scan did not cover requested scopes');
  deps.log.info('scan_collected', {
    runId: plan.runId, scanId: opened.scanId, pagesRead, scopeCount: found.size,
    rowsReceived: sections.reduce((n, s) => n + (s.reservations?.length ?? 0), 0),
  });
  return { scanId: opened.scanId, sections, pagesRead };
}
