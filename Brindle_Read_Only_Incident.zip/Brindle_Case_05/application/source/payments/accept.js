import { readPayment } from './envelope.js';
import { findReceipt, saveReceipt } from './receipts.js';
import { requireInvoice, changed } from '../billing/repository.js';

export function acceptPayment(context, payload, requestId) {
  const payment = readPayment(payload);
  const key = { accountId: payment.accountId, invoiceId: payment.invoiceId };
  return context.database.transaction(() => {
    requireInvoice(context.database, key);
    if (context.database.get('SELECT event_id FROM payment_events WHERE event_id=:eventId', { eventId: payment.eventId })) {
      context.log('payments', 'duplicate_delivery', { ...key, requestId, eventId: payment.eventId });
      return { accepted: true, disposition: 'duplicate', eventId: payment.eventId };
    }
    const prior = findReceipt(context.database, key, payment.receiptId);
    const disposition = prior && prior.provider_revision >= payment.providerRevision ? 'older-or-equal' : 'stored';
    if (disposition === 'stored') {
      saveReceipt(context, payment);
      changed(context, key, requestId, 'receipt', payment.receiptId);
    }
    context.database.run(`INSERT INTO payment_events
      (event_id, account_id, invoice_id, receipt_id, disposition, payload_json, received_at)
      VALUES (:eventId, :accountId, :invoiceId, :receiptId, :disposition, :payload, :now)`, {
      ...key, eventId: payment.eventId, receiptId: payment.receiptId, disposition,
      payload: JSON.stringify(payment), now: context.now(),
    });
    context.log('payments', 'receipt_processed', { ...key, requestId, eventId: payment.eventId,
      receiptId: payment.receiptId, providerRevision: payment.providerRevision,
      status: payment.status, amountCents: payment.amountCents, disposition });
    return { accepted: true, disposition, eventId: payment.eventId };
  });
}
