export function findReceipt(database, key, receiptId) {
  return database.get(`SELECT * FROM receipts
    WHERE account_id=:accountId AND invoice_id=:invoiceId AND receipt_id=:receiptId`, { ...key, receiptId });
}
export function saveReceipt(context, payment) {
  context.database.run(`INSERT INTO receipts
    (account_id, invoice_id, receipt_id, provider_revision, amount_cents, status, method,
     provider_reference, updated_at)
    VALUES (:accountId,:invoiceId,:receiptId,:providerRevision,:amountCents,:status,:method,
      :providerReference,:now)
    ON CONFLICT(account_id, invoice_id, receipt_id) DO UPDATE SET
      provider_revision=excluded.provider_revision, amount_cents=excluded.amount_cents,
      status=excluded.status, method=excluded.method, provider_reference=excluded.provider_reference,
      updated_at=excluded.updated_at`, {
    accountId: payment.accountId, invoiceId: payment.invoiceId, receiptId: payment.receiptId,
    providerRevision: payment.providerRevision, amountCents: payment.amountCents, status: payment.status,
    method: payment.method, providerReference: payment.providerReference, now: context.now(),
  });
}
