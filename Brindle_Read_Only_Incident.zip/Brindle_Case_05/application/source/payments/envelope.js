import { identifier, amount, requireThat } from '../shared/checks.js';

export function readPayment(payload) {
  for (const name of ['eventId','accountId','invoiceId','receiptId']) identifier(payload[name], name);
  amount(payload.providerRevision, 'providerRevision'); amount(payload.amountCents, 'amountCents');
  requireThat(['pending','settled','reversed'].includes(payload.status), 'Invalid receipt status');
  requireThat(['card','bank'].includes(payload.method), 'Invalid payment method');
  requireThat(typeof payload.providerReference === 'string', 'Missing providerReference');
  return payload;
}
