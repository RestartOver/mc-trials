export function enqueueBalance(context, invoice, causeId) {
  const jobId = context.id('JOB');
  context.database.run(`INSERT INTO balance_jobs
    (job_id, account_id, invoice_id, source_revision, cause_id, state, not_before, queued_at)
    VALUES (:jobId, :accountId, :invoiceId, :revision, :causeId, 'queued', :now, :now)`, {
    jobId, accountId: invoice.account_id, invoiceId: invoice.invoice_id,
    revision: invoice.revision, causeId, now: context.now(),
  });
  context.log('billing', 'balance_requested', {
    jobId, accountId: invoice.account_id, invoiceId: invoice.invoice_id,
    sourceRevision: invoice.revision, causeId,
  });
  return jobId;
}
