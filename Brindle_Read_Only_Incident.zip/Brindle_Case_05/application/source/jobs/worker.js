import { requireInvoice } from '../billing/repository.js';
import { calculateBalance } from '../reports/calculate.js';
import { readBalance, writeBalance } from '../reports/store.js';

export function handleJob(context, jobId) {
  return context.database.transaction(() => {
    const job = context.database.get('SELECT * FROM balance_jobs WHERE job_id=:jobId', { jobId });
    if (!job) throw new Error('Unknown balance job');
    if (job.state === 'complete') {
      context.log('balance-worker', 'delivery_duplicate', { jobId });
      return { disposition: 'duplicate' };
    }
    const key = { accountId: job.account_id, invoiceId: job.invoice_id };
    const invoice = requireInvoice(context.database, key);
    const prior = readBalance(context.database, key);
    let disposition = 'current';
    if (!prior || prior.source_revision < invoice.revision) {
      const balance = calculateBalance(context.database, key);
      writeBalance(context, key, invoice.revision, jobId, balance);
      context.log('balance-worker', 'balance_calculated', {
        ...key, jobId, requestedRevision: job.source_revision, sourceRevision: invoice.revision, ...balance,
      });
      disposition = 'calculated';
    }
    context.database.run(`UPDATE balance_jobs SET state='complete', finished_at=:now
      WHERE job_id=:jobId`, { jobId, now: context.now() });
    context.log('balance-worker', 'job_complete', { ...key, jobId, disposition, sourceRevision: invoice.revision });
    return { disposition };
  });
}
