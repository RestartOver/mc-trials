import { handleJob } from './worker.js';
import { addMilliseconds } from '../shared/time.js';

export function drain(context, { failFirstCauseIds = [], repeatCauseIds = [] } = {}) {
  const journal = [];
  while (true) {
    const job = context.database.get(`SELECT * FROM balance_jobs WHERE state='queued'
      ORDER BY not_before, job_id LIMIT 1`);
    if (!job) break;
    if (job.not_before > context.now()) context.setTime(job.not_before);
    const attempt = job.attempts + 1;
    context.database.run('UPDATE balance_jobs SET attempts=:attempt WHERE job_id=:jobId', { attempt, jobId: job.job_id });
    const base = { ts: context.now(), jobId: job.job_id, causeId: job.cause_id,
      accountId: job.account_id, invoiceId: job.invoice_id, attempt };
    context.log('transport', 'delivery_started', base);
    if (attempt === 1 && failFirstCauseIds.includes(job.cause_id)) {
      const retryAt = addMilliseconds(context.now(), context.config.retryDelayMs);
      context.database.run('UPDATE balance_jobs SET not_before=:retryAt WHERE job_id=:jobId', { retryAt, jobId: job.job_id });
      context.log('transport', 'connection_unavailable', { ...base, retryAt });
      journal.push({ ...base, status: 503, disposition: 'retry' });
    } else {
      try {
        const result = handleJob(context, job.job_id);
        journal.push({ ...base, status: 200, disposition: result.disposition });
        if (repeatCauseIds.includes(job.cause_id)) {
          context.advance(2);
          const repeated = handleJob(context, job.job_id);
          journal.push({ ...base, ts: context.now(), attempt: attempt + 1, status: 200, disposition: repeated.disposition });
        }
      } catch (error) {
        const final = attempt >= context.config.maxAttempts;
        context.database.run(`UPDATE balance_jobs SET state=:state,not_before=:next WHERE job_id=:jobId`, {
          state: final ? 'failed' : 'queued', next: addMilliseconds(context.now(), context.config.retryDelayMs), jobId: job.job_id,
        });
        context.log('transport','worker_error',{ ...base, message: error.message, final });
        journal.push({ ...base, status: 500, disposition: final ? 'failed' : 'retry' });
      }
    }
    context.advance(8);
  }
  context.log('transport','drain_finished',{ queued: context.database.get("SELECT COUNT(*) AS n FROM balance_jobs WHERE state='queued'").n });
  return journal;
}
