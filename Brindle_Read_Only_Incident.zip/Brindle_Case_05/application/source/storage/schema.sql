PRAGMA foreign_keys = ON;
CREATE TABLE accounts (
  account_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  currency TEXT NOT NULL CHECK(currency = 'USD')
);
CREATE TABLE invoices (
  account_id TEXT NOT NULL REFERENCES accounts(account_id),
  invoice_id TEXT NOT NULL,
  customer_label TEXT NOT NULL,
  due_date TEXT NOT NULL,
  reference TEXT NOT NULL DEFAULT '',
  revision INTEGER NOT NULL CHECK(revision >= 0),
  updated_at TEXT NOT NULL,
  PRIMARY KEY(account_id, invoice_id)
);
CREATE TABLE invoice_lines (
  account_id TEXT NOT NULL,
  invoice_id TEXT NOT NULL,
  line_id TEXT NOT NULL,
  description TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK(quantity > 0),
  unit_cents INTEGER NOT NULL CHECK(unit_cents >= 0),
  status TEXT NOT NULL CHECK(status IN ('active','void')),
  updated_at TEXT NOT NULL,
  PRIMARY KEY(account_id, invoice_id, line_id),
  FOREIGN KEY(account_id, invoice_id) REFERENCES invoices(account_id, invoice_id)
);
CREATE TABLE receipts (
  account_id TEXT NOT NULL,
  invoice_id TEXT NOT NULL,
  receipt_id TEXT NOT NULL,
  provider_revision INTEGER NOT NULL CHECK(provider_revision >= 0),
  amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
  status TEXT NOT NULL CHECK(status IN ('pending','settled','reversed')),
  method TEXT NOT NULL CHECK(method IN ('card','bank')),
  provider_reference TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(account_id, invoice_id, receipt_id),
  FOREIGN KEY(account_id, invoice_id) REFERENCES invoices(account_id, invoice_id)
);
CREATE TABLE payment_events (
  event_id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL,
  invoice_id TEXT NOT NULL,
  receipt_id TEXT NOT NULL,
  disposition TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  received_at TEXT NOT NULL
);
CREATE TABLE balance_jobs (
  job_id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL,
  invoice_id TEXT NOT NULL,
  source_revision INTEGER NOT NULL,
  cause_id TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('queued','complete','failed')),
  attempts INTEGER NOT NULL DEFAULT 0,
  not_before TEXT NOT NULL,
  queued_at TEXT NOT NULL,
  finished_at TEXT,
  FOREIGN KEY(account_id, invoice_id) REFERENCES invoices(account_id, invoice_id)
);
CREATE INDEX idx_balance_jobs_ready ON balance_jobs(state, not_before, job_id);
CREATE TABLE invoice_balances (
  account_id TEXT NOT NULL,
  invoice_id TEXT NOT NULL,
  source_revision INTEGER NOT NULL,
  billed_cents INTEGER NOT NULL,
  received_cents INTEGER NOT NULL,
  balance_cents INTEGER NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('open','paid','credit')),
  calculated_at TEXT NOT NULL,
  job_id TEXT NOT NULL,
  PRIMARY KEY(account_id, invoice_id),
  FOREIGN KEY(account_id, invoice_id) REFERENCES invoices(account_id, invoice_id)
);
CREATE TABLE balance_audit (
  audit_no INTEGER PRIMARY KEY,
  job_id TEXT NOT NULL,
  account_id TEXT NOT NULL,
  invoice_id TEXT NOT NULL,
  source_revision INTEGER NOT NULL,
  billed_cents INTEGER NOT NULL,
  received_cents INTEGER NOT NULL,
  balance_cents INTEGER NOT NULL,
  state TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE source_audit (
  audit_no INTEGER PRIMARY KEY,
  request_id TEXT NOT NULL,
  account_id TEXT NOT NULL,
  invoice_id TEXT NOT NULL,
  source_revision INTEGER NOT NULL,
  operation TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);
