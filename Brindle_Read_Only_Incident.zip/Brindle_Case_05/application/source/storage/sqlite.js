import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';

export class Store {
  constructor(filename) {
    this.connection = new DatabaseSync(filename);
    this.connection.exec(readFileSync(new URL('./schema.sql', import.meta.url), 'utf8'));
  }
  get(sql, values = {}) { return this.connection.prepare(sql).get(values); }
  all(sql, values = {}) { return this.connection.prepare(sql).all(values); }
  run(sql, values = {}) { return this.connection.prepare(sql).run(values); }
  transaction(work) {
    this.connection.exec('BEGIN IMMEDIATE');
    try {
      const value = work();
      this.connection.exec('COMMIT');
      return value;
    } catch (error) {
      this.connection.exec('ROLLBACK');
      throw error;
    }
  }
  snapshot(filename) { this.connection.prepare('VACUUM INTO ?').run(filename); }
  close() { this.connection.close(); }
}
