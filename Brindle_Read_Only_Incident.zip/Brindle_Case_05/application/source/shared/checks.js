export function requireThat(condition, message, status = 400) {
  if (!condition) {
    const error = new Error(message);
    error.status = status;
    throw error;
  }
}
export function identifier(value, name) {
  requireThat(typeof value === 'string' && /^[A-Z0-9-]{1,64}$/.test(value), `Invalid ${name}`);
  return value;
}
export function amount(value, name, allowZero = false) {
  requireThat(Number.isSafeInteger(value) && value >= (allowZero ? 0 : 1), `Invalid ${name}`);
  return value;
}
export function invoiceKey(accountId, invoiceId) {
  return { accountId: identifier(accountId, 'accountId'), invoiceId: identifier(invoiceId, 'invoiceId') };
}
