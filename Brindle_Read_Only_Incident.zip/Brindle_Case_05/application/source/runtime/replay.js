import { readFileSync, mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { Store } from '../storage/sqlite.js';
import { createContext } from './context.js';
import { route } from '../api/router.js';
import { drain } from '../jobs/drain.js';

const writeJson = (file, value) => writeFileSync(file, JSON.stringify(value,null,2)+'\n');
const writeLines = (file, values) => writeFileSync(file,values.map(v=>JSON.stringify(v)).join('\n')+(values.length?'\n':''));

export function replay(input, outputDirectory) {
  mkdirSync(outputDirectory,{recursive:true});
  const filename=join(outputDirectory,'closing.sqlite');
  if (existsSync(filename)) throw new Error('Output database already exists');
  const database=new Store(filename);
  const config=JSON.parse(readFileSync(new URL('../../config/runtime.json',import.meta.url),'utf8'));
  const context=createContext(database,{...config,...input.config},input.startAt);
  for (const account of input.accounts) database.run(
    'INSERT INTO accounts(account_id,name,currency) VALUES (:accountId,:name,:currency)', account);
  const requests=[],deliveries=[],checkpoints=[];
  for (const action of input.actions) {
    context.setTime(action.at);
    if (action.kind==='request') {
      const response=route(context,action.request);
      requests.push({ ts:context.now(), ...action.request, response });
    } else if (action.kind==='drain') {
      deliveries.push(...drain(context,action));
    } else if (action.kind==='checkpoint') {
      const at=context.now();
      const invoiceKeys=database.all('SELECT account_id,invoice_id FROM invoices ORDER BY account_id,invoice_id');
      const observed=[];
      for (const key of invoiceKeys) {
        const path=`/accounts/${key.account_id}/invoices/${key.invoice_id}`;
        const requestId=context.id('OBS');
        const detailRequest={ requestId:requestId+'-D', method:'GET',path };
        const statementRequest={requestId:requestId+'-S',method:'GET',path:path+'/statement'};
        const detail=route(context,detailRequest);const summary=route(context,statementRequest);
        requests.push({ts:at,...detailRequest,response:detail},{ts:at,...statementRequest,response:summary});
        observed.push({observationId:requestId,accountId:key.account_id,invoiceId:key.invoice_id,
          detailRequestId:detailRequest.requestId,statementRequestId:statementRequest.requestId});
      }
      const collectionRequests=[];
      for (const account of input.accounts) {
        let after='';
        do {
          const request={requestId:context.id('COL'),method:'GET',
            path:`/accounts/${account.accountId}/collections?asOf=${at.slice(0,10)}&after=${after}`};
          const response=route(context,request);requests.push({ts:at,...request,response});
          collectionRequests.push(request.requestId);after=response.body.nextAfterInvoiceId;
        } while(after);
      }
      const healthRequest={requestId:context.id('HLT'),method:'GET',path:'/health'};
      const health=route(context,healthRequest);requests.push({ts:at,...healthRequest,response:health});
      const snapshot=action.name+'.sqlite'; database.snapshot(join(outputDirectory,snapshot));
      checkpoints.push({name:action.name,ts:at,database:snapshot,observed,collectionRequests,healthRequestId:healthRequest.requestId});
      context.log('capture','checkpoint',{name:action.name,invoiceCount:observed.length});
    } else { throw new Error('Unknown action kind'); }
  }
  writeLines(join(outputDirectory,'requests.jsonl'),requests);
  writeLines(join(outputDirectory,'deliveries.jsonl'),deliveries);
  writeLines(join(outputDirectory,'all.jsonl'),context.logs);
  writeJson(join(outputDirectory,'checkpoints.json'),checkpoints);
  database.close();
  return { requests: requests.length, logs: context.logs.length, deliveries:deliveries.length, checkpoints:checkpoints.length };
}
if (process.argv[1] && import.meta.url===pathToFileURL(resolve(process.argv[1])).href) {
  if (process.argv.length!==4) throw new Error('Usage: node source/runtime/replay.js INPUT.json OUTPUT_DIRECTORY');
  const input=JSON.parse(readFileSync(process.argv[2],'utf8'));
  console.log(JSON.stringify(replay(input,resolve(process.argv[3]))));
}
