import { addMilliseconds } from '../shared/time.js';

export function createContext(database, config, startAt) {
  let time = startAt;
  const counters = new Map();
  const logs = [];
  return {
    database, config, logs,
    now: () => time,
    setTime: iso => { if (iso < time) throw new Error('Clock cannot move backwards'); time = iso; },
    advance: ms => { time = addMilliseconds(time, ms); },
    id: prefix => {
      const n = (counters.get(prefix) || 0) + 1; counters.set(prefix,n);
      return `${prefix}-${String(n).padStart(5,'0')}`;
    },
    log: (service,event,fields={}) => { logs.push({ ts: time, seq: logs.length+1, service,event,...fields }); },
  };
}
