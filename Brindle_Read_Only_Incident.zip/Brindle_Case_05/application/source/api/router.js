import { invoiceKey, requireThat, identifier } from '../shared/checks.js';
import { createInvoice, changeReference } from '../billing/invoices.js';
import { replaceLine } from '../billing/lines.js';
import { invoiceDetail } from '../billing/detail.js';
import { acceptPayment } from '../payments/accept.js';
import { statement } from '../reports/statement.js';
import { collectionPage } from '../reports/collections.js';

export function route(context, request) {
  const { method, path, body = {}, requestId } = request;
  context.log('http', 'request_started', { requestId, method, path });
  let response;
  try {
    const url = new URL(path, 'https://brindle.example');
    const parts = url.pathname.split('/').filter(Boolean);
    if (method === 'POST' && url.pathname === '/payments/events') {
      response = { status: 200, body: acceptPayment(context, body, requestId) };
    } else if (parts[0] === 'accounts' && parts[2] === 'collections' && method === 'GET') {
      response = { status: 200, body: collectionPage(context, identifier(parts[1],'accountId'), url.searchParams.get('asOf'), url.searchParams.get('after') || '') };
    } else if (parts[0] === 'accounts' && parts[2] === 'invoices' && parts[3]) {
      const key = invoiceKey(parts[1],parts[3]);
      if (method === 'POST' && parts.length === 4) response = { status: 201, body: createInvoice(context, key, body, requestId) };
      else if (method === 'GET' && parts.length === 4) response = { status: 200, body: invoiceDetail(context,key) };
      else if (method === 'GET' && parts[4] === 'statement') response = { status: 200, body: statement(context,key) };
      else if (method === 'PATCH' && parts[4] === 'reference') response = { status: 200, body: changeReference(context,key,body,requestId) };
      else if (method === 'PUT' && parts[4] === 'lines' && parts[5]) response = { status: 200, body: replaceLine(context,key,parts[5],body,requestId) };
    } else if (method === 'GET' && url.pathname === '/health') {
      response = { status: 200, body: {
        build: context.config.build, worker: context.config.worker,
        queued: context.database.get("SELECT COUNT(*) AS n FROM balance_jobs WHERE state='queued'").n,
        failed: context.database.get("SELECT COUNT(*) AS n FROM balance_jobs WHERE state='failed'").n,
      }};
    }
    requireThat(response, 'Route not found', 404);
  } catch (error) {
    response = { status: error.status || 500, body: { error: error.message } };
  }
  context.log('http', 'request_finished', { requestId, status: response.status });
  return response;
}
