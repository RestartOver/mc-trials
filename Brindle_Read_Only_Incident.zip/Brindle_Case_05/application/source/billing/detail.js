import { requireInvoice } from './repository.js';

export function invoiceDetail(context, key) {
  const invoice = requireInvoice(context.database, key);
  const lines = context.database.all(`SELECT line_id, description, quantity, unit_cents, status, updated_at
    FROM invoice_lines WHERE account_id=:accountId AND invoice_id=:invoiceId ORDER BY line_id`, key);
  const receipts = context.database.all(`SELECT receipt_id, provider_revision, amount_cents, status,
    method, provider_reference, updated_at FROM receipts
    WHERE account_id=:accountId AND invoice_id=:invoiceId ORDER BY receipt_id`, key);
  return {
    accountId: key.accountId, invoiceId: key.invoiceId, currency: 'USD',
    customerLabel: invoice.customer_label, dueDate: invoice.due_date,
    reference: invoice.reference, revision: invoice.revision, lines, receipts,
  };
}
