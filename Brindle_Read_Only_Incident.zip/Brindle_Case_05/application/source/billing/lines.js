import { amount, identifier, requireThat } from '../shared/checks.js';
import { changed, requireInvoice } from './repository.js';

export function replaceLine(context, key, lineId, payload, requestId) {
  identifier(lineId, 'lineId'); amount(payload.quantity, 'quantity'); amount(payload.unitCents, 'unitCents', true);
  requireThat(Number.isSafeInteger(payload.quantity * payload.unitCents), 'Line total too large');
  requireThat(typeof payload.description === 'string', 'Missing description');
  requireThat(['active','void'].includes(payload.status), 'Invalid line status');
  return context.database.transaction(() => {
    requireInvoice(context.database, key);
    context.database.run(`INSERT INTO invoice_lines
      (account_id, invoice_id, line_id, description, quantity, unit_cents, status, updated_at)
      VALUES (:accountId, :invoiceId, :lineId, :description, :quantity, :unitCents, :status, :now)
      ON CONFLICT(account_id, invoice_id, line_id) DO UPDATE SET
        description=excluded.description, quantity=excluded.quantity, unit_cents=excluded.unit_cents,
        status=excluded.status, updated_at=excluded.updated_at`, {
      ...key, lineId, description: payload.description, quantity: payload.quantity,
      unitCents: payload.unitCents, status: payload.status, now: context.now(),
    });
    requireThat(context.database.get(`SELECT COUNT(*) AS n FROM invoice_lines
      WHERE account_id=:accountId AND invoice_id=:invoiceId AND status='active'`, key).n > 0,
      'Invoice must retain an active line');
    return changed(context, key, requestId, 'line', lineId);
  });
}
