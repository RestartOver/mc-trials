import { requireThat } from '../shared/checks.js';
import { enqueueBalance } from '../jobs/enqueue.js';

export function requireInvoice(database, key) {
  const invoice = database.get(`SELECT * FROM invoices
    WHERE account_id = :accountId AND invoice_id = :invoiceId`, key);
  requireThat(invoice, 'Invoice not found', 404);
  return invoice;
}
export function changed(context, key, requestId, operation, entityId) {
  context.database.run(`UPDATE invoices SET revision = revision + 1, updated_at = :now
    WHERE account_id = :accountId AND invoice_id = :invoiceId`, { ...key, now: context.now() });
  const invoice = requireInvoice(context.database, key);
  context.database.run(`INSERT INTO source_audit
    (request_id, account_id, invoice_id, source_revision, operation, entity_id, created_at)
    VALUES (:requestId, :accountId, :invoiceId, :revision, :operation, :entityId, :now)`, {
    ...key, requestId, revision: invoice.revision, operation, entityId, now: context.now(),
  });
  const jobId = enqueueBalance(context, invoice, requestId);
  context.log('billing', 'invoice_changed', {
    ...key, requestId, operation, entityId, sourceRevision: invoice.revision, jobId,
  });
  return { invoiceId: invoice.invoice_id, revision: invoice.revision, jobId };
}
