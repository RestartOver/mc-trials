import { requireThat, identifier, amount } from '../shared/checks.js';
import { requireDate } from '../shared/time.js';
import { requireInvoice, changed } from './repository.js';

export function createInvoice(context, key, payload, requestId) {
  requireThat(typeof payload.customerLabel === 'string', 'Missing customerLabel');
  requireDate(payload.dueDate);
  requireThat(Array.isArray(payload.lines) && payload.lines.length > 0, 'Missing lines');
  const ids = new Set();
  for (const line of payload.lines) {
    identifier(line.lineId, 'lineId'); amount(line.quantity, 'quantity'); amount(line.unitCents, 'unitCents', true);
    requireThat(Number.isSafeInteger(line.quantity * line.unitCents), 'Line total too large');
    requireThat(!ids.has(line.lineId), 'Duplicate lineId'); ids.add(line.lineId);
    requireThat(typeof line.description === 'string', 'Missing line description');
  }
  return context.database.transaction(() => {
    requireThat(context.database.get('SELECT account_id FROM accounts WHERE account_id=:accountId',
      { accountId: key.accountId }), 'Account not found', 404);
    requireThat(!context.database.get('SELECT invoice_id FROM invoices WHERE account_id=:accountId AND invoice_id=:invoiceId', key), 'Invoice exists', 409);
    context.database.run(`INSERT INTO invoices
      (account_id, invoice_id, customer_label, due_date, reference, revision, updated_at)
      VALUES (:accountId, :invoiceId, :customerLabel, :dueDate, :reference, 0, :now)`, {
      ...key, customerLabel: payload.customerLabel, dueDate: payload.dueDate,
      reference: payload.reference ?? '', now: context.now(),
    });
    for (const line of payload.lines) {
      context.database.run(`INSERT INTO invoice_lines
        (account_id, invoice_id, line_id, description, quantity, unit_cents, status, updated_at)
        VALUES (:accountId, :invoiceId, :lineId, :description, :quantity, :unitCents, 'active', :now)`, {
        ...key, lineId: line.lineId, description: line.description,
        quantity: line.quantity, unitCents: line.unitCents, now: context.now(),
      });
    }
    return changed(context, key, requestId, 'create', key.invoiceId);
  });
}
export function changeReference(context, key, payload, requestId) {
  requireThat(typeof payload.reference === 'string', 'Missing reference');
  return context.database.transaction(() => {
    requireInvoice(context.database, key);
    context.database.run(`UPDATE invoices SET reference=:reference
      WHERE account_id=:accountId AND invoice_id=:invoiceId`, { ...key, reference: payload.reference });
    return changed(context, key, requestId, 'reference', key.invoiceId);
  });
}
