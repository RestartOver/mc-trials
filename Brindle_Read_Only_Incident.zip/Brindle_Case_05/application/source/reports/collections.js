import { requireDate } from '../shared/time.js';

export function collectionPage(context, accountId, asOf, afterInvoiceId = '') {
  requireDate(asOf);
  const rows = context.database.all(`SELECT i.invoice_id, i.customer_label, i.due_date,
      b.billed_cents, b.received_cents, b.balance_cents, b.source_revision, b.calculated_at
    FROM invoices AS i JOIN invoice_balances AS b
      ON b.account_id=i.account_id AND b.invoice_id=i.invoice_id
    WHERE i.account_id=:accountId AND i.invoice_id>:afterInvoiceId
      AND i.due_date<:asOf AND b.balance_cents>0
    ORDER BY i.invoice_id LIMIT :pageSize`, {
    accountId, asOf, afterInvoiceId, pageSize: context.config.invoicePageSize + 1,
  });
  const hasMore = rows.length > context.config.invoicePageSize;
  const items = rows.slice(0, context.config.invoicePageSize);
  return { accountId, asOf, items, nextAfterInvoiceId: hasMore ? items.at(-1).invoice_id : null };
}
