SELECT i.account_id, i.invoice_id,
       COALESCE(SUM(l.quantity * l.unit_cents), 0) AS billed_cents,
       COALESCE(SUM(r.amount_cents), 0) AS received_cents
FROM invoices AS i
LEFT JOIN invoice_lines AS l
  ON l.account_id = i.account_id
 AND l.invoice_id = i.invoice_id
 AND l.status = 'active'
LEFT JOIN receipts AS r
  ON r.account_id = i.account_id
 AND r.invoice_id = i.invoice_id
 AND r.status = 'settled'
WHERE i.account_id = :accountId
  AND i.invoice_id = :invoiceId
GROUP BY i.account_id, i.invoice_id;
