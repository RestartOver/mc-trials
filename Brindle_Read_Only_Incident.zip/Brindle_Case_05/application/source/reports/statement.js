import { requireInvoice } from '../billing/repository.js';
import { readBalance } from './store.js';

export function statement(context, key) {
  const invoice = requireInvoice(context.database, key);
  const balance = readBalance(context.database, key);
  return {
    accountId: key.accountId, invoiceId: key.invoiceId,
    customerLabel: invoice.customer_label, dueDate: invoice.due_date, currency: 'USD',
    sourceRevision: invoice.revision,
    calculation: balance ? {
      revision: balance.source_revision, billedCents: balance.billed_cents,
      receivedCents: balance.received_cents, balanceCents: balance.balance_cents,
      state: balance.state, calculatedAt: balance.calculated_at, jobId: balance.job_id,
    } : null,
    refreshPending: !balance || balance.source_revision !== invoice.revision,
  };
}
