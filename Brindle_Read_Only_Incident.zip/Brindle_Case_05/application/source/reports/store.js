export function readBalance(database, key) {
  return database.get(`SELECT * FROM invoice_balances
    WHERE account_id=:accountId AND invoice_id=:invoiceId`, key);
}
export function writeBalance(context, key, revision, jobId, balance) {
  const values = { ...key, revision, jobId, ...balance, now: context.now() };
  context.database.run(`INSERT INTO invoice_balances
    (account_id, invoice_id, source_revision, billed_cents, received_cents, balance_cents,
     state, calculated_at, job_id)
    VALUES (:accountId,:invoiceId,:revision,:billedCents,:receivedCents,:balanceCents,:state,:now,:jobId)
    ON CONFLICT(account_id,invoice_id) DO UPDATE SET
      source_revision=excluded.source_revision, billed_cents=excluded.billed_cents,
      received_cents=excluded.received_cents, balance_cents=excluded.balance_cents,
      state=excluded.state, calculated_at=excluded.calculated_at, job_id=excluded.job_id`, values);
  context.database.run(`INSERT INTO balance_audit
    (job_id,account_id,invoice_id,source_revision,billed_cents,received_cents,balance_cents,state,created_at)
    VALUES (:jobId,:accountId,:invoiceId,:revision,:billedCents,:receivedCents,:balanceCents,:state,:now)`, values);
}
