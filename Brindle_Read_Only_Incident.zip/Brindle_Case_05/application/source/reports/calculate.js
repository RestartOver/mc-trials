import { readFileSync } from 'node:fs';
const BALANCE_INPUTS = readFileSync(new URL('./balance-inputs.sql', import.meta.url), 'utf8');

export function calculateBalance(database, key) {
  const totals = database.get(BALANCE_INPUTS, key);
  if (!totals) throw new Error('Missing invoice for calculation');
  const billedCents = totals.billed_cents;
  const receivedCents = totals.received_cents;
  const balanceCents = billedCents - receivedCents;
  const state = balanceCents > 0 ? 'open' : balanceCents < 0 ? 'credit' : 'paid';
  return { billedCents, receivedCents, balanceCents, state };
}
