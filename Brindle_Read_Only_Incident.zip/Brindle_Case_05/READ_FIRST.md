# Brindle: The Balances That Wouldn't Stay Put

## The report

Brindle is used by repair businesses to issue invoices and record payments. Its collections screen lists overdue invoices so staff know which customers still need to pay.

Staff say the collections screen and generated statements sometimes disagree with the invoice's own line items and payment activity. A fully paid invoice can still appear as owing money. Another invoice disappears from collections even though money is still outstanding. Some statements show incorrect credits. Refreshing the page does not resolve the complaints, and a later capture shows one disputed invoice back at the expected balance.

Support checked the invoice edits and provider payment notifications against the stored source records. Those records are correct. The affected statement requests completed successfully; the captures below were taken after their updates finished processing.

## What the customer expects

An invoice's billed amount is the sum of quantity multiplied by unit price for every active line. Voided lines do not contribute. Its received amount is the sum of its settled payment receipts. Pending or reversed receipts do not contribute. The balance is billed minus received: positive means money is owed, zero means paid, and negative means a customer credit.

All captured amounts are integer US cents. There are no additional taxes, interest, currency conversions or hidden fees. An invoice appears in collections only when its balance is positive and its due date is before the requested date. After processing finishes, the statement and collections screen must agree with the current line items and receipts. Merely changing an invoice's reference label must not change its money totals.

## Verified examples

All four examples below belong to account `AC-41`. Times are UTC on 6 October 2026. “Confirmed correct” means the values were checked, not merely that nobody complained.

| Observation | Time | Invoice | Checked result |
|---|---|---|---|
| OBS-00064 | 08:13 | INV-4104 | Should owe 8,000 cents; statement says paid and it is absent from collections. |
| OBS-00092 | 08:23 | INV-4102 | Should owe zero; statement and collections show 18,000 cents outstanding. |
| OBS-00154 | 08:43 | INV-4104 | Later statement and collections agree with the expected 8,000 cents outstanding. |
| OBS-00061 | 08:13 | INV-4101 | Confirmed correct: billed 12,000, received 12,000, balance zero. |

The remaining captures include other accounts, correct results, incorrect results and a capture taken while updates were still pending. The raw requests, responses, logs and databases are provided. Files in `evidence/checks/` record independent comparisons with the rules above; a `PENDING` row is not counted as a confirmed incorrect result.

## Your investigation

Find the one underlying implementation defect behind this incident. Explain the causal path for an affected example and use an appropriate correct or recovered example to support it. A spoken explanation or a few paragraphs is enough. No code change, formal report or exhaustive catalogue of every observation is required.

You may record one initial suspicion now, before opening the source. “No hypothesis yet” is fine too. After that, investigate however you choose; there are no further checkpoints to complete.

## Access

This is a read-only case. No server, installation or application execution is required. Search, compare files, inspect SQL or use the CSV copies of every database table. The ZIP contains the actual SQLite databases; this browser contains the readable files. Some combined and per-service files are alternate views of the same capture, not extra executions.

There is no technical walkthrough, architecture diagram, protocol guide or Git history in this case. The incident and business rules above are the starting brief; the rest is source and evidence. Ordinary language/API documentation, notes and scratch calculations are allowed. Avoid AI interpretation during an independent attempt.

Allow 90–150 focused minutes including orientation as a planning window, not a deadline. Pause whenever you need to. Browser notes are local; use Save notes to keep a portable copy.
