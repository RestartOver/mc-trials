# Investigation notes

This is an optional scratchpad, not a required report template.

Focused time used:

Outside documentation or help used:

Observations and evidence references:

Current explanation and questions still open:

Final diagnosis:
