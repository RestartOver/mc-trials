export function orderLabel(orderId, config) {
  const prefix = config.labelPrefix.trim() || 'Order';
  return `${prefix} ${orderId}`;
}

export function lineLabel(line) {
  return `${line.sku} x ${line.quantity}`;
}
