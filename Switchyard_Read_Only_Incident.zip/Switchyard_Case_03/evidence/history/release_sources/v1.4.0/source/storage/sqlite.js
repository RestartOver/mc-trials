import { DatabaseSync } from 'node:sqlite';
export function openDatabase(filename, options = {}) {
  const connection = new DatabaseSync(filename, { readOnly: options.readOnly ?? false });
  connection.exec('PRAGMA foreign_keys = ON;');
  function statement(sql) {
    const result = connection.prepare(sql);
    result.setAllowBareNamedParameters(true);
    return result;
  }
  return {
    all(sql, params = {}) { return statement(sql).all(params); },
    get(sql, params = {}) { return statement(sql).get(params); },
    run(sql, params = {}) { return statement(sql).run(params); },
    exec(sql) { connection.exec(sql); },
    transaction(work) {
      connection.exec('BEGIN IMMEDIATE;');
      try {
        const result = work();
        connection.exec('COMMIT;');
        return result;
      } catch (error) {
        connection.exec('ROLLBACK;');
        throw error;
      }
    },
    close() { connection.close(); },
  };
}
