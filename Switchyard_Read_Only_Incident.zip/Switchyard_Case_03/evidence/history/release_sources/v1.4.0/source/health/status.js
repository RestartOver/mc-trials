export function healthStatus(queueStatus) {
  return {
    healthy: queueStatus.deadLetters === 0,
    queueDepth: queueStatus.outstanding,
    deadLetters: queueStatus.deadLetters,
  };
}
