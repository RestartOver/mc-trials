export function readBoard(database, accountId, warehouseId) {
  return database.all(`
    SELECT o.account_id, o.warehouse_id, o.order_id, o.customer_label, o.revision,
           l.line_no, l.sku, l.quantity
    FROM projection_orders AS o
    JOIN projection_lines AS l
      ON l.account_id = o.account_id AND l.warehouse_id = o.warehouse_id
     AND l.order_id = o.order_id
    WHERE o.account_id = :accountId AND o.warehouse_id = :warehouseId AND o.state = 'ready'
    ORDER BY o.order_id, l.line_no`, { accountId, warehouseId });
}
