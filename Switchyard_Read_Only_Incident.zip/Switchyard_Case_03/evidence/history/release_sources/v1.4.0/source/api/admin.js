import { readOne } from '../orders/repository.js';
import { groupOrders } from '../orders/group.js';
export function readAdminOrder(database, run, orderId) {
  const orders = groupOrders(readOne(database, run, orderId));
  return orders[0] ?? null;
}
