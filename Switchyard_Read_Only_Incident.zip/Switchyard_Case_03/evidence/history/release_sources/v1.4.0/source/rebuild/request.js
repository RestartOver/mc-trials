import { readConfig } from '../config.js';
import { eligibleOrderIds } from '../orders/repository.js';
export function openRun(request, database) {
  for (const field of ['runId', 'datasetId', 'accountId', 'warehouseId', 'trigger']) {
    if (typeof request[field] !== 'string' || !request[field]) {
      throw new Error(`Missing request field: ${field}`);
    }
  }
  if (!['rebuild', 'normal-update'].includes(request.trigger)) throw new Error('Unknown trigger');
  const run = { ...request, config: readConfig(request.config) };
  run.expectedOrders = eligibleOrderIds(database, run).length;
  return run;
}
