import { readPage } from '../orders/repository.js';
import { groupOrders } from '../orders/group.js';
import { buildEvent } from '../events/build.js';
import { publishEvent } from '../queue/publish.js';

export async function rebuild(run, services) {
  let afterOrderId = '';
  let page = 0;
  let publishedOrders = 0;
  services.log('rebuild', 'started', { expectedOrders: run.expectedOrders });
  while (true) {
    const rows = readPage(services.database, run, afterOrderId);
    services.capturePage({ page, afterOrderId, rows });
    services.log('database', 'page_read', {
      page, afterOrderId, rowCount: rows.length,
      firstOrderId: rows[0]?.order_id ?? null,
      lastOrderId: rows.at(-1)?.order_id ?? null,
    });
    if (rows.length === 0) break;
    const orders = groupOrders(rows);
    for (const order of orders) {
      await publishEvent(buildEvent(run, order), services);
      publishedOrders += 1;
    }
    afterOrderId = rows.at(-1).order_id;
    services.log('rebuild', 'checkpoint_saved', { page, afterOrderId, publishedOrders });
    page += 1;
  }
  services.log('rebuild', 'enumeration_finished', { pages: page, publishedOrders });
  return { pages: page, publishedOrders };
}
