export function orderKey(accountId, warehouseId, orderId) {
  return JSON.stringify([accountId, warehouseId, orderId]);
}
export function eventKey(runId, orderId) {
  return `${runId}/${orderId}`;
}

export function scopeKey(accountId, warehouseId) {
  return JSON.stringify([accountId, warehouseId]);
}
