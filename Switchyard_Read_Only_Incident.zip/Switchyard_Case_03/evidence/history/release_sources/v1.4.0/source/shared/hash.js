import { createHash } from 'node:crypto';
export function digest(text) {
  return createHash('sha256').update(text, 'utf8').digest('hex');
}
