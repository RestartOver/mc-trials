import { validateEvent } from '../events/validate.js';
import { applyDocument } from '../projection/store.js';
import { digest } from '../shared/hash.js';
export async function handleBatch(invocation, services) {
  const batchItemFailures = [];
  for (const record of invocation.Records) {
    try {
      const event = validateEvent(JSON.parse(record.body));
      services.log('worker', 'message_received', {
        messageId: record.messageId, eventId: event.eventId,
        orderId: event.order.orderId, bodySha256: digest(record.body),
        receiveCount: Number(record.attributes.ApproximateReceiveCount),
      });
      services.beforeApply(record);
      const disposition = applyDocument(services.database, event);
      services.log('worker', 'message_completed', {
        messageId: record.messageId, eventId: event.eventId,
        orderId: event.order.orderId, disposition, lineCount: event.order.lines.length,
      });
    } catch (error) {
      batchItemFailures.push({ itemIdentifier: record.messageId });
      services.log('worker', 'message_failed', {
        messageId: record.messageId, error: error.message,
      });
    }
  }
  return { batchItemFailures };
}
