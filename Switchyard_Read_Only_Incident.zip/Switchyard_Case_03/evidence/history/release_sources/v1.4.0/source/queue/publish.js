import { digest } from '../shared/hash.js';
import { validateEvent } from '../events/validate.js';
export async function publishEvent(event, services) {
  validateEvent(event);
  const body = JSON.stringify(event);
  const message = await services.queue.send(body);
  services.log('publisher', 'message_sent', {
    eventId: event.eventId, messageId: message.messageId,
    orderId: event.order.orderId, lineCount: event.order.lines.length,
    bodyBytes: Buffer.byteLength(body, 'utf8'), bodySha256: digest(body),
  });
  return message.messageId;
}
