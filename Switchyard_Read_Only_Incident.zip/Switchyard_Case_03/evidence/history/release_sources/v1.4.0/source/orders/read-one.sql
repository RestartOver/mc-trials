SELECT o.dataset_id, o.account_id, o.warehouse_id, o.order_id,
       o.customer_label, o.revision, o.state, o.updated_at,
       l.line_no, l.sku, l.quantity
FROM source_orders AS o
JOIN source_order_lines AS l
  ON l.dataset_id = o.dataset_id
 AND l.account_id = o.account_id
 AND l.order_id = o.order_id
WHERE o.dataset_id = :datasetId
  AND o.account_id = :accountId
  AND o.order_id = :orderId
ORDER BY l.line_no;
