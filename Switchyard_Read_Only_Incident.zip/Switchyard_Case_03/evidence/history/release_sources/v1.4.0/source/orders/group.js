export function groupOrders(rows) {
  const orders = new Map();
  for (const row of rows) {
    let order = orders.get(row.order_id);
    if (!order) {
      order = {
        accountId: row.account_id,
        warehouseId: row.warehouse_id,
        orderId: row.order_id,
        revision: row.revision,
        state: row.state,
        customerLabel: row.customer_label,
        updatedAt: row.updated_at,
        lines: [],
      };
      orders.set(row.order_id, order);
    }
    order.lines.push({ lineNo: row.line_no, sku: row.sku, quantity: row.quantity });
  }
  return [...orders.values()];
}
