WITH selected AS (
    SELECT order_id
    FROM source_orders
    WHERE dataset_id = :datasetId
      AND account_id = :accountId
      AND warehouse_id = :warehouseId
      AND state = 'ready'
      AND order_id > :afterOrderId
    ORDER BY order_id
    LIMIT :pageLimit
)
SELECT o.dataset_id, o.account_id, o.warehouse_id, o.order_id,
       o.customer_label, o.revision, o.state, o.updated_at,
       l.line_no, l.sku, l.quantity
FROM selected AS s
JOIN source_orders AS o
  ON o.dataset_id = :datasetId
 AND o.account_id = :accountId
 AND o.order_id = s.order_id
JOIN source_order_lines AS l
  ON l.dataset_id = o.dataset_id
 AND l.account_id = o.account_id
 AND l.order_id = o.order_id
ORDER BY o.order_id, l.line_no;
