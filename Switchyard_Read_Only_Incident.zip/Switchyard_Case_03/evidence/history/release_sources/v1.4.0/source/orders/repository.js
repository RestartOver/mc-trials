import { readFileSync } from 'node:fs';
const pageSql = readFileSync(new URL('./list-page.sql', import.meta.url), 'utf8');
const oneSql = readFileSync(new URL('./read-one.sql', import.meta.url), 'utf8');

export function readPage(database, run, afterOrderId) {
  return database.all(pageSql, {
    datasetId: run.datasetId,
    accountId: run.accountId,
    warehouseId: run.warehouseId,
    afterOrderId,
    pageLimit: run.config.pageLimit,
  });
}
export function readOne(database, run, orderId) {
  return database.all(oneSql, {
    datasetId: run.datasetId, accountId: run.accountId, orderId,
  });
}
export function eligibleOrderIds(database, run) {
  return database.all(`
    SELECT order_id FROM source_orders
    WHERE dataset_id = :datasetId AND account_id = :accountId
      AND warehouse_id = :warehouseId AND state = 'ready'
    ORDER BY order_id`, {
    datasetId: run.datasetId, accountId: run.accountId, warehouseId: run.warehouseId,
  }).map(row => row.order_id);
}
