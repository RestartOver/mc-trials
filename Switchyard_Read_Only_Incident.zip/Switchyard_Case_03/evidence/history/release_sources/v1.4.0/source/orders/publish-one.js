import { readOne } from './repository.js';
import { groupOrders } from './group.js';
import { buildEvent } from '../events/build.js';
import { publishEvent } from '../queue/publish.js';
export async function publishOne(run, orderId, services) {
  const rows = readOne(services.database, run, orderId);
  services.log('database', 'single_order_read', { orderId, rowCount: rows.length });
  const orders = groupOrders(rows);
  if (orders.length !== 1) throw new Error(`Source order missing: ${orderId}`);
  if (orders[0].warehouseId !== run.warehouseId) throw new Error('Wrong warehouse');
  return publishEvent(buildEvent(run, orders[0]), services);
}
