export function completeRun(run, enumeration, queueStatus, database, log) {
  const acknowledged = database.get(`SELECT COUNT(*) AS n FROM processed_events WHERE run_id = :runId`, {
    runId: run.runId,
  }).n;
  const complete = enumeration.publishedOrders === run.expectedOrders &&
    acknowledged === enumeration.publishedOrders && queueStatus.outstanding === 0;
  const status = complete ? 'Complete' : 'Waiting';
  log('jobs', 'status_recorded', {
    status, expectedOrders: run.expectedOrders,
    publishedOrders: enumeration.publishedOrders, acknowledgedEvents: acknowledged,
    outstandingMessages: queueStatus.outstanding,
  });
  return { status, acknowledgedEvents: acknowledged };
}
