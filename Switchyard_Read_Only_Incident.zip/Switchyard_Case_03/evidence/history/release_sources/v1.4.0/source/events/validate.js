export function validateEvent(event) {
  if (event.schema !== 'order-document/1') throw new Error('Unsupported event schema');
  if (typeof event.eventId !== 'string' || !event.eventId) throw new Error('Missing event ID');
  if (typeof event.runId !== 'string' || !event.runId) throw new Error('Missing run ID');
  if (!Number.isSafeInteger(event.generation) || event.generation < 1) {
    throw new Error('Invalid generation');
  }
  const order = event.order;
  if (!order || ['accountId', 'warehouseId', 'orderId', 'customerLabel', 'updatedAt']
      .some(key => typeof order[key] !== 'string')) throw new Error('Invalid order fields');
  if (order.state !== 'ready') throw new Error('Order is not eligible for picking');
  if (!Number.isSafeInteger(order.revision) || order.revision < 1) {
    throw new Error('Invalid revision');
  }
  if (!Array.isArray(order.lines) || !order.lines.length) throw new Error('No order lines');
  const seen = new Set();
  for (const line of order.lines) {
    if (!Number.isSafeInteger(line.lineNo) || line.lineNo < 1 || seen.has(line.lineNo)) {
      throw new Error('Invalid or repeated line number');
    }
    if (typeof line.sku !== 'string' || !line.sku) throw new Error('Invalid SKU');
    if (!Number.isSafeInteger(line.quantity) || line.quantity < 1) {
      throw new Error('Invalid quantity');
    }
    seen.add(line.lineNo);
  }
  return event;
}
