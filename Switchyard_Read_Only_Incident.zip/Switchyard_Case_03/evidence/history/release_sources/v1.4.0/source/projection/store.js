export function applyDocument(database, event) {
  return database.transaction(() => {
    const duplicate = database.get('SELECT event_id FROM processed_events WHERE event_id = :eventId', {
      eventId: event.eventId,
    });
    if (duplicate) return 'duplicate';
    const o = event.order;
    const key = { accountId: o.accountId, warehouseId: o.warehouseId, orderId: o.orderId };
    const current = database.get(`
      SELECT generation, revision FROM projection_orders
      WHERE account_id = :accountId AND warehouse_id = :warehouseId AND order_id = :orderId`, key);
    const isOlder = current && (
      event.generation < current.generation ||
      (event.generation === current.generation && o.revision <= current.revision)
    );
    if (!isOlder) {
      database.run(`DELETE FROM projection_lines
        WHERE account_id = :accountId AND warehouse_id = :warehouseId AND order_id = :orderId`, key);
      database.run(`INSERT INTO projection_orders
        (account_id, warehouse_id, order_id, generation, revision, customer_label, state)
        VALUES (:accountId, :warehouseId, :orderId, :generation, :revision, :customerLabel, :state)
        ON CONFLICT(account_id, warehouse_id, order_id) DO UPDATE SET
          generation = excluded.generation, revision = excluded.revision,
          customer_label = excluded.customer_label, state = excluded.state`, {
        ...key, generation: event.generation, revision: o.revision,
        customerLabel: o.customerLabel, state: o.state,
      });
      for (const line of o.lines) {
        database.run(`INSERT INTO projection_lines
          (account_id, warehouse_id, order_id, line_no, sku, quantity)
          VALUES (:accountId, :warehouseId, :orderId, :lineNo, :sku, :quantity)`, {
          ...key, lineNo: line.lineNo, sku: line.sku, quantity: line.quantity,
        });
      }
    }
    database.run(`INSERT INTO processed_events(event_id, run_id, disposition)
      VALUES (:eventId, :runId, :disposition)`, {
      eventId: event.eventId, runId: event.runId, disposition: isOlder ? 'older-or-equal' : 'applied',
    });
    return isOlder ? 'older-or-equal' : 'applied';
  });
}
