export function orderLabel(orderId, config) {
  const prefix = config.labelPrefix.trim() || 'Order';
  return `${prefix} ${orderId}`;
}
