import test from 'node:test';
import assert from 'node:assert/strict';
import { validateEvent } from '../source/events/validate.js';
import { readConfig } from '../source/config.js';
const example = {
  schema:'order-document/1', eventId:'example/o1', runId:'example', generation:1,
  order:{accountId:'a',warehouseId:'w',orderId:'o1',revision:1,state:'ready',
    customerLabel:'Example',updatedAt:'2025-01-01T00:00:00Z',
    lines:[{lineNo:1,sku:'sku-1',quantity:2}]},
};
test('accepts a valid event', () => assert.equal(validateEvent(example), example));
test('rejects duplicate line numbers', () => assert.throws(() =>
  validateEvent({...example, order:{...example.order, lines:[...example.order.lines,...example.order.lines]}})));
test('rejects zero batch size', () => assert.throws(() => readConfig({queueBatchSize:0})));
