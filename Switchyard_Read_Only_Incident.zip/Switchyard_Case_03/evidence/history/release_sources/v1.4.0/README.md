# Switchyard application source

A warehouse order board with a SQL order store, queued order documents, and a
separate read model for the picking screen. Normal updates and maintenance
rebuilds publish the same event schema. The board API reads the read model.

This repository is the executable application model used for the exercise.
Hosted queue and function invocation behavior is supplied by the capture harness.
`source/storage/sqlite.js` is the local SQL adapter; it is not an AWS SDK.
Application SQL is ordinary SQLite SQL and runs against the supplied database.

All source is included. Only the platform scheduler, clock, fault injection and
capture writer are outside this repository. Their behavior is specified in the
case's `reference/RUNTIME.md`. You do not need to run this code to investigate.

## Entrypoints

* Maintenance: `source/rebuild/run.js`
* Normal order update: `source/orders/publish-one.js`
* Queue consumer: `source/queue/handler.js`
* Picking screen: `source/api/board.js`
* Administrative order screen: `source/api/admin.js`

The source's database calls resolve directly to the SQL files and schema in
`source/storage/`. No hidden ORM or remote service supplies additional logic.
