export function readConfig(input = {}) {
  const result = {
    pageLimit: input.pageLimit ?? 36,
    queueBatchSize: input.queueBatchSize ?? 5,
    visibilityTimeoutSeconds: input.visibilityTimeoutSeconds ?? 90,
    labelPrefix: input.labelPrefix ?? 'Order',
  };
  for (const name of ['pageLimit', 'queueBatchSize', 'visibilityTimeoutSeconds']) {
    if (!Number.isSafeInteger(result[name]) || result[name] < 1) {
      throw new Error(`Invalid setting: ${name}`);
    }
  }
  if (result.queueBatchSize > 10) throw new Error('Queue batch exceeds ten messages');
  return result;
}
