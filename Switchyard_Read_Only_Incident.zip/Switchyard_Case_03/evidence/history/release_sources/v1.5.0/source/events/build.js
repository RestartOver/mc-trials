import { eventKey } from '../shared/identity.js';
export function buildEvent(run, order) {
  return {
    schema: 'order-document/1',
    eventId: eventKey(run.runId, order.orderId),
    runId: run.runId,
    generation: run.generation,
    source: run.trigger,
    sourceDataset: run.datasetId,
    order,
  };
}
