PRAGMA foreign_keys = ON;
CREATE TABLE source_orders (
  dataset_id TEXT NOT NULL, account_id TEXT NOT NULL, warehouse_id TEXT NOT NULL,
  order_id TEXT NOT NULL, customer_label TEXT NOT NULL, revision INTEGER NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('ready','held')), updated_at TEXT NOT NULL,
  PRIMARY KEY(dataset_id, account_id, order_id)
);
CREATE TABLE source_order_lines (
  dataset_id TEXT NOT NULL, account_id TEXT NOT NULL, order_id TEXT NOT NULL,
  line_no INTEGER NOT NULL CHECK(line_no > 0), sku TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK(quantity > 0),
  PRIMARY KEY(dataset_id, account_id, order_id, line_no),
  FOREIGN KEY(dataset_id, account_id, order_id) REFERENCES source_orders(dataset_id, account_id, order_id)
);
CREATE TABLE projection_orders (
  account_id TEXT NOT NULL, warehouse_id TEXT NOT NULL, order_id TEXT NOT NULL,
  generation INTEGER NOT NULL, revision INTEGER NOT NULL,
  customer_label TEXT NOT NULL, state TEXT NOT NULL,
  PRIMARY KEY(account_id, warehouse_id, order_id)
);
CREATE TABLE projection_lines (
  account_id TEXT NOT NULL, warehouse_id TEXT NOT NULL, order_id TEXT NOT NULL,
  line_no INTEGER NOT NULL, sku TEXT NOT NULL, quantity INTEGER NOT NULL,
  PRIMARY KEY(account_id, warehouse_id, order_id, line_no),
  FOREIGN KEY(account_id, warehouse_id, order_id) REFERENCES projection_orders(account_id, warehouse_id, order_id)
);
CREATE TABLE processed_events (
  event_id TEXT PRIMARY KEY, run_id TEXT NOT NULL, disposition TEXT NOT NULL
);
CREATE INDEX idx_source_warehouse ON source_orders(dataset_id,account_id,warehouse_id,state,order_id);
CREATE INDEX idx_processed_run ON processed_events(run_id);

CREATE INDEX idx_source_state ON source_orders(dataset_id,account_id,state,order_id);
