CREATE TABLE application_logs(run_id TEXT,log_index INTEGER,timestamp TEXT,service TEXT,event TEXT,record_json TEXT,PRIMARY KEY(run_id,log_index));

CREATE TABLE board_after(run_id TEXT,account_id TEXT,warehouse_id TEXT,order_id TEXT,customer_label TEXT,revision INTEGER,line_no INTEGER,sku TEXT,quantity INTEGER,PRIMARY KEY(run_id,order_id,line_no));

CREATE TABLE board_before(run_id TEXT,account_id TEXT,warehouse_id TEXT,order_id TEXT,customer_label TEXT,revision INTEGER,line_no INTEGER,sku TEXT,quantity INTEGER,PRIMARY KEY(run_id,order_id,line_no));

CREATE TABLE captured_processed_events(run_id TEXT,event_id TEXT,disposition TEXT,PRIMARY KEY(run_id,event_id));

CREATE TABLE captured_projection_orders(run_id TEXT,account_id TEXT,warehouse_id TEXT,order_id TEXT,generation INTEGER,revision INTEGER,customer_label TEXT,state TEXT,PRIMARY KEY(run_id,order_id));

CREATE TABLE content_checks (run_id TEXT, dataset_id TEXT, account_id TEXT, warehouse_id TEXT, release TEXT, trigger TEXT, page_limit INTEGER, queue_batch_size INTEGER, job_status TEXT, expected_orders INTEGER, actual_orders INTEGER, expected_lines INTEGER, actual_lines INTEGER, missing_orders INTEGER, extra_orders INTEGER, missing_lines INTEGER, extra_lines INTEGER, changed_lines INTEGER, result TEXT);

CREATE TABLE database_page_rows(run_id TEXT,page INTEGER,row_index INTEGER,dataset_id TEXT,account_id TEXT,warehouse_id TEXT,order_id TEXT,customer_label TEXT,revision INTEGER,state TEXT,updated_at TEXT,line_no INTEGER,sku TEXT,quantity INTEGER,PRIMARY KEY(run_id,page,row_index));

CREATE TABLE database_pages(run_id TEXT,page INTEGER,after_order_id TEXT,row_count INTEGER,PRIMARY KEY(run_id,page));

CREATE TABLE deliveries(run_id TEXT,invocation_id TEXT,message_id TEXT,receive_count INTEGER,body_sha256 TEXT,body_json TEXT);

CREATE TABLE job_runs (run_id TEXT, dataset_id TEXT, account_id TEXT, warehouse_id TEXT, release TEXT, commit_sha TEXT, trigger TEXT, started_at TEXT, generation INTEGER, page_limit INTEGER, queue_batch_size INTEGER, duplicate_every INTEGER, transient_failure_every INTEGER, status TEXT, published_orders INTEGER, acknowledged_events INTEGER, outstanding_messages INTEGER);

CREATE TABLE published_messages(run_id TEXT,message_id TEXT,event_id TEXT,order_id TEXT,body_sha256 TEXT,body_json TEXT,PRIMARY KEY(run_id,message_id));

CREATE TABLE source_order_lines(
  dataset_id TEXT,
  account_id TEXT,
  order_id TEXT,
  line_no INT,
  sku TEXT,
  quantity INT
);

CREATE TABLE source_orders(
  dataset_id TEXT,
  account_id TEXT,
  warehouse_id TEXT,
  order_id TEXT,
  customer_label TEXT,
  revision INT,
  state TEXT,
  updated_at TEXT
);
