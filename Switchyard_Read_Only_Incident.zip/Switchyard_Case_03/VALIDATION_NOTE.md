# Package validation

This is a fictional, locally executed incident model, not a claim about a real
company or a calibrated examination for a particular experience level.

All 20 captured runs were executed using the application code from their named
Git releases. Their output records were compared with the selected source orders
and lines using a separate unpaginated source query. There are 11 matching and
9 mismatching original captures. The supplied content-check files identify them.

The intended correction was replayed against all 20 captured inputs and another
240 seeded scenarios with different data shapes and runtime settings. Corrected
output matched the source in all of those checks. The correction and detailed
postmortem are not included in the participant files.

There are 22 application source files, 12 Git commits, 2,114 published messages
and 8,481 application/runtime log records in the recorded incident package.
Captured message bodies were also checked against all 2,318 delivered bodies.

These checks support the internal consistency of the case. They do not prove
that every possible application input is correct or establish how long a human
investigator ought to take.
