# Evidence locations and fields

## Run identity

`evidence/jobs.csv` is the compact index; `evidence/runs.json` contains the full
requests. A run selects one dataset, account and warehouse. Use all three when
identifying the corresponding source orders. Release and commit are explicit.

`evidence/deployments/releases.json` maps tags to commits. The actual Git history
is in `repository/.git`. Text logs, patches and complete source trees from the
three captured releases are under `evidence/history/`, also searchable offline.

## Source records

`evidence/database/source_orders.csv` contains one record per source order.
`source_order_lines.csv` contains its numbered product lines. The matching SQL
database is `source.sqlite`; its empty projection tables are initialization
schema, not the captured picking screen. Captured projections are listed below.

`dataset_id`, `account_id` and `order_id` link a line to its parent order. The
warehouse is recorded on the parent. `state=ready` selects eligible orders.
`line_no` identifies a line within that order; it is not a SKU count or an event
sequence. `quantity` is the number of units on that line.

## Per-run captures

Each `evidence/captures/RB-xxxx/` directory contains:

| File | What it is |
| --- | --- |
| summary.json | Job status, effective settings and counts |
| application.jsonl | Application, database, queue, worker and API logs in execution order |
| database-pages.jsonl | Exact result rows returned by each rebuild page read, with the request cursor |
| published-messages.jsonl | Messages accepted by the queue, including full event bodies |
| delivered-messages.jsonl | Full bodies delivered to the worker and receive counts |
| invocations.jsonl | Worker batch membership and returned partial-failure responses |
| board-before.csv | The correct starting picking-screen API records |
| board-after.csv | Picking-screen API records after the queue drains |
| projection_orders.csv | Captured final stored order headers |
| projection_lines.csv | Captured final stored product lines |
| processed_events.csv | Final event-processing journal |

The page-read file is empty for a normal-update replay because that path reads
individual orders. Its single-order query results are reflected in the source
records, published bodies and `single_order_read` logs.

JSONL means one complete JSON object per line. The browser has a formatting
option for JSON and JSONL. The bodies in message captures are decoded JSON;
their `bodySha256` fields refer to the original serialized UTF-8 messages.

## Independent output checks

`evidence/checks/content_checks.csv` compares every ending API record against
all eligible source records for that run. Order counts, line counts, missing
and extra records and changed field values are checked. `MATCH` means equality
of that content, not merely an absence of complaints or successful delivery.

`line_differences.csv` identifies the actual missing, extra or changed line
records. Here `kind=missing` describes a source line absent from the ending
picking-screen response. SKU and quantity are the expected source values for a
missing line. All differing captures in this package have missing lines, not
extra or changed lines. These are observations, not a diagnosis.

## Cross-run SQL database

`evidence/database/observations.sqlite` collects the same evidence for read-only
queries. Its schema is `observations_schema.sql`. Useful tables are `job_runs`,
`source_orders`, `source_order_lines`, `board_before`, `board_after`,
`published_messages`, `deliveries`, `database_pages`, `database_page_rows`,
`captured_projection_orders`, `captured_processed_events`, `application_logs`
and `content_checks`. Captured tables include `run_id`.

There is no SQL engine embedded in the casebook. The actual SQLite files can be
queried with a tool you already have; the CSV and JSON equivalents are enough to
inspect all the evidence without installing one.
