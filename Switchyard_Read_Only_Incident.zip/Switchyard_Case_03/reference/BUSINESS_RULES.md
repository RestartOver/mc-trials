# What correct behavior means

## Orders and product lines

An account operates warehouses. Each source order belongs to one warehouse and
has a state of `ready` or `held`. For a particular account and warehouse, the
picking screen must contain all `ready` source orders and none of the `held`
orders. Every order in this case has at least one source line.

A product line is identified by its order and `line_no`. Two different lines can
have the same SKU and are still two separate lines. Do not merge lines solely
because their SKU or quantity happens to match.

For each eligible order, the picking screen must show exactly the source lines,
once each, with their original line number, SKU and quantity. The customer label
and source revision must also match. There is no rule that intentionally hides
particular lines, splits an order across screens, or limits its displayed lines.

Example: if an eligible source order has lines 1, 2 and 3, the screen must show
all three. Showing the order with only lines 1 and 2 is wrong even if the overall
number of displayed orders is correct.

## What a rebuild does

A rebuild republishes current order documents for a selected account and
warehouse. It should refresh the picking screen without changing which source
product lines belong to each order. It does not edit the source orders.

The administrative screen reads the source SQL tables. The picking screen reads
the separate projection tables. A projection is just a stored copy arranged for
that screen; it is not another authority on the business data.

## Order-document events

Both maintenance rebuilds and normal order updates publish `order-document/1`
events. Every event describes one complete current order, including its entire
list of source product lines. An event is not a fragment of an order or a list
of only the lines that changed. There is no separate end-of-order message.

An eligible new event replaces the projection's stored order and product lines
in one transaction. Lines absent from that complete document are not preserved
from an older projection. This is intended, because a genuine source update may
remove a line from an order. The consumer is not meant to reread the source
database to reconstruct an event.

`eventId` identifies the logical event. A duplicate delivery of that event must
not create additional lines. `messageId` identifies the queued message.
`generation` identifies a newer refresh generation; `revision` is the source
order revision within a generation. The application's comparison is in
`source/projection/store.js`.

## Meaning of Complete

A job is Complete when it has published the expected number of selected orders,
all those event IDs have been recorded as processed, and no messages remain
outstanding. That is the status currently implemented by Switchyard. It is not a
comparison of the resulting product lines against the source database.

The independent content-check file measures business correctness, not just job
completion. Proposing an additional check could be useful prevention, but it
would not by itself identify the defect that produced the bad output.

## Captured input

All captures use the frozen source dataset DS-101. Account and warehouse filters
still differ between runs. The source is unchanged throughout each capture;
there are no unrecorded edits, migrations of orders between warehouses, or
external product lookups to discover. Quantities are positive whole numbers.
