# Runtime and capture boundaries

## This is a recorded, executable model

The application source is JavaScript. The local capture runner executes its SQL
using Node's SQLite binding. Lambda-style invocations and queue delivery are
modeled explicitly; there is no hidden AWS service, credential or account that
you need to inspect. Node is unnecessary for the read-only investigation.

The source and event handling code in the repository produced the captures. The
platform capture harness supplies only the scheduler, clock, queue delivery,
controlled transient failures, starting database copy and evidence writer.
Application source from each named Git release was loaded for that run.

## Independent runs

Each recorded run starts from its own independent copy of DS-101 and a correct
picking-screen projection of the selected orders. The starting projection has
generation 0. The run's newly assigned generation is listed in `jobs.csv`.

These are isolated diagnostic replays, not 20 successive edits to one shared
board. Never treat the ending board of RB-3907 as the starting board of RB-3908.
For every run, its own `board-before.csv` and `board-after.csv` are captured.

A `normal-update` replay invokes the normal single-order publishing path once
for each selected order. It does not change any source values during the replay.
A `rebuild` replay invokes the maintenance publishing path. Both use the same
queue and projection worker afterward.

## Queue behavior in these captures

Publishing records the serialized body as an immutable message. The queue never
alters, combines or truncates message bodies. Producer and delivery captures
include SHA-256 hashes of the exact UTF-8 body for verification.

The scheduler delivers each block of up to seven newly published messages in
reverse order. It also schedules another delivery for every Nth published
message when `duplicateEvery` is nonzero. These duplicate deliveries reuse that
message's body and message ID. They are delivery attempts, not new source edits.

`queueBatchSize` controls the number of records in each worker invocation. The
worker returns `batchItemFailures`, containing message IDs to retry. A successful
record is acknowledged. Failed records are appended for redelivery.

When `transientFailureEvery` is nonzero, the first attempted application of every
Nth published message throws `SimulatedDatabaseUnavailable` before any database
write. The next attempt can proceed. No failure is injected after a successful
transaction. Setting either schedule field to 0 disables that injected behavior.

All captured jobs ultimately drain their queues, and no message reaches the
dead-letter queue. The delivery bodies, attempts and responses are supplied;
you do not have to trust a queue-depth metric as proof of delivery.

This model uses sequential database transactions. There is no simultaneous
shared-memory access, hidden service timeout, source write during a scan, or
missing worker log. The exercise does not depend on unspecified timing.

## Configurations and dates

Each request's effective configuration is in `runs.json` and `jobs.csv`.
`pageLimit` is the SQL parameter passed by the order repository to its page
query. `queueBatchSize` is an independent delivery setting. Configuration changes
do not imply an application-code change, and neither is omitted from these runs.

All captured timestamps are UTC, written with `Z`. Log timestamps are generated
by the capture clock as successive operations execute; they are not measurements
of real-world service latency. Git author and commit dates include their offsets.

## Validation and boundaries

Event-schema validation checks required fields, types, positive quantities and
unique line numbers within a document. It does not query the source to count
lines. The producer's contract is to supply a complete order document.

The screen response is captured after the queue has drained. It applies no cache,
extra client-side filter, result limit or transformation beyond the supplied API
SQL. Field serialization preserves strings and whole numbers.

General hardening outside this defined input and runtime is not another required
bug. The goal is to explain the captured missing lines under these conditions.

## Optional public references

These references explain the general APIs. The case-specific behavior above is
the complete contract for this simulation.

SQLite SELECT syntax: https://www.sqlite.org/lang_select.html
AWS Lambda with SQS: https://docs.aws.amazon.com/lambda/latest/dg/with-sqs.html
SQS error handling and partial responses:
https://docs.aws.amazon.com/lambda/latest/dg/services-sqs-errorhandling.html
