# Application map

```text
                         Source SQL tables
                       orders + order lines
                         /              \
             Normal update publisher    Rebuild publisher
                         \              /
                       Order-document queue
                                |
                         Projection worker
                                |
                       Projection SQL tables
                                |
                          Picking-screen API

```

The administrative order API reads the source tables directly.

## Where the code is

| Component | Entrypoint | Main dependencies |
| --- | --- | --- |
| Rebuild request | repository/source/rebuild/request.js | Configuration and selected-order count |
| Rebuild publishing | repository/source/rebuild/run.js | orders/repository.js, orders/group.js, events/build.js, queue/publish.js |
| Normal publishing | repository/source/orders/publish-one.js | orders/read-one.sql, same event builder and publisher |
| Queue consumer | repository/source/queue/handler.js | events/validate.js, projection/store.js |
| Picking-screen API | repository/source/api/board.js | projection_orders, projection_lines |
| Administrative API | repository/source/api/admin.js | Source order repository |
| Job completion | repository/source/jobs/complete.js | Published count, processed journal, queue status |
| Local database | repository/source/storage/sqlite.js | SQL files and source/storage/schema.sql |

`database.all`, `database.get` and `database.run` execute the provided SQL and
named bindings against SQLite. `database.transaction` commits all its statements
together or rolls them back on an exception. There is no hidden query builder.

The hosted queue service is modeled outside this repository. Its complete
capture behavior and the permitted interpretation of the evidence are in
`RUNTIME.md`.

Other source files provide configuration, labels, health responses, hashes and
identity formatting. Git history includes changes outside the incident's path;
release tags identify the code used by each captured run.
