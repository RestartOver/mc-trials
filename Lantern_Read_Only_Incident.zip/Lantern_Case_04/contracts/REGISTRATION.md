# Registration interface

## Save a registration edit

`PATCH /accounts/{accountId}/passes/{passId}/registration`

The request may contain `status`, `attendeeLabel` or `contactLabel`. Unspecified
fields are unchanged. `status` is either `active` or `cancelled`. Passes already
exist in this capture; there is no transfer between accounts or events.

```json
{"status":"active","contactLabel":"Reception desk 2"}
```

Each successful save advances this pass's **registration version** by one,
including edits that change only a label. The version is a positive integer;
a larger version means a later saved registration record for the same account
and pass. The payments service has a separate record and version counter.

## Registration notification

The save and its outbox notification are committed together. The body contains
the entire registration record, not just the edited fields.

```json
{
  "schema": "pass-fact/1",
  "eventId": "registration/ORG-DEMO/PS-DEMO/12",
  "operationId": "OP-DEMO-1",
  "feed": "registration",
  "accountId": "ORG-DEMO",
  "passId": "PS-DEMO",
  "sourceVersion": 12,
  "occurredAt": "2026-10-12T08:00:00.000Z",
  "body": {
    "eventId": "EV-DEMO",
    "status": "active",
    "attendeeLabel": "Example visitor",
    "contactLabel": "Reception desk 2"
  }
}
```

Here `sourceVersion: 12` means the twelfth saved registration version for this
pass. `occurredAt` records when the source save happened. A retry sends the same
notification with the same `eventId`, version and body.

The envelope's `eventId` identifies a notification. The body's `eventId`
identifies the workshop. They belong to different objects; the examples and
captured data use `registration/...` for notification IDs and `EV-...` for
workshop IDs.

Machine-readable message shapes are in `contracts/pass-fact.schema.json`.
