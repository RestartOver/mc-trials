# Payments interface

## Save a payment record

`PATCH /accounts/{accountId}/passes/{passId}/payment`

The request may contain `status`, `receiptLabel` or `amountMinor`. Unspecified
fields are unchanged. Payment status is `unpaid`, `paid` or `refunded`.
`amountMinor` is a nonnegative whole number of the currency's smallest units.
The amount is descriptive here; the status determines whether payment permits
entry. No currency conversion or external payment processing is part of the case.

```json
{"status":"paid","receiptLabel":"Receipt 204"}
```

Every successful payment-record save advances its **payment version** by one,
including receipt-label edits. That counter is local to this pass's payment
record. It is not a registration version or an event-wide transaction number.

## Payment notification

The save writes a complete payment body to the outbox in the same transaction.
The body does not contain registration fields.

```json
{
  "schema": "pass-fact/1",
  "eventId": "payment/ORG-DEMO/PS-DEMO/5",
  "operationId": "OP-DEMO-2",
  "feed": "payment",
  "accountId": "ORG-DEMO",
  "passId": "PS-DEMO",
  "sourceVersion": 5,
  "occurredAt": "2026-10-12T08:01:00.000Z",
  "body": {
    "status": "paid",
    "receiptLabel": "Receipt 204",
    "amountMinor": 4500
  }
}
```

`sourceVersion: 5` means the fifth saved payment version for this account and
pass. A later payment body replaces the earlier payment body; it does not
replace the registration record. Retries keep the same event ID and version.

The payment service publishes saved records, not incremental charges to apply.
Delivering the same notification twice must not charge anyone or toggle a state.
Machine-readable message shapes are in `contracts/pass-fact.schema.json`.
