# Desk, gate and delivery interfaces

## Read the desk status

`GET /accounts/{accountId}/passes/{passId}` reads both source records.

```json
{
  "accountId":"ORG-DEMO", "passId":"PS-DEMO", "eventId":"EV-DEMO",
  "registration":{"status":"active","version":12,"attendeeLabel":"Example visitor","updatedAt":"2026-10-12T08:00:00.000Z"},
  "payment":{"status":"paid","version":5,"amountMinor":4500,"updatedAt":"2026-10-12T08:01:00.000Z"}
}
```

## Ask for admission

`POST /gate/scans` accepts a scanner ID, account ID, event ID and pass ID.
A scanner's QR decoding has already produced those identifiers in the capture.

```json
{"scanId":"SCN-DEMO","scannerId":"SC-DEMO","accountId":"ORG-DEMO","eventId":"EV-DEMO","passId":"PS-DEMO"}
```

A successful HTTP response contains the decision. HTTP 200 means the request
was handled, not that admission was granted or independently checked.

```json
{"scanId":"SCN-DEMO","accountId":"ORG-DEMO","passId":"PS-DEMO","eventId":"EV-DEMO","allowed":true,"reason":"READY","registrationVersion":12,"paymentVersion":5}
```

`registrationVersion` and `paymentVersion` report the source versions present
in the gate's stored decision. They are not versions of the scanner software.
There is no browser, scanner or API decision cache in the captured path.

## Receive a notification

The delivery adapter calls `receiveFact`. A notification identifies its source
using `feed`. The gate stores one current registration fact and one current
payment fact for a pass, then evaluates admission using both.

A new notification for a source record should replace that source's older fact.
A late older version of the same source record must not undo a newer version.
A repeated event ID is a duplicate and does not apply the change again.
`occurredAt` is useful for investigation; it is not a delivery-order guarantee.

Deliveries can be delayed, repeated or arrive out of order. `eventId` identifies
the logical notification; `deliveryId` identifies one delivery attempt. A
successful acknowledgement can mean `applied`, `duplicate` or `not_newer`.
The last two mean no new fact was stored. They are not transport errors.

## Reprint and health

Reprinting changes the paper/QR layout, not the pass identity or admission rule.
A reprinted token still identifies the same account, event and pass.
The health endpoint checks database reachability and queue/outbox counts. It
does not compare gate decisions with the source records.
