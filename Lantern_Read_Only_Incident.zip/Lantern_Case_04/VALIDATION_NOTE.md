# How this case was checked

The supplied application was executed against its captured opening state and
recorded operations. Its output includes 197 source notifications, 1,779 unique
log events and 294 scanner requests. A repeated execution reproduced the entire
log stream byte for byte.

A separate checker reconstructed source records from the opening state and edits.
It checked the emitted notification bodies, the source values read at each scan,
and the source tables at the end. It then compared scanner decisions with the
stated business rule. Those results are in `evidence/checks/`.

Of the 294 scans, 293 have settled notifications and one was captured while a
notification was pending. The original application has 103 incorrect settled
decision/reason comparisons. The intended corrected implementation eliminates
all 103 in a separate replay. The pending comparison is not counted as a failure.

The correction was also checked in 384 additional generated scenarios containing
2,064 settled scanner requests. All corrected decisions matched an independent
business-rule calculation. The scenarios varied starting records, source edits,
delivery orders and ordinary transport behavior. The five packaged SQLite
snapshots passed integrity and foreign-key checks.

These are executable correctness checks, not a benchmark of human difficulty.
They support one underlying implementation defect behind the captured incident;
they are not a claim that this reduced application is production-complete or
free of every conceivable unrelated improvement.

The correction, answer and author test harness are not in the participant files.

## Casebook checks

The exact embedded HTML was loaded into Chromium with networking disabled.
Every embedded text file was rendered, and search, comparisons, JSON/CSV
formatting, file exports and note exports were exercised. No JavaScript errors
or external resource requests were observed. The exported CSV matched its
original bytes, including line endings.

This build environment blocks URL navigation, including local file URLs, so
browser checks used programmatic HTML loading rather than a native double-click.
Browser storage was unavailable in that test context; the documented Save notes
fallback was checked. The casebook itself has no external asset dependencies.
