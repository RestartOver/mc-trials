# Lantern investigation notes

## Initial suspicion (optional, before browsing the implementation)


## Notes


## Conclusion or stopping point

A short explanation or a spoken account is sufficient. Use this file only if it
helps; no particular note-taking format is required.
