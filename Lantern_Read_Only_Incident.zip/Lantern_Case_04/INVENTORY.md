# Package inventory

This package contains 23 JavaScript source files, five SQLite snapshots and their CSV table exports. The source and evidence are the same in the ZIP and standalone casebook. SQLite binaries themselves are only in the ZIP.

The casebook has the same layout and controls as Switchyard: file/content search, a two-file comparison view, optional JSON/CSV formatting, original line numbers, and local notes. The added diagrams and contracts appear as ordinary files.

No Git repository, previous application build, answer key, corrected implementation, private conversation or participant annotations are included.

Browser notes are stored locally when the browser permits it. Use **Save notes** to keep a portable copy. Notes are not written back into the ZIP. **Save open file** exports the original text, not a reformatted version.

`MANIFEST.sha256` lists checksums for the extracted package files except itself. It is intentionally not embedded in the casebook, avoiding a self-referential checksum.

## Files

| File | Bytes | In browser |
| --- | ---: | --- |
| `CASE_NOTES.md` | 278 | Yes |
| `READ_FIRST.md` | 4796 | Yes |
| `VALIDATION_NOTE.md` | 2324 | Yes |
| `application/config/transport.json` | 87 | Yes |
| `application/package.json` | 232 | Yes |
| `application/source/api/desk.js` | 791 | Yes |
| `application/source/api/health.js` | 560 | Yes |
| `application/source/api/reprint.js` | 611 | Yes |
| `application/source/api/scan.js` | 1397 | Yes |
| `application/source/gate/consumer.js` | 2232 | Yes |
| `application/source/gate/envelope.js` | 1082 | Yes |
| `application/source/gate/facts.js` | 1407 | Yes |
| `application/source/gate/policy.js` | 406 | Yes |
| `application/source/gate/project.js` | 1531 | Yes |
| `application/source/payments/repository.js` | 616 | Yes |
| `application/source/payments/service.js` | 1765 | Yes |
| `application/source/registration/repository.js` | 691 | Yes |
| `application/source/registration/service.js` | 1775 | Yes |
| `application/source/relay/outbox.js` | 1167 | Yes |
| `application/source/relay/publisher.js` | 725 | Yes |
| `application/source/replay.js` | 699 | Yes |
| `application/source/runtime/clock.js` | 707 | Yes |
| `application/source/runtime/queue.js` | 2216 | Yes |
| `application/source/runtime/run.js` | 4232 | Yes |
| `application/source/runtime/seed.js` | 2101 | Yes |
| `application/source/shared/identity.js` | 316 | Yes |
| `application/source/shared/validation.js` | 598 | Yes |
| `application/source/storage/schema.sql` | 3479 | Yes |
| `application/source/storage/sqlite.js` | 966 | Yes |
| `contracts/GATE.md` | 2457 | Yes |
| `contracts/PAYMENTS.md` | 1753 | Yes |
| `contracts/REGISTRATION.md` | 1833 | Yes |
| `contracts/pass-fact.schema.json` | 3389 | Yes |
| `evidence/checks/decision_checks.csv` | 39604 | Yes |
| `evidence/checks/decision_differences.csv` | 14013 | Yes |
| `evidence/checks/summary.json` | 601 | Yes |
| `evidence/database/0815/deliveries.csv` | 20494 | Yes |
| `evidence/database/0815/events.csv` | 241 | Yes |
| `evidence/database/0815/gate_audit.csv` | 13026 | Yes |
| `evidence/database/0815/gate_facts.csv` | 20229 | Yes |
| `evidence/database/0815/gate_passes.csv` | 3949 | Yes |
| `evidence/database/0815/outbox.csv` | 38262 | Yes |
| `evidence/database/0815/payments.csv` | 3270 | Yes |
| `evidence/database/0815/processed_events.csv` | 7364 | Yes |
| `evidence/database/0815/registrations.csv` | 4133 | Yes |
| `evidence/database/0815/scans.csv` | 11036 | Yes |
| `evidence/database/0815.sqlite` | 249856 | ZIP only |
| `evidence/database/0830/deliveries.csv` | 30686 | Yes |
| `evidence/database/0830/events.csv` | 241 | Yes |
| `evidence/database/0830/gate_audit.csv` | 19878 | Yes |
| `evidence/database/0830/gate_facts.csv` | 20252 | Yes |
| `evidence/database/0830/gate_passes.csv` | 4099 | Yes |
| `evidence/database/0830/outbox.csv` | 57317 | Yes |
| `evidence/database/0830/payments.csv` | 3334 | Yes |
| `evidence/database/0830/processed_events.csv` | 11270 | Yes |
| `evidence/database/0830/registrations.csv` | 4197 | Yes |
| `evidence/database/0830/scans.csv` | 15292 | Yes |
| `evidence/database/0830.sqlite` | 319488 | ZIP only |
| `evidence/database/0850/deliveries.csv` | 48160 | Yes |
| `evidence/database/0850/events.csv` | 241 | Yes |
| `evidence/database/0850/gate_audit.csv` | 31427 | Yes |
| `evidence/database/0850/gate_facts.csv` | 20177 | Yes |
| `evidence/database/0850/gate_passes.csv` | 4015 | Yes |
| `evidence/database/0850/outbox.csv` | 91135 | Yes |
| `evidence/database/0850/payments.csv` | 3271 | Yes |
| `evidence/database/0850/processed_events.csv` | 17904 | Yes |
| `evidence/database/0850/registrations.csv` | 4132 | Yes |
| `evidence/database/0850/scans.csv` | 21810 | Yes |
| `evidence/database/0850.sqlite` | 421888 | ZIP only |
| `evidence/database/closing/deliveries.csv` | 48160 | Yes |
| `evidence/database/closing/events.csv` | 241 | Yes |
| `evidence/database/closing/gate_audit.csv` | 31427 | Yes |
| `evidence/database/closing/gate_facts.csv` | 20177 | Yes |
| `evidence/database/closing/gate_passes.csv` | 4015 | Yes |
| `evidence/database/closing/outbox.csv` | 91135 | Yes |
| `evidence/database/closing/payments.csv` | 3271 | Yes |
| `evidence/database/closing/processed_events.csv` | 17904 | Yes |
| `evidence/database/closing/registrations.csv` | 4132 | Yes |
| `evidence/database/closing/scans.csv` | 25982 | Yes |
| `evidence/database/closing.sql` | 303734 | Yes |
| `evidence/database/closing.sqlite` | 434176 | ZIP only |
| `evidence/database/opening/deliveries.csv` | 122 | Yes |
| `evidence/database/opening/events.csv` | 241 | Yes |
| `evidence/database/opening/gate_audit.csv` | 112 | Yes |
| `evidence/database/opening/gate_facts.csv` | 20512 | Yes |
| `evidence/database/opening/gate_passes.csv` | 4088 | Yes |
| `evidence/database/opening/outbox.csv` | 100 | Yes |
| `evidence/database/opening/payments.csv` | 3324 | Yes |
| `evidence/database/opening/processed_events.csv` | 74 | Yes |
| `evidence/database/opening/registrations.csv` | 4026 | Yes |
| `evidence/database/opening/scans.csv` | 138 | Yes |
| `evidence/database/opening.sqlite` | 135168 | ZIP only |
| `evidence/deployments/installations.csv` | 556 | Yes |
| `evidence/deployments/scanners.csv` | 224 | Yes |
| `evidence/inputs/capture-input.json` | 150277 | Yes |
| `evidence/inputs/operations.csv` | 40939 | Yes |
| `evidence/logs/all.jsonl` | 440234 | Yes |
| `evidence/logs/by-service/capture.jsonl` | 309 | Yes |
| `evidence/logs/by-service/desk-api.jsonl` | 47523 | Yes |
| `evidence/logs/by-service/gate-api.jsonl` | 82456 | Yes |
| `evidence/logs/by-service/gate-worker.jsonl` | 87307 | Yes |
| `evidence/logs/by-service/health.jsonl` | 2534 | Yes |
| `evidence/logs/by-service/payments.jsonl` | 24151 | Yes |
| `evidence/logs/by-service/registration.jsonl` | 26501 | Yes |
| `evidence/logs/by-service/relay.jsonl` | 44818 | Yes |
| `evidence/logs/by-service/transport.jsonl` | 124635 | Yes |
| `evidence/passes.csv` | 1724 | Yes |
| `evidence/queue/delivery_journal.csv` | 48160 | Yes |
| `evidence/relay/published.jsonl` | 69060 | Yes |
| `evidence/requests/desk.jsonl` | 122767 | Yes |
| `evidence/requests/health.jsonl` | 2508 | Yes |
| `evidence/requests/reprints.jsonl` | 2700 | Yes |
| `evidence/requests/scans.jsonl` | 128934 | Yes |
| `evidence/scans.csv` | 32415 | Yes |
| `reference/BUSINESS_RULES.md` | 2992 | Yes |
| `reference/EVIDENCE_GUIDE.md` | 3882 | Yes |
| `reference/RUNTIME.md` | 3260 | Yes |
| `reference/SYSTEM_MAP.md` | 2228 | Yes |
| `reference/diagrams/entities.svg` | 2585 | Yes |
| `reference/diagrams/sequence.svg` | 2308 | Yes |
| `reference/diagrams/system-map.svg` | 3621 | Yes |
