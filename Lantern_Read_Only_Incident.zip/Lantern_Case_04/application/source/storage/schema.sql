PRAGMA foreign_keys = ON;
CREATE TABLE events (
  account_id TEXT NOT NULL, event_id TEXT NOT NULL, title TEXT NOT NULL,
  venue_id TEXT NOT NULL, event_day TEXT NOT NULL,
  PRIMARY KEY(account_id, event_id)
);
CREATE TABLE registrations (
  account_id TEXT NOT NULL, pass_id TEXT NOT NULL, event_id TEXT NOT NULL,
  registration_status TEXT NOT NULL CHECK(registration_status IN ('active','cancelled')),
  attendee_label TEXT NOT NULL, contact_label TEXT NOT NULL,
  source_version INTEGER NOT NULL CHECK(source_version >= 1), updated_at TEXT NOT NULL,
  PRIMARY KEY(account_id,pass_id),
  FOREIGN KEY(account_id,event_id) REFERENCES events(account_id,event_id)
);
CREATE TABLE payments (
  account_id TEXT NOT NULL, pass_id TEXT NOT NULL,
  payment_status TEXT NOT NULL CHECK(payment_status IN ('unpaid','paid','refunded')),
  receipt_label TEXT NOT NULL, amount_minor INTEGER NOT NULL CHECK(amount_minor >= 0),
  source_version INTEGER NOT NULL CHECK(source_version >= 1), updated_at TEXT NOT NULL,
  PRIMARY KEY(account_id,pass_id),
  FOREIGN KEY(account_id,pass_id) REFERENCES registrations(account_id,pass_id)
);
CREATE TABLE outbox (
  event_id TEXT PRIMARY KEY, operation_id TEXT NOT NULL, feed TEXT NOT NULL,
  account_id TEXT NOT NULL, pass_id TEXT NOT NULL, source_version INTEGER NOT NULL,
  occurred_at TEXT NOT NULL, payload_json TEXT NOT NULL, published_at TEXT
);
CREATE TABLE gate_facts (
  account_id TEXT NOT NULL, pass_id TEXT NOT NULL,
  feed TEXT NOT NULL CHECK(feed IN ('registration','payment')),
  source_version INTEGER NOT NULL, payload_json TEXT NOT NULL,
  source_event_id TEXT NOT NULL, source_updated_at TEXT NOT NULL, received_at TEXT NOT NULL,
  PRIMARY KEY(account_id,pass_id,feed)
);
CREATE TABLE gate_passes (
  account_id TEXT NOT NULL, pass_id TEXT NOT NULL, event_id TEXT,
  registration_status TEXT, payment_status TEXT,
  registration_version INTEGER, payment_version INTEGER,
  eligible INTEGER NOT NULL CHECK(eligible IN (0,1)), reason_code TEXT NOT NULL,
  evaluated_at TEXT NOT NULL,
  PRIMARY KEY(account_id,pass_id)
);
CREATE TABLE processed_events (
  event_id TEXT PRIMARY KEY, account_id TEXT NOT NULL, pass_id TEXT NOT NULL,
  feed TEXT NOT NULL, source_version INTEGER NOT NULL,
  disposition TEXT NOT NULL, processed_at TEXT NOT NULL
);
CREATE TABLE gate_audit (
  audit_id INTEGER PRIMARY KEY AUTOINCREMENT, processed_at TEXT NOT NULL,
  delivery_id TEXT NOT NULL, event_id TEXT NOT NULL, account_id TEXT NOT NULL,
  pass_id TEXT NOT NULL, feed TEXT NOT NULL, source_version INTEGER NOT NULL,
  compared_version INTEGER, disposition TEXT NOT NULL
);
CREATE TABLE deliveries (
  delivery_id TEXT PRIMARY KEY, event_id TEXT NOT NULL, operation_id TEXT NOT NULL,
  account_id TEXT NOT NULL, pass_id TEXT NOT NULL, feed TEXT NOT NULL,
  scheduled_at TEXT NOT NULL, attempted_at TEXT, acknowledged_at TEXT,
  attempt INTEGER NOT NULL, state TEXT NOT NULL, result TEXT
);
CREATE TABLE scans (
  scan_id TEXT PRIMARY KEY, scanned_at TEXT NOT NULL, scanner_id TEXT NOT NULL,
  account_id TEXT NOT NULL, pass_id TEXT NOT NULL, requested_event_id TEXT NOT NULL,
  http_status INTEGER NOT NULL, allowed INTEGER NOT NULL, reason_code TEXT NOT NULL,
  registration_version INTEGER, payment_version INTEGER
);
CREATE INDEX idx_outbox_pending ON outbox(published_at,occurred_at,event_id);
CREATE INDEX idx_gate_audit_pass ON gate_audit(account_id,pass_id,audit_id);
CREATE INDEX idx_deliveries_pass ON deliveries(account_id,pass_id,state);
