import { DatabaseSync } from 'node:sqlite';

export function openDatabase(filename, schema) {
  const connection = new DatabaseSync(filename);
  connection.exec('PRAGMA foreign_keys = ON;');
  if (schema) connection.exec(schema);
  function prepare(sql) {
    const statement = connection.prepare(sql);
    statement.setAllowBareNamedParameters(true);
    return statement;
  }
  return {
    get(sql, values = {}) { return prepare(sql).get(values); },
    all(sql, values = {}) { return prepare(sql).all(values); },
    run(sql, values = {}) { return prepare(sql).run(values); },
    transaction(work) {
      connection.exec('BEGIN IMMEDIATE');
      try {
        const result = work();
        connection.exec('COMMIT');
        return result;
      } catch (error) {
        connection.exec('ROLLBACK');
        throw error;
      }
    },
    backup(filename) { connection.prepare('VACUUM INTO ?').run(filename); },
    close() { connection.close(); },
  };
}
