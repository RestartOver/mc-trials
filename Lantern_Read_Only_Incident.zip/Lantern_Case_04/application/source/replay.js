// Optional capture reproduction. No server, credentials or network access are used.
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { runCapture } from './runtime/run.js';

const [inputPath,outputPath]=process.argv.slice(2);
if (!inputPath || !outputPath) {
  console.error('Usage: node application/source/replay.js <capture-input.json> <new-output-directory>');
  process.exitCode=2;
} else {
  const input=JSON.parse(readFileSync(resolve(inputPath),'utf8'));
  const result=runCapture(input,{outputDirectory:resolve(outputPath)});
  console.log(JSON.stringify({logEvents:result.logs.length,notifications:result.published.length,scans:result.scans.length}));
}
