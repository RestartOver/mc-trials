import { readPayment, storePayment, paymentPayload } from './repository.js';
import { appendNotification } from '../relay/outbox.js';
import { passKey } from '../shared/identity.js';
import { requireChoice, requireText } from '../shared/validation.js';

export function updatePayment(operation, services) {
  const { database, clock, log } = services;
  const key = passKey(operation.accountId, operation.passId);
  const changed = database.transaction(() => {
    const current = readPayment(database, key);
    if (!current) throw new Error('Payment record not found');
    const patch = operation.patch;
    const next = {
      ...key,
      paymentStatus: patch.status ?? current.payment_status,
      receiptLabel: patch.receiptLabel ?? current.receipt_label,
      amountMinor: patch.amountMinor ?? current.amount_minor,
      version: current.source_version + 1,
      at: clock.now(),
    };
    requireChoice(next.paymentStatus, ['unpaid','paid','refunded'], 'payment status');
    requireText(next.receiptLabel, 'receipt label');
    if (!Number.isSafeInteger(next.amountMinor) || next.amountMinor < 0) {
      throw new Error('Invalid amount');
    }
    storePayment(database, next);
    const row = readPayment(database, key);
    const event = appendNotification(database, {
      operationId: operation.operationId, feed: 'payment', ...key,
      version: row.source_version, at: clock.now(), body: paymentPayload(row),
    });
    return { row, event };
  });
  log('payments', 'change_committed', {
    operationId: operation.operationId, ...key,
    sourceVersion: changed.row.source_version,
    paymentStatus: changed.row.payment_status,
    fields: Object.keys(operation.patch), eventId: changed.event.eventId,
  });
  return changed.event;
}
