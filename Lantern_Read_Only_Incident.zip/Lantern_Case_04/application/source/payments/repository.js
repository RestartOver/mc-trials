export function readPayment(database, key) {
  return database.get(`SELECT * FROM payments
    WHERE account_id = :accountId AND pass_id = :passId`, key);
}
export function storePayment(database, record) {
  database.run(`UPDATE payments SET payment_status = :paymentStatus,
    receipt_label = :receiptLabel, amount_minor = :amountMinor,
    source_version = :version, updated_at = :at
    WHERE account_id = :accountId AND pass_id = :passId`, record);
}
export function paymentPayload(row) {
  return {
    status: row.payment_status,
    receiptLabel: row.receipt_label,
    amountMinor: row.amount_minor,
  };
}
