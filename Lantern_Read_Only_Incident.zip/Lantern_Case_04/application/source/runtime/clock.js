export function makeClock(startAt) {
  let time = Date.parse(startAt);
  let serial = 0;
  const tasks = [];
  return {
    now() { return new Date(time).toISOString(); },
    schedule(at, work) {
      const scheduledTime = typeof at === 'number' ? at : Date.parse(at);
      if (!Number.isFinite(scheduledTime) || scheduledTime < time) throw new Error('Invalid scheduled time');
      tasks.push({ time: scheduledTime, serial: serial++, work });
    },
    after(ms, work) { this.schedule(time + ms, work); },
    run() {
      while (tasks.length) {
        tasks.sort((a,b) => a.time-b.time || a.serial-b.serial);
        const next = tasks.shift(); time = next.time; next.work();
      }
    },
  };
}
