import { readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { openDatabase } from '../storage/sqlite.js';
import { makeClock } from './clock.js';
import { makeQueue } from './queue.js';
import { seedOpening } from './seed.js';
import { updateRegistration } from '../registration/service.js';
import { updatePayment } from '../payments/service.js';
import { publishPending } from '../relay/publisher.js';
import { receiveFact } from '../gate/consumer.js';
import { scanPass } from '../api/scan.js';
import { readDeskStatus } from '../api/desk.js';
import { reprintPass } from '../api/reprint.js';
import { health } from '../api/health.js';

export function runCapture(input, options = {}) {
  const schema = readFileSync(new URL('../storage/schema.sql',import.meta.url),'utf8');
  const database = openDatabase(':memory:',schema);
  const clock = makeClock(input.opening.at);
  const captured = {logs:[],published:[],scans:[],desk:[],reprints:[],health:[]};
  const services = {
    database,clock,
    log(service,event,fields) {captured.logs.push({ts:clock.now(),service,event,...fields});},
    capture(kind,value) {captured[kind].push(value);},
  };
  services.queue=makeQueue(services,input.transport,input.rules ?? {},receiveFact);
  seedOpening(database,input.opening);
  if (options.outputDirectory) {
    mkdirSync(join(options.outputDirectory,'database'),{recursive:true});
    database.backup(join(options.outputDirectory,'database','opening.sqlite'));
  }
  for (const operation of input.operations) clock.schedule(operation.at,() => {
    if (operation.kind === 'registration.update') updateRegistration(operation,services);
    else if (operation.kind === 'payment.update') updatePayment(operation,services);
    else if (operation.kind === 'scan') {
      const response=scanPass(operation,services);
      const key={accountId:operation.accountId,passId:operation.passId};
      const deskResponse=readDeskStatus(database,key);
      const outstanding=database.all(`SELECT DISTINCT event_id FROM deliveries
        WHERE account_id=:accountId AND pass_id=:passId AND state='pending'`,key).map(r=>r.event_id);
      const unpublished=database.all(`SELECT event_id FROM outbox
        WHERE account_id=:accountId AND pass_id=:passId AND published_at IS NULL`,key).map(r=>r.event_id);
      const scan={at:clock.now(),request:operation,response,
        unsettledEventIds:[...new Set([...outstanding,...unpublished])]};
      captured.scans.push(scan);
      captured.desk.push({at:clock.now(),scanId:operation.scanId,request:key,response:deskResponse});
      services.log('desk-api','status_read',{scanId:operation.scanId,...key,httpStatus:deskResponse.status});
    }
    else if (operation.kind === 'reprint') captured.reprints.push({at:clock.now(),request:operation,response:reprintPass(operation,services)});
    else if (operation.kind === 'health') {
      const response=health(services);captured.health.push({at:clock.now(),requestId:operation.operationId,response});
      services.log('health','sampled',{requestId:operation.operationId,...response.body});
    }
    else if (operation.kind === 'checkpoint') {
      if (options.outputDirectory) database.backup(join(options.outputDirectory,'database',operation.name+'.sqlite'));
      services.log('capture','checkpoint_written',{checkpoint:operation.name});
    }
    else throw new Error('Unknown operation kind: '+operation.kind);
    publishPending(services);
  });
  clock.run();
  const tables=['events','registrations','payments','outbox','gate_facts','gate_passes','processed_events','gate_audit','deliveries','scans'];
  captured.tables=Object.fromEntries(tables.map(name=>[name,database.all(`SELECT * FROM ${name} ORDER BY rowid`)]));
  if (options.outputDirectory) {
    database.backup(join(options.outputDirectory,'database','closing.sqlite'));
    for (const name of ['logs','published','scans','desk','reprints','health']) {
      writeFileSync(join(options.outputDirectory,name+'.jsonl'),captured[name].map(x=>JSON.stringify(x)).join('\n')+'\n');
    }
    writeFileSync(join(options.outputDirectory,'tables.json'),JSON.stringify(captured.tables));
  }
  database.close();
  return captured;
}
