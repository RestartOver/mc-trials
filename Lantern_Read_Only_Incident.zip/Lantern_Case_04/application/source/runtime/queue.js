import { deliveryId } from '../shared/identity.js';

export function makeQueue(services, settings, rules, consumer) {
  const { database, clock, log } = services;
  function schedule(event, rule, copy, attempt, delayMs) {
    const id = deliveryId(event.eventId, copy, attempt);
    const at = new Date(Date.parse(clock.now()) + delayMs).toISOString();
    database.run(`INSERT INTO deliveries
      (delivery_id,event_id,operation_id,account_id,pass_id,feed,scheduled_at,attempt,state)
      VALUES (:id,:eventId,:operationId,:accountId,:passId,:feed,:at,:attempt,'pending')`, {
      id, eventId: event.eventId, operationId: event.operationId,
      accountId: event.accountId, passId: event.passId, feed: event.feed, at, attempt,
    });
    clock.schedule(at, () => {
      database.run('UPDATE deliveries SET attempted_at=:at WHERE delivery_id=:id', { at: clock.now(), id });
      log('transport', 'delivery_attempt', { deliveryId:id,eventId:event.eventId,
        accountId:event.accountId,passId:event.passId,feed:event.feed,attempt });
      if (copy === 1 && attempt <= (rule.transientFailures ?? 0)) {
        database.run("UPDATE deliveries SET state='retry_scheduled',result='HTTP_503' WHERE delivery_id=:id", {id});
        log('transport', 'delivery_deferred', { deliveryId:id,eventId:event.eventId,
          accountId:event.accountId,passId:event.passId,httpStatus:503,retryMs:settings.retryMs });
        schedule(event,rule,copy,attempt+1,settings.retryMs);
        return;
      }
      const disposition = consumer(event,id,services);
      database.run(`UPDATE deliveries SET state='acknowledged',acknowledged_at=:at,result=:result
        WHERE delivery_id=:id`, {at:clock.now(),result:disposition,id});
      log('transport', 'delivery_acknowledged', {deliveryId:id,eventId:event.eventId,
        accountId:event.accountId,passId:event.passId,feed:event.feed,httpStatus:200,result:disposition});
    });
  }
  return {
    send(event) {
      const rule = rules[event.operationId] ?? {};
      schedule(event,rule,1,1,rule.delayMs ?? settings.delayMs[event.feed]);
      if (rule.duplicateAfterMs !== undefined) {
        schedule(event,rule,2,1,rule.duplicateAfterMs);
      }
    },
  };
}
