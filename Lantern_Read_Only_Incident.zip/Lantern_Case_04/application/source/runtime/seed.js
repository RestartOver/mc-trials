import { rebuildPass } from '../gate/project.js';
import { registrationPayload } from '../registration/repository.js';
import { paymentPayload } from '../payments/repository.js';

export function seedOpening(database, opening) {
  database.transaction(() => {
    for (const event of opening.events) database.run(`INSERT INTO events
      (account_id,event_id,title,venue_id,event_day) VALUES (:accountId,:eventId,:title,:venueId,:eventDay)`, event);
    for (const pass of opening.passes) {
      database.run(`INSERT INTO registrations
        (account_id,pass_id,event_id,registration_status,attendee_label,contact_label,source_version,updated_at)
        VALUES (:accountId,:passId,:eventId,:status,:attendeeLabel,:contactLabel,:version,:at)`, {
        accountId:pass.accountId,passId:pass.passId,eventId:pass.eventId,...pass.registration,
      });
      database.run(`INSERT INTO payments
        (account_id,pass_id,payment_status,receipt_label,amount_minor,source_version,updated_at)
        VALUES (:accountId,:passId,:status,:receiptLabel,:amountMinor,:version,:at)`, {
        accountId:pass.accountId,passId:pass.passId,...pass.payment,
      });
      const key = {accountId:pass.accountId,passId:pass.passId};
      const r = database.get('SELECT * FROM registrations WHERE account_id=:accountId AND pass_id=:passId',key);
      const p = database.get('SELECT * FROM payments WHERE account_id=:accountId AND pass_id=:passId',key);
      for (const [feed,row,body] of [['registration',r,registrationPayload(r)],['payment',p,paymentPayload(p)]]) {
        database.run(`INSERT INTO gate_facts
          (account_id,pass_id,feed,source_version,payload_json,source_event_id,source_updated_at,received_at)
          VALUES (:accountId,:passId,:feed,:version,:body,:eventId,:at,:receivedAt)`, {
          ...key,feed,version:row.source_version,body:JSON.stringify(body),
          eventId:`opening/${feed}/${pass.accountId}/${pass.passId}/${row.source_version}`,
          at:row.updated_at,receivedAt:opening.at,
        });
      }
      rebuildPass(database,key,opening.at);
    }
  });
}
