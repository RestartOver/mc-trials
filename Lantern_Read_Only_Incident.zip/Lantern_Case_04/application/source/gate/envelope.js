import { requireText, requireChoice, requireVersion, requireTimestamp } from '../shared/validation.js';

export function readEnvelope(event) {
  if (event.schema !== 'pass-fact/1') throw new Error('Unsupported event schema');
  for (const name of ['eventId','accountId','passId']) requireText(event[name], name);
  requireChoice(event.feed, ['registration','payment'], 'feed');
  requireVersion(event.sourceVersion);
  requireTimestamp(event.occurredAt);
  if (!event.body || typeof event.body !== 'object') throw new Error('Missing body');
  if (event.feed === 'registration') {
    requireChoice(event.body.status, ['active','cancelled'], 'registration status');
    for (const key of ['eventId','attendeeLabel','contactLabel']) requireText(event.body[key], key);
  } else {
    requireChoice(event.body.status, ['unpaid','paid','refunded'], 'payment status');
    requireText(event.body.receiptLabel, 'receiptLabel');
    if (!Number.isSafeInteger(event.body.amountMinor) || event.body.amountMinor < 0) {
      throw new Error('Invalid amountMinor');
    }
  }
  return event;
}
