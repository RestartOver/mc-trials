export function decideEligibility(registration, payment) {
  if (!registration || !payment) return { eligible: false, reason: 'DETAILS_PENDING' };
  if (registration.status !== 'active') {
    return { eligible: false, reason: 'REGISTRATION_CANCELLED' };
  }
  if (payment.status !== 'paid') {
    return { eligible: false, reason: 'PAYMENT_REQUIRED' };
  }
  return { eligible: true, reason: 'READY' };
}
