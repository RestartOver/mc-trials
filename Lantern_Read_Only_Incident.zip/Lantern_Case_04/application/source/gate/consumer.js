import { readEnvelope } from './envelope.js';
import { readVersion, storeFact } from './facts.js';
import { rebuildPass } from './project.js';
import { passKey } from '../shared/identity.js';

export function receiveFact(rawEvent, deliveryId, services) {
  const event = readEnvelope(rawEvent);
  const { database, clock, log } = services;
  const key = passKey(event.accountId, event.passId);
  const result = database.transaction(() => {
    const processed = database.get('SELECT event_id FROM processed_events WHERE event_id = :eventId', {
      eventId: event.eventId,
    });
    let disposition;
    let comparedVersion = null;
    let projection = null;
    if (processed) {
      disposition = 'duplicate';
    } else {
      comparedVersion = readVersion(database, event);
      if (event.sourceVersion <= comparedVersion) {
        disposition = 'not_newer';
      } else {
        storeFact(database, event, clock.now());
        projection = rebuildPass(database, key, clock.now());
        disposition = 'applied';
      }
      database.run(`INSERT INTO processed_events
        (event_id,account_id,pass_id,feed,source_version,disposition,processed_at)
        VALUES (:eventId,:accountId,:passId,:feed,:version,:disposition,:at)`, {
        eventId: event.eventId, ...key, feed: event.feed,
        version: event.sourceVersion, disposition, at: clock.now(),
      });
    }
    database.run(`INSERT INTO gate_audit
      (processed_at,delivery_id,event_id,account_id,pass_id,feed,source_version,compared_version,disposition)
      VALUES (:at,:deliveryId,:eventId,:accountId,:passId,:feed,:version,:comparedVersion,:disposition)`, {
      at: clock.now(), deliveryId, eventId: event.eventId, ...key, feed: event.feed,
      version: event.sourceVersion, comparedVersion, disposition,
    });
    return { disposition, comparedVersion, projection };
  });
  log('gate-worker', 'fact_processed', {
    deliveryId, eventId: event.eventId, ...key, feed: event.feed,
    sourceVersion: event.sourceVersion, comparedVersion: result.comparedVersion,
    disposition: result.disposition,
  });
  if (result.projection) log('gate-worker', 'pass_evaluated', { ...key, ...result.projection });
  return result.disposition;
}
