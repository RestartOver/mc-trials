import { readFacts } from './facts.js';
import { decideEligibility } from './policy.js';

export function rebuildPass(database, key, now) {
  const facts = readFacts(database, key);
  const registration = facts.registration?.body;
  const payment = facts.payment?.body;
  const decision = decideEligibility(registration, payment);
  database.run(`INSERT INTO gate_passes
    (account_id,pass_id,event_id,registration_status,payment_status,
     registration_version,payment_version,eligible,reason_code,evaluated_at)
    VALUES (:accountId,:passId,:eventId,:registrationStatus,:paymentStatus,
      :registrationVersion,:paymentVersion,:eligible,:reason,:at)
    ON CONFLICT(account_id,pass_id) DO UPDATE SET
      event_id=excluded.event_id, registration_status=excluded.registration_status,
      payment_status=excluded.payment_status,
      registration_version=excluded.registration_version, payment_version=excluded.payment_version,
      eligible=excluded.eligible, reason_code=excluded.reason_code,
      evaluated_at=excluded.evaluated_at`, {
    ...key, eventId: registration?.eventId ?? null,
    registrationStatus: registration?.status ?? null, paymentStatus: payment?.status ?? null,
    registrationVersion: facts.registration?.version ?? null,
    paymentVersion: facts.payment?.version ?? null,
    eligible: Number(decision.eligible), reason: decision.reason, at: now,
  });
  return { ...decision, registrationVersion: facts.registration?.version ?? null,
    paymentVersion: facts.payment?.version ?? null };
}
