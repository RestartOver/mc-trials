export function readVersion(database, key) {
  const row = database.get(`
    SELECT MAX(source_version) AS source_version
    FROM gate_facts
    WHERE account_id = :accountId AND pass_id = :passId`, {
    accountId: key.accountId, passId: key.passId,
  });
  return row.source_version ?? 0;
}

export function storeFact(database, event, now) {
  database.run(`INSERT INTO gate_facts
    (account_id,pass_id,feed,source_version,payload_json,source_event_id,
     source_updated_at,received_at)
    VALUES (:accountId,:passId,:feed,:sourceVersion,:payloadJson,:eventId,:occurredAt,:now)
    ON CONFLICT(account_id,pass_id,feed) DO UPDATE SET
      source_version = excluded.source_version, payload_json = excluded.payload_json,
      source_event_id = excluded.source_event_id,
      source_updated_at = excluded.source_updated_at, received_at = excluded.received_at`, {
    accountId: event.accountId, passId: event.passId, feed: event.feed,
    sourceVersion: event.sourceVersion, payloadJson: JSON.stringify(event.body),
    eventId: event.eventId, occurredAt: event.occurredAt, now,
  });
}

export function readFacts(database, key) {
  const rows = database.all(`SELECT * FROM gate_facts
    WHERE account_id = :accountId AND pass_id = :passId ORDER BY feed`, key);
  return Object.fromEntries(rows.map(row => [row.feed, {
    version: row.source_version, body: JSON.parse(row.payload_json),
  }]));
}
