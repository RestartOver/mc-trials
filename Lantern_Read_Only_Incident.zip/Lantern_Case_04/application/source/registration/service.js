import { readRegistration, storeRegistration, registrationPayload } from './repository.js';
import { appendNotification } from '../relay/outbox.js';
import { passKey } from '../shared/identity.js';
import { requireChoice, requireText } from '../shared/validation.js';

export function updateRegistration(operation, services) {
  const { database, clock, log } = services;
  const key = passKey(operation.accountId, operation.passId);
  const changed = database.transaction(() => {
    const current = readRegistration(database, key);
    if (!current) throw new Error('Registration not found');
    const patch = operation.patch;
    const next = {
      ...key,
      registrationStatus: patch.status ?? current.registration_status,
      attendeeLabel: patch.attendeeLabel ?? current.attendee_label,
      contactLabel: patch.contactLabel ?? current.contact_label,
      version: current.source_version + 1,
      at: clock.now(),
    };
    requireChoice(next.registrationStatus, ['active','cancelled'], 'registration status');
    requireText(next.attendeeLabel, 'attendee label');
    requireText(next.contactLabel, 'contact label');
    storeRegistration(database, next);
    const row = readRegistration(database, key);
    const event = appendNotification(database, {
      operationId: operation.operationId, feed: 'registration', ...key,
      version: row.source_version, at: clock.now(), body: registrationPayload(row),
    });
    return { row, event };
  });
  log('registration', 'change_committed', {
    operationId: operation.operationId, ...key,
    sourceVersion: changed.row.source_version,
    registrationStatus: changed.row.registration_status,
    fields: Object.keys(operation.patch), eventId: changed.event.eventId,
  });
  return changed.event;
}
