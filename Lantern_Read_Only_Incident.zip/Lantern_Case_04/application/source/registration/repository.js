export function readRegistration(database, key) {
  return database.get(`SELECT * FROM registrations
    WHERE account_id = :accountId AND pass_id = :passId`, key);
}
export function storeRegistration(database, record) {
  database.run(`UPDATE registrations SET
    registration_status = :registrationStatus, attendee_label = :attendeeLabel,
    contact_label = :contactLabel, source_version = :version, updated_at = :at
    WHERE account_id = :accountId AND pass_id = :passId`, record);
}
export function registrationPayload(row) {
  return {
    eventId: row.event_id,
    status: row.registration_status,
    attendeeLabel: row.attendee_label,
    contactLabel: row.contact_label,
  };
}
