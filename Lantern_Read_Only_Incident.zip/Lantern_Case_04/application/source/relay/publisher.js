import { unpublished } from './outbox.js';

export function publishPending(services) {
  const { database, queue, clock, log, capture } = services;
  const rows = unpublished(database);
  for (const row of rows) {
    const event = JSON.parse(row.payload_json);
    queue.send(event);
    database.run('UPDATE outbox SET published_at = :at WHERE event_id = :eventId', {
      at: clock.now(), eventId: event.eventId,
    });
    capture('published', { publishedAt: clock.now(), event });
    log('relay', 'notification_published', {
      eventId: event.eventId, feed: event.feed, accountId: event.accountId,
      passId: event.passId, sourceVersion: event.sourceVersion,
      operationId: event.operationId,
    });
  }
}
