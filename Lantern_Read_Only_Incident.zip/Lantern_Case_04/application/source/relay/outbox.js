import { sourceEventId } from '../shared/identity.js';

export function appendNotification(database, change) {
  const event = {
    schema: 'pass-fact/1',
    eventId: sourceEventId(change.feed, change.accountId, change.passId, change.version),
    operationId: change.operationId, feed: change.feed,
    accountId: change.accountId, passId: change.passId,
    sourceVersion: change.version, occurredAt: change.at, body: change.body,
  };
  database.run(`INSERT INTO outbox
    (event_id, operation_id, feed, account_id, pass_id, source_version,
     occurred_at, payload_json, published_at)
    VALUES (:eventId, :operationId, :feed, :accountId, :passId, :sourceVersion,
      :occurredAt, :payloadJson, NULL)`, {
    eventId: event.eventId, operationId: event.operationId,
    feed: event.feed, accountId: event.accountId, passId: event.passId,
    sourceVersion: event.sourceVersion, occurredAt: event.occurredAt,
    payloadJson: JSON.stringify(event),
  });
  return event;
}
export function unpublished(database) {
  return database.all(`SELECT event_id, operation_id, payload_json
    FROM outbox WHERE published_at IS NULL ORDER BY occurred_at,event_id`);
}
