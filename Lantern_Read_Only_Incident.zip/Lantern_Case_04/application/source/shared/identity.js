export function passKey(accountId, passId) {
  return { accountId, passId };
}
export function sourceEventId(feed, accountId, passId, version) {
  return [feed, accountId, passId, version].join('/');
}
export function deliveryId(eventId, copy, attempt) {
  return `${eventId}/delivery-${copy}/attempt-${attempt}`;
}
