export function requireText(value, name) {
  if (typeof value !== 'string' || !value.length) throw new Error(`Invalid ${name}`);
  return value;
}
export function requireChoice(value, choices, name) {
  if (!choices.includes(value)) throw new Error(`Invalid ${name}`);
  return value;
}
export function requireVersion(value) {
  if (!Number.isSafeInteger(value) || value < 1) throw new Error('Invalid sourceVersion');
  return value;
}
export function requireTimestamp(value) {
  requireText(value, 'occurredAt');
  if (!Number.isFinite(Date.parse(value))) throw new Error('Invalid occurredAt');
}
