export function scanPass(request, services) {
  const { database, clock, log } = services;
  const key = { accountId: request.accountId, passId: request.passId };
  const row = database.get(`SELECT * FROM gate_passes
    WHERE account_id = :accountId AND pass_id = :passId`, key);
  let allowed = false;
  let reason = 'DETAILS_PENDING';
  if (row && row.event_id && row.event_id !== request.eventId) reason = 'WRONG_EVENT';
  else if (row) { allowed = Boolean(row.eligible); reason = row.reason_code; }
  const body = { scanId: request.scanId, ...key, eventId: request.eventId,
    allowed, reason, registrationVersion: row?.registration_version ?? null,
    paymentVersion: row?.payment_version ?? null };
  database.run(`INSERT INTO scans
    (scan_id,scanned_at,scanner_id,account_id,pass_id,requested_event_id,
      http_status,allowed,reason_code,registration_version,payment_version)
    VALUES (:scanId,:at,:scannerId,:accountId,:passId,:eventId,
      200,:allowed,:reason,:registrationVersion,:paymentVersion)`, {
    scanId: request.scanId, at: clock.now(), scannerId: request.scannerId, ...key,
    eventId: request.eventId, allowed: Number(allowed), reason,
    registrationVersion: body.registrationVersion, paymentVersion: body.paymentVersion,
  });
  log('gate-api', 'scan_completed', { ...body, scannerId: request.scannerId, httpStatus: 200 });
  return { status: 200, body };
}
