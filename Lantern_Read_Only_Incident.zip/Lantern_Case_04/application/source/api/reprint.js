export function reprintPass(request, services) {
  const row = services.database.get(`SELECT event_id FROM registrations
    WHERE account_id = :accountId AND pass_id = :passId`, {
    accountId: request.accountId, passId: request.passId,
  });
  if (!row) return { status: 404, body: { code: 'PASS_NOT_FOUND' } };
  const token = `lantern:${request.accountId}:${row.event_id}:${request.passId}`;
  const body = { passId: request.passId, token, template: request.template ?? 'compact/3' };
  services.log('desk-api', 'pass_reprinted', { ...request, template: body.template });
  return { status: 200, body };
}
