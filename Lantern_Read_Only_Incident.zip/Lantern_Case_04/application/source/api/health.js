export function health(services) {
  const { database } = services;
  const outbox = database.get('SELECT COUNT(*) AS n FROM outbox WHERE published_at IS NULL').n;
  const pending = database.get("SELECT COUNT(*) AS n FROM deliveries WHERE state = 'pending'").n;
  const counts = database.all('SELECT disposition,COUNT(*) AS n FROM processed_events GROUP BY disposition');
  return { status: 200, body: { database: 'reachable', unpublished: outbox,
    pendingDeliveries: pending, processed: Object.fromEntries(counts.map(row => [row.disposition,row.n])) }};
}
