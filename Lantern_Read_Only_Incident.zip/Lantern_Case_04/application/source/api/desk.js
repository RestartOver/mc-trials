import { readRegistration } from '../registration/repository.js';
import { readPayment } from '../payments/repository.js';

export function readDeskStatus(database, key) {
  const registration = readRegistration(database, key);
  const payment = readPayment(database, key);
  if (!registration || !payment) return { status: 404, body: { code: 'PASS_NOT_FOUND' } };
  return { status: 200, body: {
    ...key, eventId: registration.event_id,
    registration: { status: registration.registration_status, version: registration.source_version,
      attendeeLabel: registration.attendee_label, updatedAt: registration.updated_at },
    payment: { status: payment.payment_status, version: payment.source_version,
      amountMinor: payment.amount_minor, updatedAt: payment.updated_at },
  }};
}
