# Reading the captured evidence

## One window, not hundreds of independent reruns

`LC-041` is one continuous fictional incident from 07:55 to 09:00 UTC on
12 October 2026. Source edits, deliveries and scans share a clock. The CSV scan
index is chronological, but each row is a separate scanner request. Two scans
of the same pass can have different intervening source changes.

`evidence/passes.csv` identifies the account and event for each pass.
The full recorded operations and opening state are in
`evidence/inputs/capture-input.json`; `operations.csv` is its compact index.
No participant needs to run these inputs to solve the case.

## What each source establishes

| File or directory | What it records |
| --- | --- |
| `evidence/scans.csv` | Every scan's identifiers, time, actual decision and independently checked expected decision |
| `evidence/requests/scans.jsonl` | Exact scanner request and response; also any still-pending notification IDs for that pass |
| `evidence/requests/desk.jsonl` | A source-record read captured at the same point as each scan, linked by scan ID |
| `evidence/logs/all.jsonl` | The 1,779 unique log events in capture order |
| `evidence/logs/by-service/` | Subsets of the same log stream, not additional events |
| `evidence/relay/published.jsonl` | Full notification envelopes accepted by the delivery adapter |
| `evidence/queue/delivery_journal.csv` | Scheduled and attempted deliveries, retries and final acknowledgements |
| `evidence/database/` | Opening, 08:15, 08:30, 08:50 and closing SQLite snapshots plus table CSVs |
| `evidence/deployments/installations.csv` | Actual installation times for the builds active during this capture |
| `evidence/checks/` | Independent source-to-decision comparisons, separate from application health |

`MATCH` means the boolean decision and reason code agree with the business rule.
`MISMATCH` means one or both disagree. `PENDING` means a notification for a
source change was still outstanding at that scan, so this comparison is not used
to claim a settled-content failure. The pending IDs are given, not hidden.
The mismatch-only file is a convenience subset of the full comparison.

## Database snapshots

The opening snapshot is at 07:55. The other snapshots are at the times in their
filenames; `closing.sqlite` is at 09:00. Use a time-appropriate snapshot when
reconstructing an earlier scan. Closing tables are not historical snapshots of
what every scan saw.

Each SQLite file has a directory of same-named CSV exports. `closing.sql` is a
SQL dump, and `application/source/storage/schema.sql` defines the actual tables.
`gate_facts.payload_json` contains the stored source body as JSON. `outbox` retains
all emitted envelopes, even after publication. `gate_audit` records handler
dispositions; `processed_events` records logical event IDs already considered.

Example read-only lookup:

```sql
SELECT * FROM scans WHERE scan_id = 'SCN-42063';
```

No schema diagram is required to execute the SQL, but an entity map is included
in `reference/diagrams/entities.svg`.

## Identifiers and versions

| Prefix / field | Meaning |
| --- | --- |
| `ORG-...` | Organizer account |
| `EV-...` | Workshop or event |
| `PS-...` | Admission pass |
| `OP-...` | Captured source edit, request or operational action |
| `SCN-...` | Scanner request |
| `SC-...` | Scanner device |
| notification `eventId` | One saved source notification |
| `deliveryId` | One transport attempt for that notification |
| `sourceVersion` | Version supplied by the notification's source; see that source's interface |

JSONL means one JSON object per line. In the casebook, use Format JSON / CSV for
readability, or Raw / line numbers to cite an original source line. Search works
across filenames and their contents. SQLite binaries are in the ZIP; all their
exported tables are readable in the standalone casebook.
