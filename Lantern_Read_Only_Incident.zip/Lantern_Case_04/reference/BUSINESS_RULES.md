# What should happen at the gate?

## The rule

For the event being scanned, a pass may enter if and only if its registration is
`active` and its payment record is `paid`. The registration must belong to the
requested event. A cancelled registration must not enter, even if its payment
is still paid. An unpaid or refunded pass must not enter, even if its registration
is active.

| Registration | Payment | Correct result |
| --- | --- | --- |
| active | paid | Admit: `READY` |
| active | unpaid | Deny: `PAYMENT_REQUIRED` |
| active | refunded | Deny: `PAYMENT_REQUIRED` |
| cancelled | any state | Deny: `REGISTRATION_CANCELLED` |

A pass for another event is denied with `WRONG_EVENT` before these checks.
If the gate has not received both records yet, it may return `DETAILS_PENDING`.
There is no quota, waitlist, one-use lock, hidden override, age condition or
entry-time calculation in this case. Repeated scans are allowed and do not
consume a pass. All passes have a registration record and a payment record.

## Which records are authoritative?

The registration service owns whether a pass is active and which event it
belongs to. The payments service owns whether it is paid. The desk screen reads
these two source records. The gate maintains its own stored copy so a scan does
not have to call both source services.

Saving a source change does not synchronously update the gate. Each source
publishes a notification, and the gate worker processes it later. Once the
notifications for the relevant changes have been delivered, the gate decision
must reflect those source records. A successfully delivered notification can
still be deliberately ignored when it is a duplicate or a late older change.

The captured checks distinguish settled observations from scans taken while a
notification was still waiting. There is one `PENDING` comparison in this archive;
it is not counted as an incorrect settled decision.

## Which edits affect admission?

Changing registration status or payment status can change admission. Changing an
attendee label, contact label, receipt label or pass-print template does not by
itself change admission. These are normal administrative operations and their
records are included in the capture.

Example: an active, unpaid pass is denied. Its payment becomes paid. After that
notification is delivered, it should be admitted. Editing the receipt label
later must not be necessary to make the payment take effect.

## Words used in this case

An **account** is an event organizer. An **event** is a workshop or open day.
A **pass** belongs to one account and one event. In storage, use `account_id`
and `pass_id` together to identify it.

A **notification** is a message saying a source record was saved. A **feed**
names the source of that message: `registration` or `payment`. A **fact** in the
gate database is the gate's stored copy of one of those source records. The
`gate_passes` row combines the two facts into the decision used by scanners.
