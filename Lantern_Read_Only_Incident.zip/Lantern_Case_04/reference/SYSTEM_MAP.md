# Lantern's components

The desk reads the source records. The scanner reads the gate's stored decision.
The services between them carry and apply notifications.

![Lantern component map](diagrams/system-map.svg)

## Entrypoints

| Component | Function | Code |
| --- | --- | --- |
| Registration changes | `updateRegistration` | `application/source/registration/service.js` |
| Payment changes | `updatePayment` | `application/source/payments/service.js` |
| Notification publication | `publishPending` | `application/source/relay/publisher.js` |
| Delivery adapter | `makeQueue` | `application/source/runtime/queue.js` |
| Gate notification handler | `receiveFact` | `application/source/gate/consumer.js` |
| Gate decision calculation | `rebuildPass` | `application/source/gate/project.js` |
| Scanner endpoint | `scanPass` | `application/source/api/scan.js` |
| Desk endpoint | `readDeskStatus` | `application/source/api/desk.js` |
| Pass reprinting | `reprintPass` | `application/source/api/reprint.js` |
| Health endpoint | `health` | `application/source/api/health.js` |

Each repository file contains the SQL it runs. `database.get`, `database.all`
and `database.run` are thin SQLite wrappers. `database.transaction` commits
all the work in its callback together or rolls it back on an exception. There
is no hidden object-relational mapper or external database behavior to infer.

## One ordinary update and scan

![Notification and scanner sequence](diagrams/sequence.svg)

A source update writes its record and an outbox row in one transaction. An
outbox is simply a table of notifications waiting to be published. The relay
sends that row to the delivery adapter. The gate worker processes the notification
and acknowledges it. A later scanner request reads the stored gate decision.

Registration and payment updates follow this same path. They can arrive in
either order. The desk API does not read the gate tables, and the gate API does
not query the source tables during a scan.

`application/source/runtime/run.js` wires the capture together and dispatches
the recorded operations to these entrypoints. It is included so none of that
wiring is hidden. Reading it is optional; running it is not part of the task.
