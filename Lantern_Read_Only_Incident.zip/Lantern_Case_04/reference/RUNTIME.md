# Capture runtime and boundaries

## What is implemented

The supplied JavaScript runs the registration and payment updates, transactional
outbox, publication, gate handling, fact storage, admission calculation, desk
reads and scanner requests against actual SQLite tables. The output files were
captured from those functions. They were not written by a separate script that
only imitates their expected log messages.

For a portable archive, separate services use separate tables in one local SQLite
connection. Their source modules and contracts retain their service boundaries.
The desk can read source tables; scanner requests read only gate tables.
The model has no external APIs, npm packages or network calls.

The source begins from the captured opening records. Those records include a
consistent opening gate state. Historical activity before 07:55 is not supplied
or needed; the incident window contains the changes to investigate.

## Delivery and time

`application/source/runtime/clock.js` is a deterministic scheduler: a scheduled
callback runs at its recorded UTC time. Ties use scheduling order. This makes the
captures reproducible and avoids dependence on a machine's wall clock.

Transport normally delays registration notifications by 800 ms and payment
notifications by 1,400 ms. A recorded delivery rule may instead delay a particular
notification, duplicate it, or return HTTP 503 before it reaches the handler.
The exact rules are in `evidence/inputs/capture-input.json`, keyed by operation ID.
Retries wait 4,000 ms. A retry or duplicate preserves the event body and logical
event ID. The journal records every attempt and acknowledgement.

An HTTP 503 here occurs before the consumer runs; it is not a half-committed
consumer transaction. Every published event eventually reaches the consumer in
this archive, and no deliveries remain pending at the closing snapshot. A
notification's acknowledgement is not an independent check of business output.

## What is deliberately outside the case

HTTP routing, login, authorization, payment-provider settlement and camera/QR
recognition are outside this reduced application model. Requests have already
passed those checks. There is no clock skew, torn transaction, missing hidden
service, replica lag, undocumented override, or undisclosed source edit to find.
Source registration and payment records are correct.

The defect is in the supplied application behavior. The normal presence of an
outbox, transport retries or an older notification is not itself a claim of a bug.
This is not an exercise in adding every production-hardening feature to a demo.

## Source and history

One current application build is supplied. No `.git`, commit list, older source,
patch, solution or corrected implementation is present in the participant case.
Installation timestamps are supplied as operational context, not as Git dates.
There are no application build changes during the captured window.

Optional reproduction was tested with Node.js 22.16.0 using
`node:sqlite`. It is not necessary for the read-only investigation. Running
`application/source/replay.js` with the capture input and a new output directory
recreates the evidence; it does not perform an answer check or reveal a solution.
